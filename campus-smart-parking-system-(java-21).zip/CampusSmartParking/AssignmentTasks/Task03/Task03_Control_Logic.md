# TASK 3 – Control Logic

## 1. Slot Allocation Algorithm & Pseudocode

### Algorithm: First-Available Jagged Slot Allocation
1. Iterate floor index `f` from `0` to `slots.length - 1`.
2. Iterate slot index `s` from `0` to `slots[f].length - 1`.
3. If `slots[f][s]` is `false` (unoccupied):
   - Mark `slots[f][s] = true`.
   - Return `{f, s}` immediately using `return`.
4. If both loops complete without finding a free slot, return `null`.

```text
ALGORITHM AllocateFirstAvailable(slots[][])
  FOR f <- 0 TO length(slots) - 1 DO
      FOR s <- 0 TO length(slots[f]) - 1 DO
          IF slots[f][s] == FALSE THEN
              slots[f][s] <- TRUE
              RETURN [f, s]
          ENDIF
      ENDFOR
  ENDFOR
  RETURN NULL
END ALGORITHM
```

## 2. Parking Fee Calculation Algorithm & Pseudocode

```text
ALGORITHM CalculateParkingFee(vehicle, entryTime, exitTime, pass)
  IF exitTime < entryTime THEN
      THROW IllegalArgumentException
  ENDIF
  totalMinutes <- MinutesBetween(entryTime, exitTime)
  IF totalMinutes <= 0 THEN
      billedHours <- 1
  ELSE
      billedHours <- (totalMinutes + 59) DIV 60
  ENDIF

  IF vehicle IS DeliveryVan THEN
      rawFee <- SumHourByHourPeakOrStandard(entryTime, billedHours)
  ELSE IF vehicle IS EBike THEN
      rawFee <- EBIKE_FLAT_FEE
  ELSE
      rawFee <- billedHours * vehicle.ratePerHour()
  ENDIF

  rawFee <- MIN(rawFee, DAILY_MAX_CAP)
  chargingFee <- (vehicle IS Chargeable AND vehicle.isChargingRequested()) ? EV_CHARGING_FEE : 0.0

  IF pass != NULL AND pass.isValidOn(exitTime.date) THEN
      adjustedFee <- pass.applyToParkingFee(rawFee)
  ELSE
      adjustedFee <- rawFee
  ENDIF

  RETURN adjustedFee + chargingFee
END ALGORITHM
```

## 3. Role of `break`, `continue`, and `return`
- **`return`**: Immediately terminates the method and sends back the allocated `{f, s}` coordinate as soon as the first free slot is found, avoiding unnecessary inner and outer loop iterations.
- **`break`**: Exits only the innermost loop (for example, stopping a search on the current floor once a match is found, while still allowing outer logic to execute).
- **`continue`**: Skips the remaining body of the current iteration and jumps to the next slot/floor (for example, skipping already occupied slots during reporting or filtering).

## 4. Mandatory `ParkingFacility.java` Expected Output
```text
[0, 0]
[0, 1]
[1, 0]
null
true false false
[0, 1]
```

## 5. Alternative Comparison: Nested Loop Scan vs Stack-Based Free-Slot Pool

| Metric | Nested Loop Scan (`ParkingFacility`) | Stack-Based Allocation (`StackBasedAllocationDemo`) |
|---|---|---|
| `allocate()` Time | `O(N)` worst-case | `O(1)` (`pop()`) |
| `release(f, s)` Time | `O(1)` direct array access | `O(1)` (`push()`) |
| Extra Space | `O(1)` extra (only `boolean[][]`) | `O(N)` extra for stack of `int[]` coordinates |
| Slot Ordering | Always deterministic lowest floor & lowest slot | LIFO order (most recently vacated slot first) |
