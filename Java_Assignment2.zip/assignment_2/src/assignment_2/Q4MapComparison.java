package assignment_2;


import java.util.*;

public class Q4MapComparison {

    public static void main(String[] args) {

        Map<String, Integer> hashMap = new HashMap<>();
        Map<String, Integer> treeMap = new TreeMap<>();
        Map<String, Integer> linkedMap = new LinkedHashMap<>();

        String[] codes = {
            "M103", "M101", "M105", "M102", "M104"
        };

        int[] stock = {50, 100, 75, 60, 90};

        for (int i = 0; i < codes.length; i++) {
            hashMap.put(codes[i], stock[i]);
            treeMap.put(codes[i], stock[i]);
            linkedMap.put(codes[i], stock[i]);
        }

        System.out.println("HASHMAP:");
        System.out.println(hashMap);

        System.out.println("\nTREEMAP:");
        System.out.println(treeMap);

        System.out.println("\nLINKEDHASHMAP:");
        System.out.println(linkedMap);

        System.out.println("\nMedicine Lookup:");

        long start = System.nanoTime();

        for (int i = 0; i < 100000; i++) {
            hashMap.get("M103");
        }

        long end = System.nanoTime();

        System.out.println("HashMap Lookup: "
                + (end - start) / 1000000.0 + " ms");

        start = System.nanoTime();

        for (int i = 0; i < 100000; i++) {
            treeMap.get("M103");
        }

        end = System.nanoTime();

        System.out.println("TreeMap Lookup: "
                + (end - start) / 1000000.0 + " ms");

        start = System.nanoTime();

        for (int i = 0; i < 100000; i++) {
            linkedMap.get("M103");
        }

        end = System.nanoTime();

        System.out.println("LinkedHashMap Lookup: "
                + (end - start) / 1000000.0 + " ms");

        System.out.println("\nSorted Medicine Report:");

        start = System.nanoTime();

        for (String key : treeMap.keySet()) {
            System.out.println(key + " : " + treeMap.get(key));
        }

        end = System.nanoTime();

        System.out.println("Report Time: " + (end - start) + " ns");

        System.out.println("\nInsertion Order Report:");

        for (String key : linkedMap.keySet()) {
            System.out.println(key + " : " + linkedMap.get(key));
        }
    }
}
