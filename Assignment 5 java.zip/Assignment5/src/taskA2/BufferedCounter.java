
package taskA2;

import java.io.*;

public class BufferedCounter {

    public static void main(String[] args) {

        String fileName = "attendance.txt";

        // Create sample attendance file
        try {
            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(fileName));

            writer.write("Student 1");
            writer.newLine();

            writer.write("Student 2");
            writer.newLine();

            writer.write("Student 3");
            writer.newLine();

            writer.write("Student 4");

            writer.close();

            System.out.println("File created successfully!");

        } catch (IOException e) {
            System.out.println("File creation error: " + e.getMessage());
            return;
        }

        // Count lines using buffered byte reading
        int lines = 0;
        boolean hasData = false;
        int data;

        try (BufferedInputStream bis =
                new BufferedInputStream(
                        new FileInputStream(fileName))) {

            byte[] buffer = new byte[8192];
            int bytesRead;

            while ((bytesRead = bis.read(buffer)) != -1) {

                for (int i = 0; i < bytesRead; i++) {

                    hasData = true;

                    if (buffer[i] == '\n') {
                        lines++;
                        hasData = false;
                    }
                }
            }

            if (hasData) {
                lines++;
            }

            System.out.println("Total number of lines: " + lines);
            System.out.println("Buffered reading completed!");

        } catch (IOException e) {
            System.out.println("File reading error: " + e.getMessage());
        }
    }
}
