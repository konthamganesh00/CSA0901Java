package parking.model;

/**
 * Day-4 Challenge Addition: Electric bicycle (E-Bike) with a configurable flat parking fee.
 */
public class EBike extends TwoWheeler {

    private int batteryVoltage;

    public EBike() {
        this("UNREGISTERED", "Campus Cyclist", "0000000000", 48);
    }

    public EBike(String registrationNumber, String ownerName) {
        this(registrationNumber, ownerName, "N/A", 48);
    }

    public EBike(String registrationNumber, String ownerName, String contactNumber, int batteryVoltage) {
        super(registrationNumber, ownerName, contactNumber, false, VehicleType.E_BIKE);
        this.batteryVoltage = Math.max(24, batteryVoltage);
    }

    public int getBatteryVoltage() {
        return batteryVoltage;
    }

    public void setBatteryVoltage(int batteryVoltage) {
        if (batteryVoltage >= 12) {
            this.batteryVoltage = batteryVoltage;
        }
    }

    @Override
    public double ratePerHour() {
        // E-Bikes use a flat fee per visit rather than an hourly rate.
        return 0.0;
    }

    @Override
    public double calculateFee(int hours) {
        if (hours <= 0) {
            return 0.0;
        }
        return PricingConfig.getEbikeFlatFee();
    }

    @Override
    public String toString() {
        return String.format("%s [RegNo=%s, Owner=%s, Contact=%s, FlatFee=Rs %.2f, Battery=%dV]",
                getVehicleType().getDisplayName(),
                getRegistrationNumber(),
                getOwnerName(),
                getContactNumber(),
                PricingConfig.getEbikeFlatFee(),
                batteryVoltage);
    }
}
