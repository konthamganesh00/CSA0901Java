package assignment_3;


import java.util.*;
import java.io.*;

class InvalidAmountException extends Exception {
    InvalidAmountException(String message) {
        super(message);
    }
}

class InsufficientBalanceException extends Exception {
    InsufficientBalanceException(String message) {
        super(message);
    }
}

public class Q1ATMSimulation {

    static void withdraw(int balance, int amount)
            throws InvalidAmountException,
                   InsufficientBalanceException {

        if (amount <= 0) {
            throw new InvalidAmountException(
                "Withdrawal amount must be positive");
        }

        if (amount > balance) {
            throw new InsufficientBalanceException(
                "Insufficient account balance");
        }

        System.out.println("Withdrawal successful!");
        System.out.println("Remaining balance: "
                + (balance - amount));
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int balance = 10000;

        try {

            System.out.print("Enter account number: ");
            String account = sc.nextLine();

            if (!account.matches("\\d{9,12}")) {
                throw new IllegalArgumentException(
                    "Invalid account number");
            }

            System.out.print("Enter withdrawal amount: ");

            int amount = Integer.parseInt(sc.nextLine());

            withdraw(balance, amount);

            // Check card reader file
            FileReader reader =
                new FileReader("cardreader.txt");

            reader.close();

        } catch (IllegalArgumentException e) {

            System.out.println("Input Error: " + e.getMessage());

        } catch (InvalidAmountException e) {

            System.out.println("Amount Error: " + e.getMessage());

        } catch (InsufficientBalanceException e) {

            System.out.println("Balance Error: " + e.getMessage());

        } catch (IOException e) {

            System.out.println("File Error: " + e.getMessage());

        } finally {

            System.out.println("ATM transaction completed.");
            sc.close();
        }
    }
}
