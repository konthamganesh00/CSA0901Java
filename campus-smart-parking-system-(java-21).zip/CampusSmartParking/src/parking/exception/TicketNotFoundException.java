package parking.exception;

/**
 * Thrown when a parking ticket ID or active ticket for a vehicle cannot be located.
 */
public class TicketNotFoundException extends ParkingException {

    private static final long serialVersionUID = 1L;

    public TicketNotFoundException(String message) {
        super(message);
    }
}
