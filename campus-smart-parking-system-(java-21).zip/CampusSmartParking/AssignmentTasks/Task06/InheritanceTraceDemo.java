/**
 * Task 06 - Inheritance Hierarchy, super keyword, and Constructor Execution Trace.
 * Hierarchy:
 *   Vehicle -> TwoWheeler -> EBike
 *   Vehicle -> Car -> ElectricCar
 *   Vehicle -> Car -> DeliveryVan
 */
public class InheritanceTraceDemo {

    static class VehicleBase {
        protected String regNo;

        public VehicleBase(String regNo) {
            this.regNo = regNo;
            System.out.println("  [1] VehicleBase constructor executed for " + regNo);
        }

        public double ratePerHour() {
            return 20.0;
        }
    }

    static class TwoWheelerSub extends VehicleBase {
        public TwoWheelerSub(String regNo) {
            super(regNo);
            System.out.println("  [2] TwoWheelerSub constructor executed");
        }

        @Override
        public double ratePerHour() {
            return 10.0;
        }
    }

    static class CarSub extends VehicleBase {
        protected int doors;

        public CarSub(String regNo, int doors) {
            super(regNo);
            this.doors = doors;
            System.out.println("  [2] CarSub constructor executed (doors=" + doors + ")");
        }

        @Override
        public double ratePerHour() {
            return 30.0;
        }
    }

    static class ElectricCarSub extends CarSub {
        private double batteryKwh;

        public ElectricCarSub(String regNo, double batteryKwh) {
            super(regNo, 4); // Calls CarSub constructor via super(...)
            this.batteryKwh = batteryKwh;
            System.out.println("  [3] ElectricCarSub constructor executed (battery=" + batteryKwh + " kWh)");
        }

        @Override
        public double ratePerHour() {
            return super.ratePerHour() + 10.0; // Uses super.ratePerHour()
        }
    }

    public static void main(String[] args) {
        System.out.println("Creating TwoWheeler (Single/Hierarchical Inheritance):");
        TwoWheelerSub bike = new TwoWheelerSub("TN01W100");
        System.out.println("TwoWheeler rate: Rs " + bike.ratePerHour());

        System.out.println("\nCreating ElectricCar (Multilevel Inheritance Trace):");
        ElectricCarSub ev = new ElectricCarSub("TN03E300", 60.0);
        System.out.println("ElectricCar rate: Rs " + ev.ratePerHour());
    }
}
