package Q6;

import java.io.IOException;

/**
 * Q6 - Main Demonstration Driver
 * Displays clear headings, inputs, executes Triage.main()
 * (expected primary output: Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)),
 * runs boundary/invalid-input tests, and executes TriageBenchmark.
 */
public class Main {

    private static void verify(boolean condition, String testName) {
        if (!condition) {
            throw new AssertionError("Test failed: " + testName);
        }
        System.out.println("[PASS] " + testName);
    }

    private static void runBoundaryAndErrorTests() {
        System.out.println("\n--- Q6 Normal, Boundary & Invalid Input Tests ---");

        // 1. Boundary test: Empty triage queue
        Triage emptyTriage = new Triage();
        verify(emptyTriage.isEmpty() && emptyTriage.removeNextPatient() == null,
                "Empty triage queue removeNextPatient() safely returns null");

        // 2. Boundary test: All equal priority (S3) must follow strict FIFO arrival order
        Triage equalTriage = new Triage();
        equalTriage.admitPatient("First", 3);
        equalTriage.admitPatient("Second", 3);
        equalTriage.admitPatient("Third", 3);
        verify("First(S3) Second(S3) Third(S3)".equals(equalTriage.formatTreatmentOrder()),
                "Equal-severity patients follow strict FIFO arrival sequence");

        // 3. Invalid input tests: severity 0, severity 6, blank name
        try {
            equalTriage.admitPatient("InvalidLow", 0);
            verify(false, "Severity 0 should throw IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            System.out.println("[PASS] Severity 0 caught cleanly: " + ex.getMessage());
        }

        try {
            equalTriage.admitPatient("InvalidHigh", 6);
            verify(false, "Severity 6 should throw IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            System.out.println("[PASS] Severity 6 caught cleanly: " + ex.getMessage());
        }

        try {
            equalTriage.admitPatient("  ", 2);
            verify(false, "Blank patient name should throw IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            System.out.println("[PASS] Blank patient name caught cleanly: " + ex.getMessage());
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println("==========================================================================");
        System.out.println("Q6 DEMONSTRATION: QUEUE AND PRIORITYQUEUE");
        System.out.println("Problem: Hospital Emergency Triage");
        System.out.println("==========================================================================");

        System.out.println("Sample Inputs:");
        System.out.println("  Admissions: Ravi(S3), Asha(S5), Meena(S1), Lata(S2), John(S3), Kumar(S1)");
        System.out.println("Expected Treatment Order: Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)");

        System.out.println("\n--- Executing Triage Demo ---");
        Triage.main(args);

        runBoundaryAndErrorTests();

        System.out.println("\n--- Executing Full Q6 Benchmark & CSV Export ---");
        TriageBenchmark.main(args);
    }
}
