package parking.model;

import java.time.LocalDate;

/**
 * Monthly parking pass for campus Students and Staff.
 * Valid Student and Staff monthly passes grant free parking (Rs 0.0 base parking fee).
 */
public class MonthlyPass extends ParkingPass {

    public enum PassCategory {
        STUDENT("Student Monthly Pass"),
        STAFF("Staff Monthly Pass");

        private final String label;

        PassCategory(String label) {
            this.label = label;
        }

        public String getLabel() {
            return label;
        }
    }

    private final PassCategory category;

    public MonthlyPass(PassCategory category, String holderId, String holderName,
                       String vehicleRegistrationNumber) {
        this(category, holderId, holderName, vehicleRegistrationNumber, LocalDate.now(),
                LocalDate.now().plusMonths(1));
    }

    public MonthlyPass(PassCategory category, String holderId, String holderName,
                       String vehicleRegistrationNumber, LocalDate issueDate, LocalDate expiryDate) {
        super(category == PassCategory.STUDENT ? "MP-STU" : "MP-STF",
                holderId,
                holderName,
                vehicleRegistrationNumber,
                issueDate,
                expiryDate,
                category == PassCategory.STUDENT
                        ? PricingConfig.getStudentMonthlyPassPrice()
                        : PricingConfig.getStaffMonthlyPassPrice());
        this.category = category;
    }

    public PassCategory getCategory() {
        return category;
    }

    public void renewForMonths(int months) {
        if (months > 0) {
            LocalDate base = LocalDate.now().isAfter(getExpiryDate()) ? LocalDate.now() : getExpiryDate();
            setExpiryDate(base.plusMonths(months));
        }
    }

    @Override
    public String getPassTypeName() {
        return category.getLabel();
    }

    @Override
    public double applyToParkingFee(double baseParkingFee) {
        if (isValid()) {
            return 0.0;
        }
        return baseParkingFee;
    }
}
