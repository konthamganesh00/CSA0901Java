# Q7 – Day-4 Design Challenge: Eliminating Quadratic String Concatenation in Railway Ticketing

## A. Diagnose the Bottleneck

### 1. Slow Operation Identified
In **Q1 (`StringBenchmark.java`)**, constructing multi-field railway e-tickets (50 fields per ticket across 10,000 tickets) and building consolidated reservation charts (3,000 rows concatenated into one output `String`) using the `+` operator inside loops is severely bottlenecked.

### 2. Root Cause
In Java, `String` is **immutable**. Every execution of `ticket = ticket + ";F" + f + "=" + val` inside a loop:
1. Allocates a temporary `StringBuilder` (or `StringConcatFactory` call) for that single iteration.
2. Copies all characters accumulated from previous iterations (`0 .. i-1`) plus the new field into a brand-new `String` (`byte[]`).
3. Discards the previous `String`, creating garbage-collection (GC) pressure.

For $k$ loop iterations of average append length $c$, the total character copies grow quadratically:
$$\sum_{i=1}^{k} i \cdot c = \frac{c \cdot k(k+1)}{2} = \Theta(k^2)$$

### 3. Evidence Protocol (From Q1 Measurements)
Run `Q1.StringBenchmark` locally and inspect `ExperimentalData/Q1_StringBenchmark.csv` to confirm:
- **10,000 tickets × 50 fields:** `String (+)` creates ~490,000 intermediate `String` objects, whereas `StringBuilder` creates only 1 final `String` per ticket.
- **3,000-entry reservation chart:** `String (+)` exhibits quadratic slow-down as the accumulated chart grows across all 3,000 rows.

*(Insert your locally measured Q1 CSV averages in `AssignmentReport.md` after running `Q1.StringBenchmark`.)*

---

## B. Define the Design Objective

1. **Improvement Required:** Replace repeated immutable `String (+)` loop concatenation with a linear-time, allocation-minimal mutable buffer design.
2. **Measurable Objectives:**
   - **Asymptotic Complexity:** Reduce construction complexity from **$O(k^2)$** to **$O(k)$** in the number of fields/entries $k$.
   - **Latency Target:** Achieve **$\ge 90\%$ reduction** in average execution time on the 10,000-ticket batch and 3,000-entry consolidated chart workloads.
   - **Allocation Target:** Eliminate **$\ge 99\%$** of intermediate `String` object allocations (0 intermediate `String`s inside the loop; 0 buffer reallocations when pre-sized).
   - **Correctness Constraint:** Output must remain byte-for-byte identical (`original.equals(redesigned) == true`).

---

## C. Design the Revised Solution

### 1. Original Solution vs. Redesigned Solution
- **Original (`Original_StringPlus`):** Uses `String acc = ...; for (...) { acc = acc + ...; }`.
- **Redesigned (`Redesigned_PreSizedSB`):** Uses a **capacity-tuned `StringBuilder`** (`new StringBuilder(estimatedCapacity)`) computed from `fieldCount * 18` (for tickets) or `32 + entryCount * 72` (for charts). Pre-sizing eliminates even the internal `Arrays.copyOf` doubling steps (`16 -> 34 -> 70 -> ...`) inside `StringBuilder`.

### 2. Pseudocode
```text
FUNCTION buildChartRedesigned(entryCount):
    estimatedCapacity <- 32 + entryCount * 72
    buffer <- NEW StringBuilder(estimatedCapacity)
    buffer.append("=== RESERVATION CHART ===\n")
    FOR i FROM 0 TO entryCount - 1:
        buffer.append("PNR:").append(4500000000 + i)
              .append(",Name:").append(PASSENGERS[i mod len])
              .append(",Coach:").append(COACHES[i mod len])
              .append(",Berth:").append(BERTHS[i mod len])
              .append(",Fare:1450.00\n")
    END FOR
    RETURN buffer.toString()
END FUNCTION
```

### 3. Class / Component Diagram
```text
+-----------------------------------+         uses         +----------------------------------+
|        RedesignComparison         | -------------------> |    Original_StringPlus (O(k^2))  |
|-----------------------------------|                      | - String loop concatenation '+'  |
| + verifyIdenticalOutputs()        |                      | - High intermediate allocations  |
| + runBenchmark()                  |         uses         +----------------------------------+
| + writeCsv()                      | -------------------> | Redesigned_PreSizedSB (O(k))     |
+-----------------------------------+                      | - Pre-sized StringBuilder(cap)   |
                                                           | - Single final toString()        |
                                                           +----------------------------------+
```

### 4. Trade-offs
- **Memory Reservation vs. Resizing:** Pre-sizing allocates the full estimated `byte[]` upfront. Overestimating slightly wastes unused tail bytes; underestimating triggers a single resize.
- **Mutability & Thread Safety:** `StringBuilder` is mutable and **not thread-safe**. If multiple threads concurrently write to a single shared chart, use thread-local `StringBuilder` instances or `StringBuffer` / synchronized logging.

---

## D. Predict Before Implementing

- **Expected Speedup:**
  - On `10,000 tickets × 50 fields`, we predict a **10x–40x speedup** because 49 intermediate `String` allocations per ticket are eliminated.
  - On `3,000-entry consolidated chart`, we predict a **100x+ speedup** because `O(k^2)` full-buffer copies vanish completely.
- **Metrics to Measure:**
  1. Average execution time (`ns` and `ms`) across 5 measured iterations after 3 JIT warmup runs.
  2. Speedup factor (`Original_ms / Redesigned_ms`) and percentage latency saved.
  3. Approximate heap delta (`ApproxMemoryBytes`).
  4. Output checksum & exact string equality.

---

## E. Implement and Validate

`Q7/RedesignComparison.java` executes both designs against identical deterministic inputs across three workloads:
1. `Batch_1000x50` (1,000 tickets × 50 fields)
2. `Batch_10000x50` (10,000 tickets × 50 fields)
3. `Chart_3000Entries` (3,000-row consolidated chart)

Raw per-iteration numbers are written directly to `ExperimentalData/Q7_RedesignBenchmark.csv` when executed locally on Java 21.

---

## F. Defend the Final Design

1. **Objective Attainment:** Once executed locally, compare `Saved %` against the $\ge 90\%$ latency target and verify `Original.equals(Redesigned) == true`. Because loop complexity drops from $O(k^2)$ to $O(k)$ and pre-sizing avoids buffer reallocation, the redesign scales linearly even as ticket fields or chart rows grow 10x.
2. **Trade-off Justification:** A minor capacity calculation (`fieldCount * 18`) costs negligible CPU while saving megabytes of short-lived heap garbage.
3. **When the Original `String (+)` Remains Useful:**
   - **Compile-time constants** (e.g., `"PNR:" + "4123"`), which `javac` folds into a single literal at compile time.
   - **Single-expression concatenation outside loops** (e.g., `"PNR:" + pnr + "|Coach:" + coach`), where Java 9+ `invokedynamic` (`StringConcatFactory`) computes exact length in one pass without developer boilerplate and produces cleaner, more readable code.
   - **Immutable shared constants/keys** passed safely across threads without defensive copying.
