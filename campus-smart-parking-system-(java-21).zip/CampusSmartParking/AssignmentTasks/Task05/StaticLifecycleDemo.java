/**
 * Task 05 - Static Ticket Counter, Total Occupancy, Static Methods,
 * Static Initializer Block, and Object Lifecycle / Garbage Collection Demo.
 */
public class StaticLifecycleDemo {

    static class Ticket {
        private static int ticketCounter;
        private static int activeOccupancy;
        private static final String PREFIX;

        // Static initializer block runs once when class is loaded into JVM
        static {
            ticketCounter = 1000;
            activeOccupancy = 0;
            PREFIX = "TKT";
            System.out.println("[Static Block] Ticket class loaded. Counter initialized at " + ticketCounter);
        }

        private final String ticketId;
        private final String regNo;
        private boolean active;

        public Ticket(String regNo) {
            this.ticketId = PREFIX + "-" + (++ticketCounter);
            this.regNo = regNo;
            this.active = true;
            activeOccupancy++;
        }

        public void closeTicket() {
            if (active) {
                active = false;
                activeOccupancy--;
            }
        }

        public static int getTotalTicketsGenerated() {
            return ticketCounter - 1000;
        }

        public static int getActiveOccupancy() {
            return activeOccupancy;
        }

        @Override
        public String toString() {
            return ticketId + " (" + regNo + ", active=" + active + ")";
        }
    }

    public static void main(String[] args) {
        Ticket t1 = new Ticket("TN01AA1111");
        Ticket t2 = new Ticket("TN01BB2222");
        System.out.println("Issued: " + t1 + ", " + t2);
        System.out.println("Total Tickets Generated: " + Ticket.getTotalTicketsGenerated());
        System.out.println("Current Occupancy      : " + Ticket.getActiveOccupancy());

        // Vehicle exits; ticket closed and reference cleared for GC eligibility
        t1.closeTicket();
        t1 = null; // Heap object previously referenced by t1 is now eligible for Garbage Collection

        System.out.println("After t1 exit -> Occupancy: " + Ticket.getActiveOccupancy());
        System.out.println("Total Tickets Ever Issued : " + Ticket.getTotalTicketsGenerated());
    }
}
