# TASK 9 – Abstraction

## 1. Abstract Class vs Interface in Campus Smart-Parking
- **Abstract `Vehicle` Class (`parking.model.Vehicle`)**:
  - Cannot be instantiated directly (`new Vehicle(...)` is illegal).
  - Holds shared state (`registrationNumber`, `ownerName`, `contactNumber`, `vehicleType`) and shared concrete behaviour (`calculateFee(int)`, `equals()`, `hashCode()`).
  - Declares `public abstract double ratePerHour();` so every concrete vehicle subclass MUST define its hourly rate.
- **`Chargeable` & `PassHolder` Interfaces**:
  - Define orthogonal capabilities independent of the inheritance tree ("can-do" contracts).
  - Java allows a class to extend only one superclass (`ElectricCar extends Car`) while implementing multiple interfaces (`implements Chargeable` or `ParkingUser implements PassHolder`).
  - `Chargeable` includes:
    - Abstract methods: `chargingFee()`, `isChargingRequested()`, `setChargingRequested(boolean)`.
    - **`default` method**: `getChargingStandardInfo()` (backward-compatible helper).
    - **`static` method**: `Chargeable.supportsCharging(Vehicle)` (utility check).

## 2. Why Both Abstract Classes and Interfaces Are Used
| Feature | Abstract Class (`Vehicle`, `ParkingPass`) | Interface (`Chargeable`, `PassHolder`) |
|---|---|---|
| Shared State (Instance Fields) | Yes (e.g., `registrationNumber`, `passId`) | No (only `public static final` constants) |
| Constructors | Yes (chained via `super(...)`) | No |
| Multiple Inheritance | Single class inheritance only | A class can implement many interfaces |
| Design Role | Core **"IS-A"** family identity | Cross-cutting **"CAN-DO"** capability |
