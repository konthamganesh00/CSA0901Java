import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Task 10 - Encapsulation, Validation Rules, and Access Modifiers Demonstration.
 */
public class ValidationAndAccessDemo {

    static class EncapsulatedParkingRecord {
        private String regNo;           // private: only accessible inside this class
        int floorNumber;                // default (package-private): accessible within same package
        protected int slotNumber;       // protected: package + subclasses
        public final String facility;   // public: accessible everywhere

        public EncapsulatedParkingRecord(String facility) {
            this.facility = facility;
        }

        public void setRegistrationNumber(String regNo) {
            if (regNo == null || !regNo.trim().toUpperCase().matches("^[A-Z0-9-]{4,15}$")) {
                throw new IllegalArgumentException("Invalid registration number: " + regNo);
            }
            this.regNo = regNo.trim().toUpperCase();
        }

        public String getRegistrationNumber() {
            return regNo;
        }

        public void setSlotLocation(int floor, int slot, int maxFloors, int maxSlotsOnFloor) {
            if (floor < 1 || floor > maxFloors) {
                throw new IllegalArgumentException("Invalid floor number: " + floor);
            }
            if (slot < 1 || slot > maxSlotsOnFloor) {
                throw new IllegalArgumentException("Invalid slot number: " + slot);
            }
            this.floorNumber = floor;
            this.slotNumber = slot;
        }

        public static int validateDurationMinutes(LocalDateTime entry, LocalDateTime exit) {
            if (entry == null || exit == null || exit.isBefore(entry)) {
                throw new IllegalArgumentException("Exit time cannot precede entry time.");
            }
            long mins = java.time.Duration.between(entry, exit).toMinutes();
            return (int) Math.max(1, mins);
        }

        public static double validateFee(double fee) {
            if (fee < 0.0 || Double.isNaN(fee)) {
                throw new IllegalArgumentException("Parking fee cannot be negative or NaN.");
            }
            return fee;
        }

        public static boolean validatePassExpiry(LocalDate expiryDate, boolean active) {
            return active && expiryDate != null && !LocalDate.now().isAfter(expiryDate);
        }
    }

    public static void main(String[] args) {
        EncapsulatedParkingRecord rec = new EncapsulatedParkingRecord("Main Campus Deck");
        rec.setRegistrationNumber("tn01ab1234");
        rec.setSlotLocation(1, 5, 5, 10);

        System.out.println("Validated RegNo  : " + rec.getRegistrationNumber());
        System.out.println("Validated Slot   : F" + rec.floorNumber + "-S" + rec.slotNumber);
        System.out.println("Validated Fee    : Rs " + EncapsulatedParkingRecord.validateFee(90.0));
        System.out.println("Pass Valid Today : " + EncapsulatedParkingRecord.validatePassExpiry(LocalDate.now().plusDays(10), true));

        try {
            rec.setRegistrationNumber("@@");
        } catch (IllegalArgumentException e) {
            System.out.println("Caught expected invalid regNo: " + e.getMessage());
        }
    }
}
