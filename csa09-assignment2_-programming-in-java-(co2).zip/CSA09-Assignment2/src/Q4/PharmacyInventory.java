package Q4;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * Q4 - Hospital Pharmacy Inventory
 * Demonstrates HashMap, TreeMap, and LinkedHashMap side by side:
 *   - Add medicine
 *   - Search by medicine code
 *   - Update quantity
 *   - Delete medicine
 *   - Display medicines in code order (TreeMap)
 *   - Display medicines in insertion order (LinkedHashMap)
 */
public class PharmacyInventory {

    private final Map<String, Medicine> hashInventory = new HashMap<>();
    private final Map<String, Medicine> treeInventory = new TreeMap<>();
    private final Map<String, Medicine> linkedInventory = new LinkedHashMap<>();

    public void addMedicine(Medicine med) {
        if (med == null) {
            throw new IllegalArgumentException("Medicine record cannot be null.");
        }
        hashInventory.put(med.getCode(), med);
        treeInventory.put(med.getCode(), med);
        linkedInventory.put(med.getCode(), med);
    }

    public Medicine searchByCode(String code) {
        if (code == null) {
            return null;
        }
        return hashInventory.get(code);
    }

    public boolean updateQuantity(String code, int newQuantity) {
        if (newQuantity < 0) {
            throw new IllegalArgumentException("Updated quantity cannot be negative: " + newQuantity);
        }
        Medicine med = searchByCode(code);
        if (med == null) {
            return false;
        }
        med.setQuantity(newQuantity);
        return true;
    }

    public boolean deleteMedicine(String code) {
        if (code == null) {
            return false;
        }
        Medicine removed = hashInventory.remove(code);
        treeInventory.remove(code);
        linkedInventory.remove(code);
        return removed != null;
    }

    public int size() {
        return hashInventory.size();
    }

    public void displayInCodeOrder() {
        System.out.println("\n--- Medicines in Sorted Code Order (TreeMap) ---");
        for (Medicine med : treeInventory.values()) {
            System.out.println("  " + med);
        }
    }

    public void displayInInsertionOrder() {
        System.out.println("\n--- Medicines in Insertion Order (LinkedHashMap) ---");
        for (Medicine med : linkedInventory.values()) {
            System.out.println("  " + med);
        }
    }

    public void displayHashBucketOrder() {
        System.out.println("\n--- Medicines in HashMap Order (Unordered / Hash-based) ---");
        for (Medicine med : hashInventory.values()) {
            System.out.println("  " + med);
        }
    }

    /**
     * Brief comparison showing Arrays.binarySearch() on sorted codes.
     */
    public static void demonstrateSortedArrayLookup(String[] sortedCodes, String targetCode) {
        int idx = Arrays.binarySearch(sortedCodes, targetCode);
        System.out.println("Arrays.binarySearch(\"" + targetCode + "\") -> index " + idx);
    }

    public static void main(String[] args) {
        System.out.println("==========================================================================");
        System.out.println("Q4: Hospital Pharmacy Inventory (HashMap vs TreeMap vs LinkedHashMap)");
        System.out.println("==========================================================================");

        PharmacyInventory inventory = new PharmacyInventory();

        // Add medicines in non-alphabetical insertion order
        inventory.addMedicine(new Medicine("MED305", "Amoxicillin 250mg", 120, 85.50));
        inventory.addMedicine(new Medicine("MED101", "Paracetamol 500mg", 500, 18.00));
        inventory.addMedicine(new Medicine("MED412", "Insulin Glargine", 40, 620.00));
        inventory.addMedicine(new Medicine("MED204", "Cetirizine 10mg", 240, 22.00));
        inventory.addMedicine(new Medicine("MED150", "Azithromycin 500mg", 90, 115.00));

        // Display in insertion order vs sorted code order vs hash order
        inventory.displayInInsertionOrder();
        inventory.displayInCodeOrder();
        inventory.displayHashBucketOrder();

        // Search by medicine code
        System.out.println("\n--- Search & Update Operations ---");
        Medicine found = inventory.searchByCode("MED204");
        System.out.println("Search MED204: " + (found != null ? found : "Not found"));

        // Update quantity
        boolean updated = inventory.updateQuantity("MED204", 310);
        System.out.println("Updated MED204 quantity to 310: " + updated);
        System.out.println("After update : " + inventory.searchByCode("MED204"));

        // Delete medicine
        boolean deleted = inventory.deleteMedicine("MED412");
        System.out.println("Deleted MED412: " + deleted);

        inventory.displayInCodeOrder();

        // Sorted array binarySearch demonstration
        System.out.println("\n--- Sorted Array + Arrays.binarySearch() Comparison ---");
        String[] sortedCodes = {"MED101", "MED150", "MED204", "MED305"};
        demonstrateSortedArrayLookup(sortedCodes, "MED204");
    }
}
