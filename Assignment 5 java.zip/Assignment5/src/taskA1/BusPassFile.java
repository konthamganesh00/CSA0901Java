
package taskA1;

import java.io.*;

public class BusPassFile {

    public static void main(String[] args) {

        String fileName = "buspasses.txt";

        try {
            // Add bus pass records
            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(fileName));

            writer.write("P1001,192311001,Arun,12,MainGate,2027-03-31,4500");
            writer.newLine();

            writer.write("P1002,192311002,Divya,7,Library,2027-03-31,3800");
            writer.newLine();

            writer.close();

            System.out.println("Bus passes added successfully!");

            // Read and display all records
            BufferedReader reader = new BufferedReader(
                    new FileReader(fileName));

            String line;

            System.out.println("\nBus Pass Records:");

            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");

                if (data.length == 7) {
                    System.out.println(line);
                } else {
                    System.out.println("Damaged record skipped");
                }
            }

            reader.close();

            // Search pass by ID
            reader = new BufferedReader(new FileReader(fileName));

            String searchID = "P1002";
            boolean found = false;

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",");

                if (data.length == 7 && data[0].equals(searchID)) {
                    System.out.println("\nPass Found: " + line);
                    found = true;
                    break;
                }
            }

            reader.close();

            if (!found) {
                System.out.println("\nPass Not Found");
            }

        } catch (IOException e) {
            System.out.println("File Error: " + e.getMessage());
        }
    }
}
