
package taskA4;

import java.io.*;
import java.util.ArrayList;

public class Hostel implements Serializable {

    private static final long serialVersionUID = 1L;

    ArrayList<Room> rooms = new ArrayList<>();

    public void addRoom(Room r) {
        rooms.add(r);
    }

    public static void main(String[] args) {

        Hostel hostel = new Hostel();

        Room room = new Room(101);

        room.addResident(
                new Resident("Arun", "192311001", "12345"));

        room.addResident(
                new Resident("Divya", "192311002", "67890"));

        hostel.addRoom(room);

        // Serialize hostel object
        try {
            ObjectOutputStream out = new ObjectOutputStream(
                    new FileOutputStream("hostel.dat"));

            out.writeObject(hostel);
            out.close();

            System.out.println("Hostel data saved successfully!");

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        // Deserialize hostel object
        try {
            ObjectInputStream in = new ObjectInputStream(
                    new FileInputStream("hostel.dat"));

            Hostel loaded = (Hostel) in.readObject();
            in.close();

            System.out.println("\nHostel data loaded successfully!");

            for (Room r : loaded.rooms) {
                System.out.println(r);
            }

        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
