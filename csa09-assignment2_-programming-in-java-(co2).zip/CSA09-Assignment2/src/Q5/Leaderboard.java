package Q5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/**
 * Q5 - Generic Leaderboard<T> supporting Generics, Wildcards, Bounded Types,
 * Comparator sorting, and List.sort() / Collections.sort().
 */
public class Leaderboard<T> {

    private final List<T> entries = new ArrayList<>();

    public void addEntry(T entry) {
        entries.add(Objects.requireNonNull(entry, "Leaderboard entry cannot be null."));
    }

    /**
     * Upper-bounded wildcard (? extends T): accepts a List of T or any subtype of T.
     */
    public void addAll(List<? extends T> newEntries) {
        Objects.requireNonNull(newEntries, "Entries list cannot be null.");
        for (T entry : newEntries) {
            addEntry(entry);
        }
    }

    /**
     * Lower-bounded wildcard (? super T): accepts any Comparator for T or a supertype of T.
     */
    public void sortWith(Comparator<? super T> comparator) {
        Objects.requireNonNull(comparator, "Comparator cannot be null.");
        entries.sort(comparator);
    }

    /**
     * Lower-bounded wildcard (? super T): safely exports entries into a wider target list.
     */
    public void copyStandingsTo(List<? super T> destination) {
        Objects.requireNonNull(destination, "Destination list cannot be null.");
        destination.addAll(entries);
    }

    public List<T> getEntries() {
        return Collections.unmodifiableList(entries);
    }

    /**
     * Bounded type parameter (<U extends Comparable<? super U>>):
     * sorts a copy of any list whose element type defines a natural ordering.
     */
    public static <U extends Comparable<? super U>> List<U> sortNaturally(List<U> items) {
        List<U> copy = new ArrayList<>(items);
        Collections.sort(copy);
        return copy;
    }

    /**
     * Bounded wildcard print helper (<?>).
     */
    public static void printStandings(String title, List<?> standings) {
        System.out.println(title + ": " + standings);
    }
}
