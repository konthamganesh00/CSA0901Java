package parking.service;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import parking.model.Chargeable;
import parking.model.DeliveryVan;
import parking.model.EBike;
import parking.model.MonthlyPass;
import parking.model.OneDayPass;
import parking.model.ParkingPass;
import parking.model.PricingConfig;
import parking.model.Vehicle;

/**
 * Centralised parking fee calculation engine.
 *
 * <p>Implements ceiling-based integer arithmetic for started hours:
 * {@code billedHours = (int) ((totalMinutes + 59) / 60)}.
 * Supports vehicle-specific rates, DeliveryVan 9 AM - 5 PM double rate,
 * EV charging fees, daily maximum fee cap, and pass rules.
 */
public class FeeCalculator {

    /**
     * Immutable breakdown of a fee computation.
     */
    public record FeeBreakdown(
            int billedHours,
            double rawParkingFee,
            double adjustedParkingFee,
            double chargingFee,
            double finalTotalFee,
            String passNote
    ) {
    }

    /**
     * Calculates billed hours by charging every started hour in full using ceiling integer arithmetic.
     * Avoids integer division truncation errors such as {@code 61 / 60 == 1}.
     *
     * @param entryTime entry timestamp
     * @param exitTime  exit timestamp
     * @return billed hours (minimum 1 when entry and exit are valid)
     */
    public int calculateBilledHours(LocalDateTime entryTime, LocalDateTime exitTime) {
        if (entryTime == null || exitTime == null) {
            throw new IllegalArgumentException("Entry and exit timestamps must not be null.");
        }
        if (exitTime.isBefore(entryTime)) {
            throw new IllegalArgumentException("Exit time cannot be earlier than entry time.");
        }
        long totalMinutes = Duration.between(entryTime, exitTime).toMinutes();
        if (totalMinutes <= 0) {
            return 1; // Any valid entry-exit visit bills at least 1 started hour
        }
        return (int) ((totalMinutes + 59L) / 60L);
    }

    /**
     * Compile-time overloaded fee calculation for a known number of hours (no pass).
     */
    public double calculateFee(Vehicle vehicle, int hours) {
        if (vehicle == null || hours <= 0) {
            return 0.0;
        }
        double total = vehicle.calculateFee(hours);
        if (PricingConfig.isDailyMaxCapEnabled()) {
            total = Math.min(total, PricingConfig.getDailyMaxFeeCap());
        }
        return total;
    }

    /**
     * Compile-time overloaded fee calculation from entry/exit timestamps (no pass).
     */
    public double calculateFee(Vehicle vehicle, LocalDateTime entryTime, LocalDateTime exitTime) {
        return calculateFeeBreakdown(vehicle, entryTime, exitTime, null).finalTotalFee();
    }

    /**
     * Compile-time overloaded fee calculation from entry/exit timestamps with optional pass.
     */
    public double calculateFee(Vehicle vehicle, LocalDateTime entryTime, LocalDateTime exitTime, ParkingPass pass) {
        return calculateFeeBreakdown(vehicle, entryTime, exitTime, pass).finalTotalFee();
    }

    /**
     * Computes a complete itemised breakdown of parking fee, EV charging fee, and pass adjustments.
     */
    public FeeBreakdown calculateFeeBreakdown(Vehicle vehicle, LocalDateTime entryTime,
                                              LocalDateTime exitTime, ParkingPass pass) {
        if (vehicle == null) {
            throw new IllegalArgumentException("Vehicle must not be null.");
        }
        int billedHours = calculateBilledHours(entryTime, exitTime);

        double rawParkingFee;
        double chargingFee = 0.0;

        if (vehicle instanceof DeliveryVan van) {
            rawParkingFee = van.calculateFee(entryTime, exitTime);
        } else if (vehicle instanceof EBike ebike) {
            rawParkingFee = ebike.calculateFee(billedHours);
        } else if (vehicle instanceof Chargeable chargeableVehicle) {
            rawParkingFee = billedHours * vehicle.ratePerHour();
            chargingFee = chargeableVehicle.chargingFee();
        } else {
            rawParkingFee = vehicle.calculateFee(billedHours);
        }

        if (PricingConfig.isDailyMaxCapEnabled()) {
            rawParkingFee = Math.min(rawParkingFee, PricingConfig.getDailyMaxFeeCap());
        }

        double adjustedParkingFee = rawParkingFee;
        String passNote = "No Pass (Standard Rate)";

        if (pass != null) {
            LocalDate checkDate = exitTime.toLocalDate();
            boolean validForVisit = pass.isValidOn(checkDate)
                    && (pass.getVehicleRegistrationNumber().isEmpty()
                    || pass.getVehicleRegistrationNumber().equalsIgnoreCase(vehicle.getRegistrationNumber()));

            if (validForVisit) {
                if (pass instanceof MonthlyPass monthlyPass) {
                    adjustedParkingFee = monthlyPass.applyToParkingFee(rawParkingFee);
                    passNote = monthlyPass.getPassTypeName() + " (" + monthlyPass.getPassId() + ") - Free Parking";
                } else if (pass instanceof OneDayPass oneDayPass) {
                    adjustedParkingFee = oneDayPass.applyToParkingFee(rawParkingFee);
                    passNote = oneDayPass.getPassTypeName() + " (" + oneDayPass.getPassId() + ") - Covered by Day Pass";
                } else {
                    adjustedParkingFee = pass.applyToParkingFee(rawParkingFee);
                    passNote = pass.getPassTypeName() + " (" + pass.getPassId() + ")";
                }
            } else {
                passNote = "Pass Invalid/Expired/Mismatched - Full Fee Applied";
            }
        }

        double finalTotalFee = adjustedParkingFee + chargingFee;
        return new FeeBreakdown(billedHours, rawParkingFee, adjustedParkingFee, chargingFee, finalTotalFee, passNote);
    }
}
