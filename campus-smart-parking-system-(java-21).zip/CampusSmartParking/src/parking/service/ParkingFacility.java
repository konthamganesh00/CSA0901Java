package parking.service;

import java.util.ArrayList;
import java.util.List;
import parking.exception.InvalidSlotException;
import parking.exception.ParkingFullException;
import parking.model.ParkingSlot;
import parking.model.Vehicle;

/**
 * Manages multi-floor campus parking using a jagged 2D array of {@link ParkingSlot} objects.
 * Supports uniform configurations (1x20, 3x50, 5x100) as well as variable capacities per floor.
 */
public class ParkingFacility {

    private static int globalActiveOccupancy = 0;

    private final ParkingSlot[][] floorSlots; // Jagged array: floorSlots[floorIndex][slotIndex]
    private final int totalCapacity;
    private int currentOccupancy;

    /**
     * Default constructor creating the Day-4 5-floor jagged configuration:
     * Floor 1: 10 slots, Floor 2: 15 slots, Floor 3: 20 slots, Floor 4: 25 slots, Floor 5: 30 slots.
     */
    public ParkingFacility() {
        this(new int[]{10, 15, 20, 25, 30});
    }

    /**
     * Uniform capacity constructor (e.g., 1 floor x 20, 3 floors x 50, 5 floors x 100).
     *
     * @param numFloors        number of floors
     * @param slotsPerFloor    slots on each floor
     */
    public ParkingFacility(int numFloors, int slotsPerFloor) {
        this(createUniformCapacities(numFloors, slotsPerFloor));
    }

    /**
     * Jagged-array constructor accepting different slot capacities for each floor.
     *
     * @param floorCapacities array where floorCapacities[i] is the slot count on floor i+1
     */
    public ParkingFacility(int[] floorCapacities) {
        if (floorCapacities == null || floorCapacities.length == 0) {
            throw new IllegalArgumentException("At least one parking floor is required.");
        }
        this.floorSlots = new ParkingSlot[floorCapacities.length][];
        int capacitySum = 0;
        for (int f = 0; f < floorCapacities.length; f++) {
            int cap = floorCapacities[f];
            if (cap <= 0) {
                throw new IllegalArgumentException("Floor " + (f + 1) + " capacity must be positive.");
            }
            this.floorSlots[f] = new ParkingSlot[cap];
            for (int s = 0; s < cap; s++) {
                this.floorSlots[f][s] = new ParkingSlot(f + 1, s + 1);
            }
            capacitySum += cap;
        }
        this.totalCapacity = capacitySum;
        this.currentOccupancy = 0;
    }

    private static int[] createUniformCapacities(int numFloors, int slotsPerFloor) {
        if (numFloors <= 0 || slotsPerFloor <= 0) {
            throw new IllegalArgumentException("Floors and slots per floor must be positive.");
        }
        int[] caps = new int[numFloors];
        for (int i = 0; i < numFloors; i++) {
            caps[i] = slotsPerFloor;
        }
        return caps;
    }

    /**
     * Finds and allocates the first available slot across floors in row-major order.
     *
     * @param vehicle  vehicle to park
     * @param ticketId ticket ID associated with this parking session
     * @return 2-element array {@code {floorIndex, slotIndex}} (0-based)
     * @throws ParkingFullException if every slot on every floor is occupied
     */
    public synchronized int[] allocateFirstAvailableSlot(Vehicle vehicle, String ticketId)
            throws ParkingFullException {
        if (vehicle == null) {
            throw new IllegalArgumentException("Cannot allocate slot for null vehicle.");
        }
        for (int f = 0; f < floorSlots.length; f++) {
            for (int s = 0; s < floorSlots[f].length; s++) {
                if (!floorSlots[f][s].isOccupied()) {
                    floorSlots[f][s].occupy(vehicle, ticketId);
                    currentOccupancy++;
                    globalActiveOccupancy++;
                    return new int[]{f, s};
                }
            }
        }
        throw new ParkingFullException("Parking facility is completely full (" + totalCapacity + " slots occupied).");
    }

    /**
     * Allocates a specific floor and slot (0-based indices) if valid and unoccupied.
     *
     * @param floorIndex 0-based floor index
     * @param slotIndex  0-based slot index
     * @param vehicle    vehicle to park
     * @param ticketId   associated ticket ID
     * @return allocated {@link ParkingSlot}
     * @throws InvalidSlotException if coordinates are out of bounds or slot is already occupied
     */
    public synchronized ParkingSlot allocateSpecificSlot(int floorIndex, int slotIndex,
                                                         Vehicle vehicle, String ticketId)
            throws InvalidSlotException {
        validateCoordinates(floorIndex, slotIndex);
        ParkingSlot slot = floorSlots[floorIndex][slotIndex];
        if (slot.isOccupied()) {
            throw new InvalidSlotException("Slot " + slot.getSlotCode() + " is already occupied.");
        }
        slot.occupy(vehicle, ticketId);
        currentOccupancy++;
        globalActiveOccupancy++;
        return slot;
    }

    /**
     * Releases the slot at the specified 0-based coordinates.
     *
     * @param floorIndex 0-based floor index
     * @param slotIndex  0-based slot index
     * @return vacated vehicle
     * @throws InvalidSlotException if coordinates are invalid or slot is not occupied
     */
    public synchronized Vehicle releaseSlot(int floorIndex, int slotIndex) throws InvalidSlotException {
        validateCoordinates(floorIndex, slotIndex);
        ParkingSlot slot = floorSlots[floorIndex][slotIndex];
        if (!slot.isOccupied()) {
            throw new InvalidSlotException("Slot " + slot.getSlotCode() + " is already empty.");
        }
        Vehicle removed = slot.vacate();
        if (currentOccupancy > 0) {
            currentOccupancy--;
        }
        if (globalActiveOccupancy > 0) {
            globalActiveOccupancy--;
        }
        return removed;
    }

    public boolean isValidCoordinate(int floorIndex, int slotIndex) {
        return floorIndex >= 0
                && floorIndex < floorSlots.length
                && slotIndex >= 0
                && slotIndex < floorSlots[floorIndex].length;
    }

    private void validateCoordinates(int floorIndex, int slotIndex) throws InvalidSlotException {
        if (!isValidCoordinate(floorIndex, slotIndex)) {
            throw new InvalidSlotException(
                    String.format("Invalid slot coordinate: floor=%d, slot=%d", floorIndex + 1, slotIndex + 1));
        }
    }

    public ParkingSlot getSlot(int floorIndex, int slotIndex) throws InvalidSlotException {
        validateCoordinates(floorIndex, slotIndex);
        return floorSlots[floorIndex][slotIndex];
    }

    public int getFloorCount() {
        return floorSlots.length;
    }

    public int getFloorCapacity(int floorIndex) {
        if (floorIndex < 0 || floorIndex >= floorSlots.length) {
            return 0;
        }
        return floorSlots[floorIndex].length;
    }

    public int[] getFloorCapacities() {
        int[] capacities = new int[floorSlots.length];
        for (int i = 0; i < floorSlots.length; i++) {
            capacities[i] = floorSlots[i].length;
        }
        return capacities;
    }

    public int getTotalCapacity() {
        return totalCapacity;
    }

    public int getCurrentOccupancy() {
        return currentOccupancy;
    }

    public int getAvailableCount() {
        return totalCapacity - currentOccupancy;
    }

    public boolean isFull() {
        return currentOccupancy >= totalCapacity;
    }

    public static int getGlobalActiveOccupancy() {
        return globalActiveOccupancy;
    }

    public static void decrementGlobalOccupancyOnReset(int count) {
        globalActiveOccupancy = Math.max(0, globalActiveOccupancy - count);
    }

    public List<ParkingSlot> getAvailableSlots() {
        List<ParkingSlot> available = new ArrayList<>();
        for (ParkingSlot[] floor : floorSlots) {
            for (ParkingSlot slot : floor) {
                if (!slot.isOccupied()) {
                    available.add(slot);
                }
            }
        }
        return available;
    }

    public List<ParkingSlot> getOccupiedSlots() {
        List<ParkingSlot> occupied = new ArrayList<>();
        for (ParkingSlot[] floor : floorSlots) {
            for (ParkingSlot slot : floor) {
                if (slot.isOccupied()) {
                    occupied.add(slot);
                }
            }
        }
        return occupied;
    }

    public int getFloorOccupiedCount(int floorIndex) {
        if (floorIndex < 0 || floorIndex >= floorSlots.length) {
            return 0;
        }
        int count = 0;
        for (ParkingSlot slot : floorSlots[floorIndex]) {
            if (slot.isOccupied()) {
                count++;
            }
        }
        return count;
    }

    public ParkingSlot[][] getRawSlotMatrix() {
        return floorSlots;
    }
}
