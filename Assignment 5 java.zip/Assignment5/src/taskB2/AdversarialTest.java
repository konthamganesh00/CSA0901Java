
package taskB2;

import java.sql.*;
import java.io.*;
import java.nio.file.*;

public class AdversarialTest {

    public static void main(String[] args) {

        // PART 1: SQL INJECTION TEST

        String url = "jdbc:mysql://localhost:3306/assignment5";
        String user = "root";
        String password = "12345";

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                    url, user, password);

            System.out.println("Database Connected Successfully!");

            Statement st = con.createStatement();

            // Create users table
            st.executeUpdate(
                "CREATE TABLE IF NOT EXISTS users (" +
                "id VARCHAR(50), pwd VARCHAR(50))");

            // Insert user without duplicate insertion error
            st.executeUpdate(
                "INSERT IGNORE INTO users VALUES ('ganesh','12345')");

            // Malicious input
            String id = "' OR '1'='1' -- ";
            String pwd = "wrong";

            // Unsafe SQL
            String unsafeSQL =
                "SELECT * FROM users WHERE id='" + id
                + "' AND pwd='" + pwd + "'";

            ResultSet rs = st.executeQuery(unsafeSQL);

            System.out.println("\nUnsafe Login:");

            if (rs.next()) {
                System.out.println("Login Accepted - SQL Injection!");
            } else {
                System.out.println("Login Rejected");
            }

            rs.close();

            // Safe PreparedStatement
            String safeSQL =
                "SELECT * FROM users WHERE id=? AND pwd=?";

            PreparedStatement ps = con.prepareStatement(safeSQL);

            ps.setString(1, id);
            ps.setString(2, pwd);

            rs = ps.executeQuery();

            System.out.println("\nPreparedStatement Login:");

            if (rs.next()) {
                System.out.println("Login Accepted");
            } else {
                System.out.println("Login Rejected - Injection Prevented!");
            }

            rs.close();
            ps.close();
            st.close();
            con.close();

        } catch (Exception e) {

            System.out.println("Database Error: " + e.getMessage());
        }

        // PART 2: DAMAGED FILE TEST

        System.out.println("\nDamaged Bus Pass File Test:");

        Path file = Paths.get("damagedpasses.txt");

        try {

            Files.writeString(file,
                    "P1001,192311001,Arun,12,4500\n"
                  + "P1002,192311002,Divya\n"
                  + "P1003,192311003,Kumar,7,abc\n"
                  + "\n"
                  + "P1004,192311004,Ravi,12,4200\n");

            BufferedReader reader =
                    Files.newBufferedReader(file);

            String line;

            while ((line = reader.readLine()) != null) {

                if (line.trim().isEmpty()) {
                    System.out.println("Empty line skipped");
                    continue;
                }

                String[] data = line.split(",", -1);

                if (data.length != 5) {
                    System.out.println("Invalid fields skipped: " + line);
                    continue;
                }

                try {

                    Integer.parseInt(data[3]);
                    Double.parseDouble(data[4]);

                    System.out.println("Valid Record: " + line);

                } catch (NumberFormatException e) {

                    System.out.println("Invalid numeric data skipped: " + line);
                }
            }

            reader.close();

        } catch (IOException e) {

            System.out.println("File Error: " + e.getMessage());
        }
    }
}
