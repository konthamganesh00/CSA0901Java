
package taskB1;

import java.io.*;

public class LineCounter {

    public static void main(String[] args) throws IOException {

        String file = "attendance.txt";

        // Create sample file
        try (BufferedWriter w = new BufferedWriter(
                new FileWriter(file))) {

            for (int i = 1; i <= 100000; i++) {
                w.write("Student " + i);
                w.newLine();
            }
        }

        // Unbuffered reading
        long start = System.nanoTime();

        int count1 = 0;

        try (FileInputStream fis = new FileInputStream(file)) {

            int data;

            while ((data = fis.read()) != -1) {
                if (data == '\n') {
                    count1++;
                }
            }
        }

        long unbufferedTime = System.nanoTime() - start;

        // Buffered reading
        start = System.nanoTime();

        int count2 = 0;

        try (BufferedInputStream bis =
                new BufferedInputStream(new FileInputStream(file))) {

            int data;

            while ((data = bis.read()) != -1) {
                if (data == '\n') {
                    count2++;
                }
            }
        }

        long bufferedTime = System.nanoTime() - start;

        System.out.println("Unbuffered Lines: " + count1);
        System.out.println("Buffered Lines: " + count2);

        System.out.println("Unbuffered Time: "
                + unbufferedTime / 1000000.0 + " ms");

        System.out.println("Buffered Time: "
                + bufferedTime / 1000000.0 + " ms");
    }
}
