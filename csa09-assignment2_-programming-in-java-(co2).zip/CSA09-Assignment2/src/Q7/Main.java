package Q7;

import java.io.IOException;

/**
 * Q7 - Main Demonstration Driver
 * Displays headings, inputs, runs normal/boundary/invalid-input tests,
 * and invokes RedesignComparison.main() to generate Q7_RedesignBenchmark.csv.
 */
public class Main {

    private static void verify(boolean condition, String testName) {
        if (!condition) {
            throw new AssertionError("Test failed: " + testName);
        }
        System.out.println("[PASS] " + testName);
    }

    private static void runRedesignTests() {
        System.out.println("\n--- Q7 Normal, Boundary & Invalid Input Tests ---");

        // 1. Normal test: identical outputs on multi-field ticket and chart
        String tOrig = RedesignComparison.buildSingleTicketOriginal(5, 50);
        String tNew = RedesignComparison.buildSingleTicketRedesigned(5, 50);
        verify(tOrig.equals(tNew), "Original and redesigned 50-field ticket outputs match");

        // 2. Boundary tests: 1-field ticket and 0-entry reservation chart
        String minTicketOrig = RedesignComparison.buildSingleTicketOriginal(0, 1);
        String minTicketNew = RedesignComparison.buildSingleTicketRedesigned(0, 1);
        verify(minTicketOrig.equals(minTicketNew) && "PNR=4100000000".equals(minTicketNew),
                "Boundary test: 1-field ticket matches");

        String emptyChartOrig = RedesignComparison.buildChartOriginal(0);
        String emptyChartNew = RedesignComparison.buildChartRedesigned(0);
        verify(emptyChartOrig.equals(emptyChartNew),
                "Boundary test: 0-entry reservation chart matches header-only output");

        // 3. Invalid input tests: 0 fieldCount and negative entryCount
        try {
            RedesignComparison.buildSingleTicketRedesigned(0, 0);
            verify(false, "0 fieldCount should throw IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            System.out.println("[PASS] Invalid fieldCount caught cleanly: " + ex.getMessage());
        }

        try {
            RedesignComparison.buildChartRedesigned(-1);
            verify(false, "Negative entryCount should throw IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            System.out.println("[PASS] Negative entryCount caught cleanly: " + ex.getMessage());
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println("==========================================================================");
        System.out.println("Q7 DEMONSTRATION: DAY-4 PERFORMANCE DESIGN CHALLENGE");
        System.out.println("Focus: Original String(+) vs Pre-sized StringBuilder");
        System.out.println("==========================================================================");

        System.out.println("Sample Inputs:");
        System.out.println("  Batch_1000x50 | Batch_10000x50 | Chart_3000Entries");

        runRedesignTests();

        System.out.println("\n--- Executing Full Q7 A/B Comparison & CSV Export ---");
        RedesignComparison.main(args);
    }
}
