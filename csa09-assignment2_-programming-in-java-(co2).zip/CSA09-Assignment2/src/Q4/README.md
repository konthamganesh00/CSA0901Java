# Q4 – `HashMap`, `TreeMap`, and `LinkedHashMap` (Hospital Pharmacy Inventory)

## Short Explanation
A hospital pharmacy inventory maps unique medicine codes (`MED101`) to `Medicine` stock records:

- **`HashMap<String, Medicine>`** uses a hash table of buckets (converting long chains $\ge 8$ into balanced trees in Java 8+). It achieves **$O(1)$ average** `put()`, `get()`, and `remove()` with no guaranteed iteration order.
- **`TreeMap<String, Medicine>`** uses a self-balancing **Red-Black Tree** ordered by key (`String.compareTo()`). Operations take **$O(\log n)$**, and iterating yields medicines in **sorted code order** automatically.
- **`LinkedHashMap<String, Medicine>`** extends `HashMap` with a doubly linked list running through all entries, preserving **insertion order** (or access order if configured) while maintaining **$O(1)$ average** lookup and update.
- **Why `Hashtable` is avoided in new code:** `Hashtable` is a legacy Java 1.0 class whose every method is `synchronized` on the entire table, creating lock overhead in single-threaded code and contention under concurrency, and it forbids `null` keys/values. Modern Java prefers `HashMap` (single-threaded) or `ConcurrentHashMap` (multi-threaded).
- **Sorted Array + `Arrays.binarySearch()`:** Provides **$O(\log n)$** lookup on static read-mostly catalogs with minimal memory overhead, but dynamic insertion and deletion require **$O(n)$** array shifting—making `HashMap` or `TreeMap` far better for live inventory updates.

---

## Complexity Comparison

| Structure | Insert (`put`) | Lookup (`get`) | Delete (`remove`) | Iteration Order |
|---|---|---|---|---|
| `HashMap` | $O(1)$ avg | $O(1)$ avg | $O(1)$ avg | Unordered |
| `TreeMap` | $O(\log n)$ | $O(\log n)$ | $O(\log n)$ | Sorted key order |
| `LinkedHashMap` | $O(1)$ avg | $O(1)$ avg | $O(1)$ avg | Insertion order |
| Sorted Array (`Arrays.binarySearch`) | $O(n)$ (shift) | $O(\log n)$ | $O(n)$ (shift) | Sorted key order |

---

## How to Run
- **Complete Demo + Tests + Benchmark:** Run `Q4.Main`
- **Inventory CRUD Demo Only:** Run `Q4.PharmacyInventory`
- **Map Benchmark Only:** Run `Q4.MapBenchmark`

---

## Sample Input & Expected Output

### Sample Input
- Medicines added in order: `MED305`, `MED101`, `MED412`, `MED204`, `MED150`
- Search & update `MED204` (`240` → `310`), delete `MED412`
- Benchmark sizes: `1,000`, `10,000`, `50,000` with `100,000` lookups

### Expected Output Format
```text
--- Medicines in Insertion Order (LinkedHashMap) ---
  MED305 | Amoxicillin 250mg ...
  MED101 | Paracetamol 500mg ...
--- Medicines in Sorted Code Order (TreeMap) ---
  MED101 | Paracetamol 500mg ...
  MED150 | Azithromycin 500mg ...
[PASS] Search missing key returns null
[PASS] Negative quantity rejected cleanly: Medicine quantity cannot be negative: -5
...
Saved raw benchmark measurements to: .../ExperimentalData/Q4_MapBenchmark.csv
```

---

## Test Documentation
1. **Normal Test:** CRUD operations and ordering comparison (`LinkedHashMap` vs `TreeMap` vs `HashMap`) in `PharmacyInventory.main()`.
2. **Boundary Tests:** Empty inventory (`size == 0`), zero stock (`quantity == 0`), missing-key lookup/update/delete, and duplicate-key overwrite.
3. **Invalid Input Tests:** Negative quantity/price and `null` medicine rejected with `IllegalArgumentException`.
4. **Benchmark Protocol:** 2 warmup + 5 measured runs per size in `MapBenchmark.main()`, writing real results to `ExperimentalData/Q4_MapBenchmark.csv`.
