# TASK 7 – Method Overriding

## 1. Method Overriding Rules in Java
1. **Same Method Signature**: Subclass method must have the exact same name and parameter list as the superclass method.
2. **Return Type**: Must be identical or covariant (a subtype of the overridden return type).
3. **Access Modifier**: Cannot be more restrictive than the superclass method (e.g., `protected` can be widened to `public`, never narrowed to `private`).
4. **`@Override` Annotation**: Instructs the compiler to verify that a superclass/interface method is actually being overridden, catching typo bugs at compile time.
5. **`final`, `static`, `private` Methods**: Cannot be overridden (`static` methods are hidden, `final` methods cannot be modified by subclasses, `final` classes cannot be subclassed).

## 2. `calculateFee()`, `toString()`, `equals()`, and `hashCode()`
- `calculateFee(int hours)` is overridden by `TwoWheeler` (`hours * 10.0`), `Car` (`hours * 30.0`), `ElectricCar` (`hours * 40.0 + chargingFee()`), `EBike` (flat `15.0`), and `DeliveryVan` (peak 2x car rate).
- `toString()` provides readable diagnostic output for logging, console display, and ticket slips.
- `equals()` and `hashCode()` in `Vehicle`, `ParkingSlot`, `ParkingTicket`, and `ParkingPass` maintain the Java contract: if `a.equals(b)` is `true`, then `a.hashCode() == b.hashCode()`, guaranteeing accurate behavior inside `HashMap` and `HashSet`.

## 3. Method Overriding vs Switch-Based Fee Calculation

| Criterion | Method Overriding (OOP Polymorphism) | Switch-Based Calculation (`SwitchFeeAlternativeDemo`) |
|---|---|---|
| Adding a New Vehicle (`EBike`, `DeliveryVan`) | Add a new subclass; existing fee dispatch code stays untouched (Open/Closed Principle) | Must hunt and edit every `switch` block across the codebase |
| Type Safety | Compile-time verified via `@Override` | Relies on error-prone string/enum branching |
| Dispatch Overhead | `O(1)` JVM virtual method table lookup | `O(1)` tableswitch / lookupswitch |
| Maintainability | High: each class owns its own pricing logic | Low: centralized conditional grows bloated over time |
