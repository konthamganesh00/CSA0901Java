import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

/**
 * Task 03 - Alternative Stack-Based Free-Slot Allocation Comparison.
 * Demonstrates O(1) allocation and O(1) release using a free-slot stack.
 */
public class StackBasedAllocationDemo {

    private final Deque<int[]> freeSlots = new ArrayDeque<>();
    private final boolean[][] occupied;

    public StackBasedAllocationDemo(int[] floorCapacities) {
        occupied = new boolean[floorCapacities.length][];
        // Push in reverse order so [0, 0] sits on top of the stack
        for (int f = floorCapacities.length - 1; f >= 0; f--) {
            occupied[f] = new boolean[floorCapacities[f]];
            for (int s = floorCapacities[f] - 1; s >= 0; s--) {
                freeSlots.push(new int[]{f, s});
            }
        }
    }

    public int[] allocate() {
        if (freeSlots.isEmpty()) {
            return null;
        }
        int[] coord = freeSlots.pop();
        occupied[coord[0]][coord[1]] = true;
        return coord;
    }

    public boolean release(int floor, int slot) {
        if (floor < 0 || floor >= occupied.length || slot < 0 || slot >= occupied[floor].length) {
            return false;
        }
        if (!occupied[floor][slot]) {
            return false;
        }
        occupied[floor][slot] = false;
        freeSlots.push(new int[]{floor, slot});
        return true;
    }

    public static void main(String[] args) {
        StackBasedAllocationDemo demo = new StackBasedAllocationDemo(new int[]{2, 1});
        System.out.println(Arrays.toString(demo.allocate()));
        System.out.println(Arrays.toString(demo.allocate()));
        System.out.println(Arrays.toString(demo.allocate()));
        System.out.println(Arrays.toString(demo.allocate()));
        System.out.println(demo.release(0, 1) + " " + demo.release(0, 1) + " " + demo.release(2, 0));
        System.out.println(Arrays.toString(demo.allocate()));
    }
}
