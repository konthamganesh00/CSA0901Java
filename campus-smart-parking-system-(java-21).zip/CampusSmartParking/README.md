# Campus Smart-Parking System (Java 21)

**Course**: Programming in Java – Assignment 1 (CO1) | **Max Marks**: 50  
**Student Name**: `[YOUR_NAME]`  
**Register Number**: `[YOUR_REGISTER_NUMBER]`  
**Repository Name**: `CSA09-REGISTERNUMBER-Assignment1`  
**GitHub Repository URL**: `https://github.com/[YOUR_GITHUB_USERNAME]/CSA09-REGISTERNUMBER-Assignment1`

---

## 1. Project Overview
The **Campus Smart-Parking System** is a complete, object-oriented Java 21 console application designed to manage multi-floor campus parking lots with variable floor capacities, automated slot allocation, timestamped ticketing, centralised ceiling-based parking fee computation, electric vehicle (EV) charging billing (`Rs 12.0/kWh`), monthly and one-day parking passes, file-based registered vehicle persistence, and daily financial & occupancy reporting.

> **Frontend Note**: Any React/Vite dashboard (`src/App.tsx`) present in the AI Studio workspace outside `CampusSmartParking/` is a standalone web frontend demonstration using browser `localStorage` and is **not** connected to the Java 21 console application.

## 2. Objectives
- Apply core Object-Oriented Programming principles (encapsulation, inheritance, method overriding, compile-time & runtime polymorphism, abstraction, and package modularity) in Java 21.
- Implement multi-floor parking management using **jagged 2D arrays** (`ParkingSlot[][]`) alongside `ArrayList` and `HashMap` for efficient ticket and pass tracking.
- Build a centralised, configurable fee engine (`PricingConfig` + `FeeCalculator`) handling started-hour ceiling arithmetic, EV charging (`Rs 12.0/kWh`), Student/Staff monthly passes, Visitor one-day passes, flat-fee E-Bikes, and peak-hour (9 AM – 5 PM) Delivery Vans.
- Document and verify all 12 assignment tasks with algorithms, alternative designs, complexity analyses, UML diagrams, and test suites.

## 3. Technologies Used
- **Programming Language**: Java 21 (`JavaSE-21`)
- **IDE**: Eclipse IDE for Java Developers
- **Interface**: Console-based interactive menu (`java.util.Scanner`)
- **Data Structures**: 1D arrays, jagged 2D arrays, `ArrayList`, `HashMap`
- **Version Control**: Git & GitHub (`CSA09-REGISTERNUMBER-Assignment1`)
- **Database**: Not required (in-memory OOP collections + optional pure-Java file persistence in `PersistenceService.java`)

## 4. Key Features (All 20 Functionalities)
1. Vehicle registration (`TwoWheeler`, `Car`, `ElectricCar`, `EBike`, `DeliveryVan`) with `UserRole` (`STUDENT`, `STAFF`, `VISITOR`) and duplicate registration rejection
2. Vehicle entry management (auto slot allocation + custom/current entry timestamp)
3. Automatic & specific parking slot allocation
4. Multiple parking floors (presets: `1x20`, `3x50`, `5x100`, and `5`-floor jagged default)
5. Different slot capacities on different floors (`{10, 15, 20, 25, 30}` = 100 slots)
6. Unique static-sequenced parking ticket generation (`TKT-1001`, ...)
7. Entry and exit date/time recording (`LocalDateTime`)
8. Vehicle exit management with slot release (search by Ticket ID or Registration Number)
9. Centralised parking fee calculation with ceiling started-hour billing
10. Student monthly pass (free parking when valid)
11. Staff monthly pass (free parking when valid)
12. Visitor parking fee & Visitor One-Day Pass
13. Electric vehicle charging management & fee (`Chargeable` interface, `Rs 12.0/kWh`)
14. Available parking slot display
15. Occupied parking slot display
16. Parked vehicle details listing
17. Parking ticket search (by Ticket ID or Registration Number)
18. Daily parking collection report
19. Total & per-floor parking occupancy report
20. Custom domain exceptions, input validation & pure Java file persistence across restarts (`PersistenceService`)

## 5. Project Structure
```text
CampusSmartParking/
├── .project
├── .classpath
├── .settings/org.eclipse.jdt.core.prefs
├── src/
│   └── parking/
│       ├── app/
│       │   └── Main.java
│       ├── exception/
│       │   ├── ParkingException.java
│       │   ├── ParkingFullException.java
│       │   ├── InvalidVehicleException.java
│       │   ├── InvalidSlotException.java
│       │   ├── InvalidPassException.java
│       │   └── TicketNotFoundException.java
│       ├── model/
│       │   ├── PricingConfig.java
│       │   ├── VehicleType.java
│       │   ├── Chargeable.java
│       │   ├── PassHolder.java
│       │   ├── Vehicle.java
│       │   ├── TwoWheeler.java
│       │   ├── Car.java
│       │   ├── ElectricCar.java
│       │   ├── EBike.java
│       │   ├── DeliveryVan.java
│       │   ├── ParkingPass.java
│       │   ├── MonthlyPass.java
│       │   ├── OneDayPass.java
│       │   ├── ParkingUser.java
│       │   ├── ParkingSlot.java
│       │   ├── ParkingFloor.java
│       │   └── ParkingTicket.java
│       └── service/
│           ├── ParkingFacility.java
│           ├── FeeCalculator.java
│           ├── TicketService.java
│           ├── PassService.java
│           ├── ReportService.java
│           ├── ParkingService.java
│           └── PersistenceService.java
├── AssignmentTasks/
│   ├── Task01/ ... Task12/
├── UML/
│   ├── ClassDiagram.puml
│   └── UML_Diagrams.md
├── Screenshots/
│   └── README.md
├── AssignmentReport.md
└── README.md
```

## 6. Class Descriptions & Centralised Pricing Assumptions
All pricing rates are centralised in `parking.model.PricingConfig` (documented sample rates):
- **TwoWheeler**: `Rs 10.0 / hour`
- **Car**: `Rs 30.0 / hour`
- **ElectricCar**: `Rs 40.0 / hour` + `Rs 12.0 / kWh` EV charging rate (`defaultEvChargingKwh = 7.5 kWh` -> `Rs 90.0` default charging fee when charging is active)
- **EBike**: `Rs 15.0` flat fee per visit
- **DeliveryVan**: `2 x Car rate = Rs 60.0 / hour` between `09:00` and `17:00`; `Rs 30.0 / hour` outside peak window
- **Student Monthly Pass**: `Rs 200.0` subscription; `Rs 0.0` exit parking fee
- **Staff Monthly Pass**: `Rs 300.0` subscription; `Rs 0.0` exit parking fee
- **Visitor One-Day Pass**: `Rs 50.0` flat pass; `Rs 0.0` extra parking fee on valid day
- **Daily Max Fee Cap**: `Rs 500.0` (configurable)

## 7. UML Diagram
See `UML/ClassDiagram.puml` and `UML/UML_Diagrams.md` for complete PlantUML, Mermaid, and ASCII class and sequence diagrams.

## 8. How to Import into Eclipse IDE
1. Open **Eclipse IDE** (ensure JDK 21 is configured under *Window -> Preferences -> Java -> Installed JREs*).
2. Click **File -> Import... -> General -> Existing Projects into Workspace**.
3. Click **Browse...** and select the `CampusSmartParking/` folder.
4. Ensure `CampusSmartParking` is checked and click **Finish**.
5. Right-click `src/parking/app/Main.java` -> **Run As -> Java Application**.

## 9. How to Compile and Run via Terminal (JDK 21)
From inside the `CampusSmartParking/` directory:

```bash
# Compile main application
mkdir -p bin
javac -d bin src/parking/exception/*.java src/parking/model/*.java src/parking/service/*.java src/parking/app/*.java

# Run interactive console application
java -cp bin parking.app.Main
```

### Running Mandatory & Verification Task Programs
```bash
# Task 3 Mandatory ParkingFacility
javac AssignmentTasks/Task03/ParkingFacility.java
java -cp AssignmentTasks/Task03 ParkingFacility

# Task 8 Mandatory FeeDemo
javac AssignmentTasks/Task08/FeeDemo.java
java -cp AssignmentTasks/Task08 FeeDemo

# Task 11 Full System Test Suite (16 test cases)
javac -cp bin -d bin AssignmentTasks/Task11/AutomatedSystemTest.java
java -cp bin AutomatedSystemTest

# Task 12 Day-4 Design Challenge Test
javac -cp bin -d bin AssignmentTasks/Task12/Day4ChallengeTest.java
java -cp bin Day4ChallengeTest
```

## 10. Illustrative Console Output
```text
Initialised Campus Smart-Parking Facility: 5 Floors (Capacities: 10, 15, 20, 25, 30 = 100 Slots)
=============================================
       CAMPUS SMART-PARKING MANAGEMENT
=============================================
1.  Register Vehicle
2.  Vehicle Entry
...
17. Exit
=============================================
Enter your choice:
```

## 11. Assignment Tasks Summary (Tasks 01–12)
- **Task01**: Problem analysis, candidate classes, business rules, parallel String array alternative.
- **Task02**: Field data types, jagged array implementation, Scanner parsing, integer division & casting.
- **Task03**: Slot & fee algorithms, pseudocode, `break`/`continue`/`return`, mandatory `ParkingFacility.java`, stack alternative.
- **Task04**: Constructors, overloading, `this(...)` chaining, copy constructor, stack vs heap, factory comparison.
- **Task05**: Static ticket counter, static occupancy, static block, object lifecycle & GC.
- **Task06**: Inheritance hierarchy, `super`, constructor execution trace, composition alternative.
- **Task07**: Method overriding (`calculateFee`, `toString`, `equals`, `hashCode`), `final`, switch comparison.
- **Task08**: Overloading, overriding, upcasting, dynamic dispatch, mandatory `FeeDemo.java`.
- **Task09**: Abstract `Vehicle`, `Chargeable` & `PassHolder` interfaces, `default`/`static` interface methods.
- **Task10**: Packages (`parking.model`, `service`, `app`, `exception`), encapsulation, validation, access modifiers.
- **Task11**: Full integration, 16-case test table, manual vs program daily collection, Arrays vs `ArrayList` vs `HashMap`.
- **Task12**: Day-4 Design Challenge (`EBike`, `DeliveryVan`, `OneDayPass`, 5 floors, jagged capacities) & design defence.

## 12. GitHub Repository Submission Instructions
Create a GitHub repository named `CSA09-REGISTERNUMBER-Assignment1` (replacing `REGISTERNUMBER` with your actual register number), then run:

```bash
cd CampusSmartParking
git init
git add .
git commit -m "Complete Campus Smart-Parking System (Java 21) - Tasks 1 to 12"
git branch -M main
git remote add origin https://github.com/[YOUR_GITHUB_USERNAME]/CSA09-REGISTERNUMBER-Assignment1.git
git push -u origin main
```
Before pushing, replace `[YOUR_NAME]`, `[YOUR_REGISTER_NUMBER]`, and `[YOUR_GITHUB_USERNAME]` / `REGISTERNUMBER` in `README.md` and `AssignmentReport.md`, and add your Eclipse console screenshots into `Screenshots/`.
