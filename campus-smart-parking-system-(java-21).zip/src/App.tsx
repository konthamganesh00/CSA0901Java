import React, { useEffect, useMemo, useState } from 'react';
import {
  Car,
  CheckCircle2,
  Clock,
  CreditCard,
  LayoutGrid,
  List,
  Menu,
  ParkingSquare,
  Plus,
  Receipt,
  RotateCcw,
  Search,
  Settings2,
  X,
  Zap,
} from 'lucide-react';
import {
  allocateSlotForVehicle,
  buildJaggedFacility,
  calculateFeeQuote,
  clearPersistedState,
  computeReportsSummary,
  DEFAULT_RATES,
  findActiveSlotByRegOrTicket,
  loadPersistedState,
  normalizeRegNo,
  ParkingSlot,
  PassCategory,
  PassRecord,
  PersistedParkingState,
  PricingRates,
  RATE_ASSUMPTIONS,
  registerVehicleInRegistry,
  savePersistedState,
  SettledTransaction,
  todayDateString,
  UserCategory,
  validatePassEligibility,
  VehicleCategory,
} from './parkingLogic';

type NavSection = 'slots' | 'vehicles' | 'passes' | 'collection' | 'config';
type SlotFilter = 'all' | 'available' | 'occupied';
type ViewMode = 'grid' | 'table';
type InspectorTab = 'allocate' | 'exit';

function formatTimeShort(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function formatPassLabel(pass: PassCategory): string {
  switch (pass) {
    case 'StudentMonthly':
      return 'Student Monthly';
    case 'StaffMonthly':
      return 'Staff Monthly';
    case 'VisitorOneDay':
      return 'Visitor One-Day';
    default:
      return 'No Pass';
  }
}

export default function App() {
  const [state, setState] = useState<PersistedParkingState>(() => loadPersistedState());
  const [activeNav, setActiveNav] = useState<NavSection>('slots');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Slot browser filters & selection
  const [selectedFloor, setSelectedFloor] = useState<number | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<SlotFilter>('all');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSlotId, setSelectedSlotId] = useState<string>(
    () => state.slots[0]?.id ?? 'F1-S01'
  );
  const [inspectorTab, setInspectorTab] = useState<InspectorTab>('allocate');
  const [bannerMessage, setBannerMessage] = useState<{
    kind: 'success' | 'error';
    text: string;
  } | null>(null);

  // Entry & vehicle registration form state
  const [formRegNo, setFormRegNo] = useState('');
  const [formOwner, setFormOwner] = useState('');
  const [formCategory, setFormCategory] = useState<VehicleCategory>('Car');
  const [formUserCategory, setFormUserCategory] = useState<UserCategory>('Student');
  const [formPassId, setFormPassId] = useState('');
  const [formEvCharging, setFormEvCharging] = useState(true);
  const [formEvKwh, setFormEvKwh] = useState<string>(String(state.rates.defaultEvKwh));

  // Exit lookup & settlement state
  const [exitLookupQuery, setExitLookupQuery] = useState('');
  const [simulatedExitHours, setSimulatedExitHours] = useState<string>('');
  const [exitPassOverrideId, setExitPassOverrideId] = useState<string>('');
  const [exitEvKwhOverride, setExitEvKwhOverride] = useState<string>('');

  // Pass issuance form state
  const [newPassCategory, setNewPassCategory] =
    useState<Exclude<PassCategory, 'None'>>('StudentMonthly');
  const [newPassHolder, setNewPassHolder] = useState('');
  const [newPassHolderId, setNewPassHolderId] = useState('');
  const [newPassRegNo, setNewPassRegNo] = useState('');
  const [newPassExpiry, setNewPassExpiry] = useState('');

  useEffect(() => {
    savePersistedState(state);
  }, [state]);

  const { floorCapacities, slots, registeredVehicles, passes, transactions, rates, ticketSeq, passSeq } =
    state;

  const selectedSlot = useMemo(
    () => slots.find((s) => s.id === selectedSlotId) ?? slots[0] ?? null,
    [slots, selectedSlotId]
  );

  const metrics = useMemo(() => computeReportsSummary(state), [state]);

  const filteredSlots = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return slots.filter((slot) => {
      if (selectedFloor !== 'all' && slot.floor !== selectedFloor) {
        return false;
      }
      if (statusFilter === 'available' && slot.occupied) {
        return false;
      }
      if (statusFilter === 'occupied' && !slot.occupied) {
        return false;
      }
      if (q) {
        const matchesSlot = slot.id.toLowerCase().includes(q);
        const matchesVehicle =
          slot.vehicle &&
          (slot.vehicle.regNo.toLowerCase().includes(q) ||
            slot.vehicle.ownerName.toLowerCase().includes(q) ||
            slot.vehicle.ticketId.toLowerCase().includes(q));
        return Boolean(matchesSlot || matchesVehicle);
      }
      return true;
    });
  }, [slots, selectedFloor, statusFilter, searchQuery]);

  const floorBreakdown = useMemo(() => {
    return floorCapacities.map((cap, idx) => {
      const floorNum = idx + 1;
      const floorSlots = slots.filter((s) => s.floor === floorNum);
      const occ = floorSlots.filter((s) => s.occupied).length;
      return {
        floor: floorNum,
        capacity: cap,
        occupied: occ,
        available: cap - occ,
        slots: floorSlots,
      };
    });
  }, [floorCapacities, slots]);

  function notify(kind: 'success' | 'error', text: string) {
    setBannerMessage({ kind, text });
  }

  function resolvePassForVehicle(
    passIdInput: string,
    regNo: string,
    userCategory: UserCategory
  ): { pass: PassRecord | null; error?: string } {
    const trimmed = passIdInput.trim().toUpperCase();
    if (trimmed) {
      const found = passes.find((p) => p.passId.toUpperCase() === trimmed);
      const check = validatePassEligibility(found, regNo, userCategory);
      if (!check.valid) {
        return { pass: null, error: check.reason };
      }
      return { pass: check.pass };
    }
    const autoMatch = passes.find(
      (p) => p.regNo === normalizeRegNo(regNo) && validatePassEligibility(p, regNo, userCategory).valid
    );
    return { pass: autoMatch ?? null };
  }

  function handleRegisterVehicleOnly() {
    const res = registerVehicleInRegistry(
      registeredVehicles,
      formRegNo,
      formOwner,
      formCategory,
      formUserCategory
    );
    if (!res.ok) {
      notify('error', res.error);
      return;
    }
    setState((prev) => ({ ...prev, registeredVehicles: res.nextRegistry }));
    notify(
      'success',
      `Registered ${res.record.vehicleCategory} ${res.record.regNo} (${res.record.userCategory}).`
    );
  }

  function handleAllocateSlot(preferredSlotId?: string) {
    const cleanedReg = normalizeRegNo(formRegNo);
    let nextRegistry = registeredVehicles;
    let ownerToUse = formOwner.trim();
    let categoryToUse = formCategory;
    let userCategoryToUse = formUserCategory;

    const existingReg = registeredVehicles.find((v) => v.regNo === cleanedReg);
    if (existingReg) {
      if (slots.some((s) => s.occupied && s.vehicle?.regNo === cleanedReg)) {
        notify('error', `Duplicate entry rejected: ${cleanedReg} is already parked.`);
        return;
      }
      // If user tries to re-register an already registered plate with conflicting form details
      if (ownerToUse && ownerToUse.toLowerCase() !== existingReg.ownerName.toLowerCase()) {
        notify(
          'error',
          `Duplicate registration number: ${cleanedReg} is already registered to ${existingReg.ownerName}.`
        );
        return;
      }
      ownerToUse = existingReg.ownerName;
      categoryToUse = existingReg.vehicleCategory;
      userCategoryToUse = existingReg.userCategory;
    } else {
      const regRes = registerVehicleInRegistry(
        registeredVehicles,
        formRegNo,
        formOwner,
        formCategory,
        formUserCategory
      );
      if (!regRes.ok) {
        notify('error', regRes.error);
        return;
      }
      nextRegistry = regRes.nextRegistry;
      ownerToUse = regRes.record.ownerName;
    }

    const passResolution = resolvePassForVehicle(formPassId, cleanedReg, userCategoryToUse);
    if (passResolution.error) {
      notify('error', passResolution.error);
      return;
    }

    const parsedKwh = Number(formEvKwh);
    if (categoryToUse === 'ElectricCar' && formEvCharging && (!Number.isFinite(parsedKwh) || parsedKwh < 0)) {
      notify('error', 'Enter a valid non-negative EV charging kWh value.');
      return;
    }

    const alloc = allocateSlotForVehicle(
      slots,
      {
        regNo: cleanedReg,
        ownerName: ownerToUse,
        category: categoryToUse,
        userCategory: userCategoryToUse,
        entryTimeIso: new Date().toISOString(),
        passId: passResolution.pass ? passResolution.pass.passId : null,
        passType: passResolution.pass ? passResolution.pass.category : 'None',
        chargingRequested: categoryToUse === 'ElectricCar' ? formEvCharging : false,
        chargingKwh: categoryToUse === 'ElectricCar' && formEvCharging ? parsedKwh : 0,
      },
      ticketSeq,
      preferredSlotId
    );

    if (!alloc.ok) {
      notify('error', alloc.error);
      return;
    }

    setState((prev) => ({
      ...prev,
      registeredVehicles: nextRegistry,
      slots: alloc.nextSlots,
      ticketSeq: alloc.nextTicketSeq,
    }));
    setSelectedSlotId(alloc.allocatedSlot.id);
    setFormRegNo('');
    setFormOwner('');
    setFormPassId('');
    notify(
      'success',
      `Allocated Floor ${alloc.allocatedSlot.floor}, Slot ${alloc.allocatedSlot.slotNumber} (${alloc.allocatedSlot.id}) to ${cleanedReg} · Ticket ${alloc.allocatedSlot.vehicle?.ticketId}.`
    );
  }

  function handleReleaseSlot(slot: ParkingSlot) {
    if (!slot.occupied || !slot.vehicle) {
      notify('error', `Slot ${slot.id} is not currently occupied.`);
      return;
    }

    let billedOverride: number | undefined;
    if (simulatedExitHours.trim() !== '') {
      const parsed = Number(simulatedExitHours);
      if (!Number.isFinite(parsed) || parsed <= 0) {
        notify('error', 'Simulated exit duration must be greater than 0 hours (no negative durations).');
        return;
      }
      billedOverride = parsed;
    }

    let evKwhOverride: number | undefined;
    if (slot.vehicle.category === 'ElectricCar' && exitEvKwhOverride.trim() !== '') {
      const parsedKwh = Number(exitEvKwhOverride);
      if (!Number.isFinite(parsedKwh) || parsedKwh < 0) {
        notify('error', 'EV charging kWh cannot be negative.');
        return;
      }
      evKwhOverride = parsedKwh;
    }

    const passLookupId = exitPassOverrideId.trim() || slot.vehicle.passId || '';
    let resolvedPass: PassRecord | null = null;
    if (passLookupId) {
      const candidate = passes.find((p) => p.passId.toUpperCase() === passLookupId.toUpperCase());
      const check = validatePassEligibility(
        candidate,
        slot.vehicle.regNo,
        slot.vehicle.userCategory
      );
      if (!check.valid) {
        notify('error', `Invalid pass rejected at exit: ${check.reason}`);
        return;
      }
      resolvedPass = check.pass;
    }

    const exitTimeIso = new Date().toISOString();
    const quote = calculateFeeQuote(slot.vehicle, rates, {
      exitTimeIso,
      billedHoursOverride: billedOverride,
      resolvedPass,
      evKwhOverride,
    });

    if (!quote.ok) {
      notify('error', quote.error);
      return;
    }

    const tx: SettledTransaction = {
      ticketId: slot.vehicle.ticketId,
      regNo: slot.vehicle.regNo,
      ownerName: slot.vehicle.ownerName,
      category: slot.vehicle.category,
      userCategory: slot.vehicle.userCategory,
      slotId: slot.id,
      entryTimeIso: slot.vehicle.entryTimeIso,
      exitTimeIso,
      billedHours: quote.billedHours,
      parkingFee: quote.parkingFee,
      chargingKwh: quote.chargingKwh,
      chargingFee: quote.chargingFee,
      totalFee: quote.totalFee,
      passNote: quote.passNote,
      settledAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setState((prev) => ({
      ...prev,
      transactions: [tx, ...prev.transactions],
      slots: prev.slots.map((s) =>
        s.id === slot.id ? { ...s, occupied: false, vehicle: null } : s
      ),
    }));
    setSimulatedExitHours('');
    setExitPassOverrideId('');
    setExitEvKwhOverride('');
    setExitLookupQuery('');
    notify(
      'success',
      `Released ${slot.id} (${tx.regNo} · ${tx.ticketId}). Billed ${tx.billedHours} hr(s): Rs ${tx.totalFee.toFixed(2)}.`
    );
  }

  function handleToggleEvCharging(slotId: string) {
    setState((prev) => ({
      ...prev,
      slots: prev.slots.map((s) => {
        if (s.id === slotId && s.vehicle && s.vehicle.category === 'ElectricCar') {
          const nextReq = !s.vehicle.chargingRequested;
          return {
            ...s,
            vehicle: {
              ...s.vehicle,
              chargingRequested: nextReq,
              chargingKwh: nextReq ? s.vehicle.chargingKwh || prev.rates.defaultEvKwh : 0,
            },
          };
        }
        return s;
      }),
    }));
  }

  function handleExitLookupSubmit(e: React.FormEvent) {
    e.preventDefault();
    const match = findActiveSlotByRegOrTicket(slots, exitLookupQuery);
    if (!match) {
      notify('error', `No active parked vehicle found for "${exitLookupQuery.trim()}".`);
      return;
    }
    setSelectedSlotId(match.id);
    setInspectorTab('exit');
    setSimulatedExitHours('');
    setExitPassOverrideId(match.vehicle?.passId ?? '');
    setExitEvKwhOverride(
      match.vehicle?.category === 'ElectricCar' ? String(match.vehicle.chargingKwh) : ''
    );
    notify('success', `Loaded active ticket ${match.vehicle?.ticketId} in slot ${match.id}.`);
  }

  function handleIssuePass(e: React.FormEvent) {
    e.preventDefault();
    const cleanedReg = normalizeRegNo(newPassRegNo);
    if (!newPassHolder.trim() || !newPassHolderId.trim() || !/^[A-Z0-9-]{4,15}$/.test(cleanedReg)) {
      notify('error', 'Provide holder name, ID, and a valid vehicle registration number.');
      return;
    }

    const prefix =
      newPassCategory === 'StudentMonthly'
        ? 'MP-STU'
        : newPassCategory === 'StaffMonthly'
          ? 'MP-STF'
          : 'ODP';
    const price =
      newPassCategory === 'StudentMonthly'
        ? rates.studentMonthlyPassFee
        : newPassCategory === 'StaffMonthly'
          ? rates.staffMonthlyPassFee
          : rates.visitorOneDayPassFee;

    const today = todayDateString();
    let validUntil = newPassExpiry.trim();
    if (!validUntil) {
      const validDate = new Date();
      if (newPassCategory !== 'VisitorOneDay') {
        validDate.setMonth(validDate.getMonth() + 1);
      }
      validUntil = todayDateString(validDate);
    }

    const record: PassRecord = {
      passId: `${prefix}-${passSeq}`,
      category: newPassCategory,
      holderName: newPassHolder.trim(),
      holderId: newPassHolderId.trim().toUpperCase(),
      regNo: cleanedReg,
      validUntil,
      active: true,
      purchasePrice: price,
      issuedAtDate: today,
    };

    setState((prev) => ({
      ...prev,
      passSeq: prev.passSeq + 1,
      passes: [record, ...prev.passes],
    }));
    setNewPassHolder('');
    setNewPassHolderId('');
    setNewPassRegNo('');
    setNewPassExpiry('');
    notify('success', `Issued ${record.passId} for ${record.regNo} (Rs ${record.purchasePrice}).`);
  }

  function handleTogglePassActive(passId: string) {
    setState((prev) => ({
      ...prev,
      passes: prev.passes.map((p) => (p.passId === passId ? { ...p, active: !p.active } : p)),
    }));
  }

  function handleApplyFloorPreset(capacities: number[]) {
    if (metrics.occupiedSlots > 0) {
      notify('error', 'Release all parked vehicles before changing floor capacities.');
      return;
    }
    const nextSlots = buildJaggedFacility(capacities);
    setState((prev) => ({
      ...prev,
      floorCapacities: capacities,
      slots: nextSlots,
    }));
    setSelectedFloor('all');
    setSelectedSlotId(nextSlots[0]?.id ?? '');
    notify(
      'success',
      `Reconfigured facility to ${capacities.length} floor(s) (${nextSlots.length} total slots).`
    );
  }

  function handleResetPersistedData() {
    const fresh = clearPersistedState();
    setState(fresh);
    setSelectedFloor('all');
    setSelectedSlotId(fresh.slots[0]?.id ?? 'F1-S01');
    notify('success', 'Facility state reset to default configuration.');
  }

  function handlePrimaryAllocateClick() {
    setActiveNav('slots');
    setInspectorTab('allocate');
    const firstFree = slots.find((s) => !s.occupied);
    if (firstFree) {
      setSelectedSlotId(firstFree.id);
    }
    setTimeout(() => {
      document.getElementById('quick-allocate-reg')?.focus();
    }, 0);
  }

  const navItems: Array<{ id: NavSection; label: string; icon: React.ReactNode }> = [
    { id: 'slots', label: 'Parking Slots', icon: <ParkingSquare className="w-4 h-4" /> },
    { id: 'vehicles', label: 'Parked Vehicles', icon: <Car className="w-4 h-4" /> },
    { id: 'passes', label: 'Parking Passes', icon: <CreditCard className="w-4 h-4" /> },
    { id: 'collection', label: 'Daily Collection', icon: <Receipt className="w-4 h-4" /> },
    { id: 'config', label: 'Floors & Rates', icon: <Settings2 className="w-4 h-4" /> },
  ];

  const activeSectionTitle = navItems.find((n) => n.id === activeNav)?.label ?? 'Parking Slots';

  const selectedSlotQuote = useMemo(() => {
    if (!selectedSlot || !selectedSlot.occupied || !selectedSlot.vehicle) return null;
    const parsedOverride =
      simulatedExitHours.trim() !== '' && Number(simulatedExitHours) > 0
        ? Number(simulatedExitHours)
        : undefined;
    const parsedKwh =
      selectedSlot.vehicle.category === 'ElectricCar' && exitEvKwhOverride.trim() !== ''
        ? Math.max(0, Number(exitEvKwhOverride) || 0)
        : undefined;
    const passIdToUse = exitPassOverrideId.trim() || selectedSlot.vehicle.passId || '';
    const resolvedPass = passIdToUse
      ? passes.find((p) => p.passId.toUpperCase() === passIdToUse.toUpperCase()) ?? null
      : null;

    const quote = calculateFeeQuote(selectedSlot.vehicle, rates, {
      billedHoursOverride: parsedOverride,
      resolvedPass,
      evKwhOverride: parsedKwh,
    });
    return quote.ok ? quote : null;
  }, [selectedSlot, simulatedExitHours, exitEvKwhOverride, exitPassOverrideId, passes, rates]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex">
      {/* Mobile Sidebar Backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-slate-900/40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Left Sidebar Navigation */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-200 lg:static lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
        aria-label="Primary Sidebar Navigation"
      >
        <div className="h-16 px-6 flex items-center justify-between border-b border-slate-200 shrink-0">
          <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap">
            CampusPark
          </span>
          <button
            type="button"
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-2 -mr-2 text-slate-500 hover:text-slate-900 rounded-md focus-visible:outline-2 focus-visible:outline-slate-900"
            aria-label="Close navigation menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = activeNav === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setActiveNav(item.id);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap focus-visible:outline-2 focus-visible:outline-slate-900 ${
                  isActive
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="px-6 py-4 border-t border-slate-200 text-xs text-slate-500 space-y-1">
          <p className="font-medium text-slate-700">Main Campus Deck</p>
          <p className="font-mono tabular-nums">
            {floorCapacities.length} Floors · {metrics.totalCapacity} Total Slots
          </p>
          <p className="text-[11px] text-slate-400">
            Standalone Frontend Demo · LocalStorage
          </p>
        </div>
      </aside>

      {/* Main Column: Header + Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Header */}
        <header className="sticky top-0 z-20 h-16 bg-white border-b border-slate-200 px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden inline-flex items-center justify-center min-w-[44px] min-h-[44px] -ml-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-slate-900"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0 truncate">
              <span className="text-slate-500 hidden sm:inline whitespace-nowrap">
                Campus Operations
              </span>
              <span className="text-slate-300 hidden sm:inline" aria-hidden="true">
                /
              </span>
              <h1 className="font-semibold text-slate-900 truncate">{activeSectionTitle}</h1>
            </div>
          </div>

          <button
            type="button"
            onClick={handlePrimaryAllocateClick}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-emerald-700"
          >
            <Plus className="w-4 h-4" />
            <span>Allocate Slot</span>
          </button>
        </header>

        {/* Main Content Viewport */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 max-w-[1440px] w-full mx-auto space-y-6">
          {/* Action Feedback Banner */}
          {bannerMessage && (
            <div
              role="status"
              className={`flex items-center justify-between gap-4 px-4 py-3 text-sm rounded-lg border ${
                bannerMessage.kind === 'success'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-red-50 border-red-200 text-red-900'
              }`}
            >
              <span>{bannerMessage.text}</span>
              <button
                type="button"
                onClick={() => setBannerMessage(null)}
                className="p-1 rounded hover:bg-black/5 shrink-0"
                aria-label="Dismiss notification"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Single-Elevation Summary Strip */}
          <section
            aria-label="Facility Overview Metrics"
            className="bg-white border border-slate-200 rounded-xl grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-slate-200"
          >
            <div className="p-4 sm:p-5">
              <p className="text-xs font-medium text-slate-500">Total Capacity</p>
              <p className="mt-1 text-2xl font-semibold text-slate-900 font-mono tabular-nums">
                {metrics.totalCapacity}
              </p>
              <p className="mt-1 text-xs text-slate-500">
                {floorCapacities.length} floors · jagged layout
              </p>
            </div>

            <div className="p-4 sm:p-5 border-l border-slate-200 lg:border-l-0">
              <p className="text-xs font-medium text-slate-500">Occupied Slots</p>
              <p className="mt-1 text-2xl font-semibold text-amber-700 font-mono tabular-nums">
                {metrics.occupiedSlots}
              </p>
              <p className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
                {metrics.occupancyPct}% utilization
              </p>
            </div>

            <div className="p-4 sm:p-5">
              <p className="text-xs font-medium text-slate-500">Available Slots</p>
              <p className="mt-1 text-2xl font-semibold text-emerald-700 font-mono tabular-nums">
                {metrics.availableSlots}
              </p>
              <p className="mt-1 text-xs text-slate-500">Ready for auto-allocation</p>
            </div>

            <div className="p-4 sm:p-5 border-l border-slate-200 lg:border-l-0">
              <p className="text-xs font-medium text-slate-500">Today's Collection</p>
              <p className="mt-1 text-2xl font-semibold text-slate-900 font-mono tabular-nums">
                Rs {metrics.totalParkingCollection.toFixed(2)}
              </p>
              <p className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
                Exits Rs {(metrics.parkingFeeCollection + metrics.evChargingCollection).toFixed(0)} ·
                Passes Rs {(metrics.monthlyPassRevenue + metrics.oneDayPassRevenue).toFixed(0)}
              </p>
            </div>
          </section>

          {/* SECTION 1: PARKING SLOTS MANAGEMENT WORKSPACE */}
          {activeNav === 'slots' && (
            <div className="grid grid-cols-1 xl:grid-cols-[1fr_380px] gap-6 items-start">
              {/* Left Primary Anchor: Floor Matrix / Table */}
              <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                {/* Filter & Search Toolbar */}
                <div className="p-4 border-b border-slate-200 flex flex-col gap-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="relative flex-1 max-w-md">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search slot (F1-S01), reg no, or ticket..."
                        className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-slate-900"
                        aria-label="Search parking slots"
                      />
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg">
                        {(['all', 'available', 'occupied'] as SlotFilter[]).map((st) => (
                          <button
                            key={st}
                            type="button"
                            onClick={() => setStatusFilter(st)}
                            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                              statusFilter === st
                                ? 'bg-white text-slate-900 shadow-xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            {st === 'all' ? 'All' : st === 'available' ? 'Available' : 'Occupied'}
                          </button>
                        ))}
                      </div>

                      <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg">
                        <button
                          type="button"
                          onClick={() => setViewMode('grid')}
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 ${
                            viewMode === 'grid'
                              ? 'bg-white text-slate-900 shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                          aria-label="Grid view"
                        >
                          <LayoutGrid className="w-3.5 h-3.5" />
                          <span>Grid</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setViewMode('table')}
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 ${
                            viewMode === 'table'
                              ? 'bg-white text-slate-900 shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                          aria-label="Table view"
                        >
                          <List className="w-3.5 h-3.5" />
                          <span>Table</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Floor Tabs */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                    <button
                      type="button"
                      onClick={() => setSelectedFloor('all')}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 ${
                        selectedFloor === 'all'
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-600 border-slate-200 hover:text-slate-900'
                      }`}
                    >
                      All Floors ({metrics.totalCapacity})
                    </button>
                    {floorBreakdown.map((fb) => (
                      <button
                        key={fb.floor}
                        type="button"
                        onClick={() => setSelectedFloor(fb.floor)}
                        className={`px-3 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 font-mono tabular-nums ${
                          selectedFloor === fb.floor
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-white text-slate-600 border-slate-200 hover:text-slate-900'
                        }`}
                      >
                        Floor {fb.floor} ({fb.available}/{fb.capacity} free)
                      </button>
                    ))}
                  </div>
                </div>

                {/* Slot Display Body */}
                {filteredSlots.length === 0 ? (
                  <div className="p-12 text-center">
                    <p className="text-sm font-medium text-slate-900">No matching parking slots</p>
                    <p className="mt-1 text-xs text-slate-500">
                      Adjust your floor, status, or search filter to view slots.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedFloor('all');
                        setStatusFilter('all');
                        setSearchQuery('');
                      }}
                      className="mt-4 px-4 py-2 text-xs font-medium text-slate-900 border border-slate-200 rounded-lg hover:bg-slate-50"
                    >
                      Reset Filters
                    </button>
                  </div>
                ) : viewMode === 'grid' ? (
                  <div className="divide-y divide-slate-200">
                    {floorBreakdown
                      .filter((fb) => selectedFloor === 'all' || fb.floor === selectedFloor)
                      .map((fb) => {
                        const visibleInFloor = fb.slots.filter((s) =>
                          filteredSlots.some((fs) => fs.id === s.id)
                        );
                        if (visibleInFloor.length === 0) return null;
                        return (
                          <div key={fb.floor} className="p-4 sm:p-5">
                            <div className="flex items-center justify-between mb-3">
                              <h2 className="text-sm font-semibold text-slate-900">
                                Floor {fb.floor}
                              </h2>
                              <span className="text-xs text-slate-500 font-mono tabular-nums">
                                {fb.occupied} occupied · {fb.available} available · {fb.capacity}{' '}
                                capacity
                              </span>
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
                              {visibleInFloor.map((slot) => {
                                const isSelected = selectedSlot?.id === slot.id;
                                return (
                                  <button
                                    key={slot.id}
                                    type="button"
                                    onClick={() => {
                                      setSelectedSlotId(slot.id);
                                      setInspectorTab(slot.occupied ? 'exit' : 'allocate');
                                      setSimulatedExitHours('');
                                      setExitPassOverrideId(slot.vehicle?.passId ?? '');
                                      setExitEvKwhOverride(
                                        slot.vehicle?.category === 'ElectricCar'
                                          ? String(slot.vehicle.chargingKwh)
                                          : ''
                                      );
                                    }}
                                    className={`text-left p-2.5 rounded-lg border transition-colors focus-visible:outline-2 focus-visible:outline-slate-900 ${
                                      isSelected
                                        ? 'ring-2 ring-slate-900 border-slate-900'
                                        : 'border-slate-200'
                                    } ${
                                      slot.occupied
                                        ? 'bg-amber-50/70 hover:bg-amber-50'
                                        : 'bg-white hover:bg-emerald-50/60'
                                    }`}
                                  >
                                    <div className="flex items-center justify-between gap-1">
                                      <span className="text-xs font-semibold font-mono tabular-nums text-slate-900">
                                        {slot.id}
                                      </span>
                                      <span
                                        className={`text-[11px] font-medium ${
                                          slot.occupied ? 'text-amber-800' : 'text-emerald-700'
                                        }`}
                                      >
                                        {slot.occupied ? 'Occupied' : 'Free'}
                                      </span>
                                    </div>
                                    <p className="mt-1 text-xs text-slate-600 truncate font-mono">
                                      {slot.occupied && slot.vehicle
                                        ? slot.vehicle.regNo
                                        : 'Ready'}
                                    </p>
                                    <p className="text-[11px] text-slate-500 truncate">
                                      {slot.occupied && slot.vehicle
                                        ? `${slot.vehicle.category} · ${slot.vehicle.userCategory}`
                                        : `Bay ${slot.slotNumber}`}
                                    </p>
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                          <th className="py-2.5 px-4">Slot Code</th>
                          <th className="py-2.5 px-4">Floor</th>
                          <th className="py-2.5 px-4">State</th>
                          <th className="py-2.5 px-4">Vehicle Reg</th>
                          <th className="py-2.5 px-4">Category</th>
                          <th className="py-2.5 px-4">Ticket ID</th>
                          <th className="py-2.5 px-4 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 text-sm">
                        {filteredSlots.map((slot) => (
                          <tr
                            key={slot.id}
                            className={`hover:bg-slate-50 ${
                              selectedSlot?.id === slot.id ? 'bg-slate-50' : ''
                            }`}
                          >
                            <td className="py-2.5 px-4 font-mono font-medium text-slate-900">
                              {slot.id}
                            </td>
                            <td className="py-2.5 px-4 font-mono tabular-nums text-slate-600">
                              Floor {slot.floor}
                            </td>
                            <td className="py-2.5 px-4">
                              <span
                                className={`text-xs font-medium ${
                                  slot.occupied ? 'text-amber-800' : 'text-emerald-700'
                                }`}
                              >
                                {slot.occupied ? 'Occupied' : 'Available'}
                              </span>
                            </td>
                            <td className="py-2.5 px-4 font-mono text-slate-700">
                              {slot.vehicle?.regNo ?? '—'}
                            </td>
                            <td className="py-2.5 px-4 text-slate-600">
                              {slot.vehicle?.category ?? '—'}
                            </td>
                            <td className="py-2.5 px-4 font-mono text-slate-600">
                              {slot.vehicle?.ticketId ?? '—'}
                            </td>
                            <td className="py-2.5 px-4 text-right">
                              <button
                                type="button"
                                onClick={() => {
                                  setSelectedSlotId(slot.id);
                                  setInspectorTab(slot.occupied ? 'exit' : 'allocate');
                                }}
                                className="text-xs font-medium text-slate-900 underline-offset-2 hover:underline whitespace-nowrap"
                              >
                                {slot.occupied ? 'Inspect / Exit' : 'Select Bay'}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </section>

              {/* Right Panel: Slot Inspector (Entry/Register vs Exit Lookup) */}
              <aside className="bg-white border border-slate-200 rounded-xl divide-y divide-slate-200">
                <div className="p-3 border-b border-slate-200">
                  <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg">
                    <button
                      type="button"
                      onClick={() => setInspectorTab('allocate')}
                      className={`py-1.5 px-3 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                        inspectorTab === 'allocate'
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Vehicle Entry
                    </button>
                    <button
                      type="button"
                      onClick={() => setInspectorTab('exit')}
                      className={`py-1.5 px-3 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                        inspectorTab === 'exit'
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Vehicle Exit
                    </button>
                  </div>
                </div>

                {inspectorTab === 'exit' ? (
                  <>
                    {/* Search by Registration or Ticket ID */}
                    <form onSubmit={handleExitLookupSubmit} className="p-4 space-y-2.5">
                      <label
                        htmlFor="exit-lookup-input"
                        className="block text-xs font-medium text-slate-700"
                      >
                        Find Vehicle by Reg No or Ticket ID
                      </label>
                      <div className="flex gap-2">
                        <input
                          id="exit-lookup-input"
                          type="text"
                          value={exitLookupQuery}
                          onChange={(e) => setExitLookupQuery(e.target.value)}
                          placeholder="TN02CD4480 or TKT-1002"
                          className="flex-1 min-w-0 px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg font-mono uppercase focus:outline-none focus:border-slate-900"
                        />
                        <button
                          type="submit"
                          className="px-3 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg whitespace-nowrap shrink-0"
                        >
                          Lookup
                        </button>
                      </div>
                    </form>

                    {selectedSlot && selectedSlot.occupied && selectedSlot.vehicle && selectedSlotQuote ? (
                      <>
                        <div className="p-5">
                          <div className="flex items-center justify-between gap-2">
                            <h2 className="text-base font-semibold text-slate-900">
                              Slot {selectedSlot.id} (Floor {selectedSlot.floor})
                            </h2>
                            <span className="text-xs font-medium text-amber-800">Occupied</span>
                          </div>
                          <p className="mt-1 text-xs text-slate-500 font-mono">
                            {selectedSlot.vehicle.ticketId} · Entered{' '}
                            {formatTimeShort(selectedSlot.vehicle.entryTimeIso)}
                          </p>

                          <dl className="mt-4 space-y-2 text-sm">
                            <div className="flex justify-between gap-4">
                              <dt className="text-slate-500">Registration</dt>
                              <dd className="font-mono font-medium text-slate-900">
                                {selectedSlot.vehicle.regNo}
                              </dd>
                            </div>
                            <div className="flex justify-between gap-4">
                              <dt className="text-slate-500">Owner / User</dt>
                              <dd className="text-slate-900">
                                {selectedSlot.vehicle.ownerName} · {selectedSlot.vehicle.userCategory}
                              </dd>
                            </div>
                            <div className="flex justify-between gap-4">
                              <dt className="text-slate-500">Category</dt>
                              <dd className="text-slate-900">{selectedSlot.vehicle.category}</dd>
                            </div>
                            <div className="flex justify-between gap-4">
                              <dt className="text-slate-500">Pass Rule</dt>
                              <dd className="text-right text-xs text-slate-700">
                                {selectedSlotQuote.passNote}
                              </dd>
                            </div>
                          </dl>

                          {selectedSlot.vehicle.category === 'ElectricCar' && (
                            <div className="mt-4 pt-4 border-t border-slate-200 space-y-2.5">
                              <div className="flex items-center justify-between gap-3">
                                <div className="flex items-center gap-2 text-xs text-slate-700">
                                  <Zap className="w-4 h-4 text-emerald-700 shrink-0" />
                                  <span>EV Charging (Rs {rates.evChargingPerKwh}/kWh)</span>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => handleToggleEvCharging(selectedSlot.id)}
                                  className={`px-3 py-1.5 text-xs font-medium rounded-md border whitespace-nowrap shrink-0 ${
                                    selectedSlot.vehicle.chargingRequested
                                      ? 'bg-emerald-700 text-white border-emerald-700'
                                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                                  }`}
                                >
                                  {selectedSlot.vehicle.chargingRequested ? 'Enabled' : 'Disabled'}
                                </button>
                              </div>
                              {selectedSlot.vehicle.chargingRequested && (
                                <div>
                                  <label
                                    htmlFor="exit-ev-kwh"
                                    className="block text-xs font-medium text-slate-600 mb-1"
                                  >
                                    Energy Consumed (kWh)
                                  </label>
                                  <input
                                    id="exit-ev-kwh"
                                    type="number"
                                    min={0}
                                    step={0.5}
                                    value={exitEvKwhOverride}
                                    onChange={(e) => setExitEvKwhOverride(e.target.value)}
                                    placeholder={String(selectedSlot.vehicle.chargingKwh)}
                                    className="w-full px-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-slate-900"
                                  />
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        <div className="p-5 space-y-3.5">
                          <div className="grid grid-cols-2 gap-2.5">
                            <div>
                              <label
                                htmlFor="sim-hours-input"
                                className="block text-xs font-medium text-slate-600 mb-1"
                              >
                                Simulate Hours
                              </label>
                              <input
                                id="sim-hours-input"
                                type="number"
                                min={1}
                                max={24}
                                value={simulatedExitHours}
                                onChange={(e) => setSimulatedExitHours(e.target.value)}
                                placeholder={`${selectedSlotQuote.billedHours} hr`}
                                className="w-full px-2.5 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-slate-900"
                              />
                            </div>
                            <div>
                              <label
                                htmlFor="exit-pass-override"
                                className="block text-xs font-medium text-slate-600 mb-1"
                              >
                                Pass ID (Optional)
                              </label>
                              <input
                                id="exit-pass-override"
                                type="text"
                                value={exitPassOverrideId}
                                onChange={(e) => setExitPassOverrideId(e.target.value)}
                                placeholder="MP-STU-501"
                                className="w-full px-2.5 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg font-mono uppercase focus:outline-none focus:border-slate-900"
                              />
                            </div>
                          </div>

                          <div className="space-y-1.5 text-sm">
                            <div className="flex justify-between text-slate-600">
                              <span>Billed Duration</span>
                              <span className="font-mono tabular-nums">
                                {selectedSlotQuote.billedHours} hr(s)
                              </span>
                            </div>
                            <div className="flex justify-between text-slate-600">
                              <span>Parking Fee</span>
                              <span className="font-mono tabular-nums">
                                Rs {selectedSlotQuote.parkingFee.toFixed(2)}
                              </span>
                            </div>
                            <div className="flex justify-between text-slate-600">
                              <span>
                                EV Charging ({selectedSlotQuote.chargingKwh} kWh × Rs{' '}
                                {rates.evChargingPerKwh})
                              </span>
                              <span className="font-mono tabular-nums">
                                Rs {selectedSlotQuote.chargingFee.toFixed(2)}
                              </span>
                            </div>
                            <div className="pt-2 border-t border-slate-200 flex justify-between font-semibold text-slate-900">
                              <span>Total Due</span>
                              <span className="font-mono tabular-nums">
                                Rs {selectedSlotQuote.totalFee.toFixed(2)}
                              </span>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleReleaseSlot(selectedSlot)}
                            className="w-full py-2.5 px-4 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap"
                          >
                            Release Slot & Settle Exit
                          </button>
                        </div>
                      </>
                    ) : (
                      <div className="p-6 text-center text-xs text-slate-500">
                        Enter a parked registration number or ticket ID above, or click an occupied
                        slot in the grid to inspect and settle exit.
                      </div>
                    )}
                  </>
                ) : (
                  <div className="p-5">
                    <div className="flex items-center justify-between gap-2">
                      <h2 className="text-base font-semibold text-slate-900">
                        Vehicle Registration & Entry
                      </h2>
                      <span className="text-xs font-medium text-emerald-700">
                        {selectedSlot && !selectedSlot.occupied ? selectedSlot.id : 'Auto-Assign'}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-slate-500">
                      Register a vehicle or auto-allocate the first available slot.
                    </p>

                    <form
                      className="mt-4 space-y-3"
                      onSubmit={(e) => {
                        e.preventDefault();
                        handleAllocateSlot();
                      }}
                    >
                      <div>
                        <label
                          htmlFor="quick-allocate-reg"
                          className="block text-xs font-medium text-slate-700 mb-1"
                        >
                          Registration Number
                        </label>
                        <input
                          id="quick-allocate-reg"
                          type="text"
                          value={formRegNo}
                          onChange={(e) => setFormRegNo(e.target.value)}
                          placeholder="TN01AB1234"
                          className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg font-mono uppercase focus:outline-none focus:border-slate-900"
                          required
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="quick-allocate-owner"
                          className="block text-xs font-medium text-slate-700 mb-1"
                        >
                          Owner Name
                        </label>
                        <input
                          id="quick-allocate-owner"
                          type="text"
                          value={formOwner}
                          onChange={(e) => setFormOwner(e.target.value)}
                          placeholder="Full name"
                          className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-slate-900"
                          required
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label
                            htmlFor="quick-allocate-type"
                            className="block text-xs font-medium text-slate-700 mb-1"
                          >
                            Vehicle Category
                          </label>
                          <select
                            id="quick-allocate-type"
                            value={formCategory}
                            onChange={(e) => setFormCategory(e.target.value as VehicleCategory)}
                            className="w-full px-2.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-slate-900"
                          >
                            <option value="TwoWheeler">TwoWheeler</option>
                            <option value="Car">Car</option>
                            <option value="ElectricCar">ElectricCar</option>
                            <option value="EBike">EBike</option>
                            <option value="DeliveryVan">DeliveryVan</option>
                          </select>
                        </div>

                        <div>
                          <label
                            htmlFor="quick-allocate-user"
                            className="block text-xs font-medium text-slate-700 mb-1"
                          >
                            User Category
                          </label>
                          <select
                            id="quick-allocate-user"
                            value={formUserCategory}
                            onChange={(e) => setFormUserCategory(e.target.value as UserCategory)}
                            className="w-full px-2.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-slate-900"
                          >
                            <option value="Student">Student</option>
                            <option value="Staff">Staff</option>
                            <option value="Visitor">Visitor</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label
                          htmlFor="quick-allocate-pass-id"
                          className="block text-xs font-medium text-slate-700 mb-1"
                        >
                          Pass ID (optional, auto-checked by Reg No)
                        </label>
                        <input
                          id="quick-allocate-pass-id"
                          type="text"
                          value={formPassId}
                          onChange={(e) => setFormPassId(e.target.value)}
                          placeholder="e.g. MP-STU-501 or ODP-503"
                          className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg font-mono uppercase focus:outline-none focus:border-slate-900"
                        />
                      </div>

                      {formCategory === 'ElectricCar' && (
                        <div className="space-y-2 pt-1">
                          <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={formEvCharging}
                              onChange={(e) => setFormEvCharging(e.target.checked)}
                              className="rounded border-slate-300 text-emerald-700 focus:ring-emerald-700"
                            />
                            <span>Enable EV Charging (Rs {rates.evChargingPerKwh}/kWh)</span>
                          </label>
                          {formEvCharging && (
                            <div>
                              <label
                                htmlFor="quick-ev-kwh"
                                className="block text-xs font-medium text-slate-600 mb-1"
                              >
                                Estimated Energy (kWh)
                              </label>
                              <input
                                id="quick-ev-kwh"
                                type="number"
                                min={0.5}
                                step={0.5}
                                value={formEvKwh}
                                onChange={(e) => setFormEvKwh(e.target.value)}
                                className="w-full px-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-slate-900"
                              />
                            </div>
                          )}
                        </div>
                      )}

                      <div className="pt-2 flex flex-col gap-2">
                        <button
                          type="submit"
                          className="w-full py-2.5 px-4 text-sm font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors whitespace-nowrap"
                        >
                          Auto-Allocate First Available Slot
                        </button>
                        {selectedSlot && !selectedSlot.occupied && (
                          <button
                            type="button"
                            onClick={() => handleAllocateSlot(selectedSlot.id)}
                            className="w-full py-2 px-4 text-xs font-medium text-slate-900 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap"
                          >
                            Park in Selected Bay ({selectedSlot.id})
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={handleRegisterVehicleOnly}
                          className="w-full py-2 px-4 text-xs font-medium text-slate-600 bg-slate-50 border border-slate-200 hover:bg-slate-100 rounded-lg transition-colors whitespace-nowrap"
                        >
                          Register Vehicle Only
                        </button>
                      </div>
                    </form>
                  </div>
                )}
              </aside>
            </div>
          )}

          {/* SECTION 2: PARKED VEHICLES & REGISTRY */}
          {activeNav === 'vehicles' && (
            <div className="space-y-6">
              <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="p-5 border-b border-slate-200 flex items-center justify-between gap-4">
                  <div>
                    <h2 className="text-base font-semibold text-slate-900">
                      Currently Parked Vehicles ({metrics.occupiedSlots})
                    </h2>
                    <p className="text-xs text-slate-500">
                      Live fee estimates use started-hour ceiling arithmetic, Rs{' '}
                      {rates.evChargingPerKwh}/kWh EV charging, and pass rules.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handlePrimaryAllocateClick}
                    className="px-3 py-1.5 text-xs font-medium text-slate-900 border border-slate-200 rounded-lg hover:bg-slate-50 whitespace-nowrap shrink-0"
                  >
                    New Entry
                  </button>
                </div>

                {metrics.occupiedSlots === 0 ? (
                  <div className="p-12 text-center">
                    <p className="text-sm font-medium text-slate-900">No vehicles currently parked</p>
                    <p className="mt-1 text-xs text-slate-500">
                      Allocate a parking slot to generate an active vehicle ticket.
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                          <th className="py-3 px-4">Ticket</th>
                          <th className="py-3 px-4">Slot</th>
                          <th className="py-3 px-4">Vehicle Reg</th>
                          <th className="py-3 px-4">Category</th>
                          <th className="py-3 px-4">User</th>
                          <th className="py-3 px-4">Entry</th>
                          <th className="py-3 px-4">Pass</th>
                          <th className="py-3 px-4 text-right">Est. Fee</th>
                          <th className="py-3 px-4 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 text-sm">
                        {slots
                          .filter((s) => s.occupied && s.vehicle)
                          .map((slot) => {
                            const v = slot.vehicle!;
                            const matchedPass = v.passId
                              ? passes.find((p) => p.passId === v.passId) ?? null
                              : null;
                            const quote = calculateFeeQuote(v, rates, { resolvedPass: matchedPass });
                            const totalEst = quote.ok ? quote.totalFee : 0;
                            return (
                              <tr key={slot.id} className="hover:bg-slate-50">
                                <td className="py-3 px-4 font-mono text-slate-900">{v.ticketId}</td>
                                <td className="py-3 px-4 font-mono text-slate-700">{slot.id}</td>
                                <td className="py-3 px-4 font-mono font-medium text-slate-900">
                                  {v.regNo}
                                </td>
                                <td className="py-3 px-4 text-slate-700">
                                  {v.category}
                                  {v.category === 'ElectricCar' && v.chargingRequested
                                    ? ` (${v.chargingKwh} kWh)`
                                    : ''}
                                </td>
                                <td className="py-3 px-4 text-slate-700">
                                  {v.ownerName} · {v.userCategory}
                                </td>
                                <td className="py-3 px-4 font-mono text-slate-600">
                                  {formatTimeShort(v.entryTimeIso)}
                                </td>
                                <td className="py-3 px-4 text-slate-600">
                                  {v.passId ?? formatPassLabel(v.passType)}
                                </td>
                                <td className="py-3 px-4 text-right font-mono tabular-nums font-medium text-slate-900">
                                  Rs {totalEst.toFixed(2)}
                                </td>
                                <td className="py-3 px-4 text-right">
                                  <button
                                    type="button"
                                    onClick={() => handleReleaseSlot(slot)}
                                    className="px-3 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md whitespace-nowrap"
                                  >
                                    Settle & Exit
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                )}
              </section>

              <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="p-5 border-b border-slate-200">
                  <h2 className="text-base font-semibold text-slate-900">
                    Registered Vehicles Directory ({registeredVehicles.length})
                  </h2>
                  <p className="text-xs text-slate-500">
                    Duplicate registration numbers are rejected across the campus registry.
                  </p>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                        <th className="py-2.5 px-4">Registration</th>
                        <th className="py-2.5 px-4">Owner</th>
                        <th className="py-2.5 px-4">Vehicle Category</th>
                        <th className="py-2.5 px-4">User Category</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 text-sm">
                      {registeredVehicles.map((rv) => (
                        <tr key={rv.regNo} className="hover:bg-slate-50">
                          <td className="py-2.5 px-4 font-mono font-medium text-slate-900">
                            {rv.regNo}
                          </td>
                          <td className="py-2.5 px-4 text-slate-700">{rv.ownerName}</td>
                          <td className="py-2.5 px-4 text-slate-700">{rv.vehicleCategory}</td>
                          <td className="py-2.5 px-4 text-slate-600">{rv.userCategory}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            </div>
          )}

          {/* SECTION 3: PARKING PASSES */}
          {activeNav === 'passes' && (
            <div className="grid grid-cols-1 lg:grid-cols-[340px_1fr] gap-6 items-start">
              <section className="bg-white border border-slate-200 rounded-xl p-5">
                <h2 className="text-base font-semibold text-slate-900">Issue Parking Pass</h2>
                <p className="mt-1 text-xs text-slate-500">
                  Student & Staff Monthly Passes grant free daily parking; Visitor One-Day Pass
                  applies flat Rs {rates.visitorOneDayPassFee} pricing.
                </p>

                <form onSubmit={handleIssuePass} className="mt-4 space-y-3.5">
                  <div>
                    <label
                      htmlFor="pass-cat"
                      className="block text-xs font-medium text-slate-700 mb-1"
                    >
                      Pass Category
                    </label>
                    <select
                      id="pass-cat"
                      value={newPassCategory}
                      onChange={(e) =>
                        setNewPassCategory(e.target.value as Exclude<PassCategory, 'None'>)
                      }
                      className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-slate-900"
                    >
                      <option value="StudentMonthly">
                        Student Monthly (Rs {rates.studentMonthlyPassFee})
                      </option>
                      <option value="StaffMonthly">
                        Staff Monthly (Rs {rates.staffMonthlyPassFee})
                      </option>
                      <option value="VisitorOneDay">
                        Visitor One-Day (Rs {rates.visitorOneDayPassFee})
                      </option>
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="pass-holder-id"
                      className="block text-xs font-medium text-slate-700 mb-1"
                    >
                      Campus / Visitor ID
                    </label>
                    <input
                      id="pass-holder-id"
                      type="text"
                      value={newPassHolderId}
                      onChange={(e) => setNewPassHolderId(e.target.value)}
                      placeholder="STU-2026-102"
                      className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg font-mono uppercase focus:outline-none focus:border-slate-900"
                      required
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="pass-holder-name"
                      className="block text-xs font-medium text-slate-700 mb-1"
                    >
                      Holder Name
                    </label>
                    <input
                      id="pass-holder-name"
                      type="text"
                      value={newPassHolder}
                      onChange={(e) => setNewPassHolder(e.target.value)}
                      placeholder="Full name"
                      className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-slate-900"
                      required
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="pass-reg"
                      className="block text-xs font-medium text-slate-700 mb-1"
                    >
                      Vehicle Registration
                    </label>
                    <input
                      id="pass-reg"
                      type="text"
                      value={newPassRegNo}
                      onChange={(e) => setNewPassRegNo(e.target.value)}
                      placeholder="TN01CD5566"
                      className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg font-mono uppercase focus:outline-none focus:border-slate-900"
                      required
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="pass-expiry"
                      className="block text-xs font-medium text-slate-700 mb-1"
                    >
                      Valid Until (optional, defaults to standard term)
                    </label>
                    <input
                      id="pass-expiry"
                      type="date"
                      value={newPassExpiry}
                      onChange={(e) => setNewPassExpiry(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-slate-900"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 text-sm font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors whitespace-nowrap"
                  >
                    Issue Pass
                  </button>
                </form>
              </section>

              <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="p-5 border-b border-slate-200">
                  <h2 className="text-base font-semibold text-slate-900">
                    Registered Passes ({passes.length})
                  </h2>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                        <th className="py-3 px-4">Pass ID</th>
                        <th className="py-3 px-4">Type</th>
                        <th className="py-3 px-4">Holder</th>
                        <th className="py-3 px-4">Vehicle</th>
                        <th className="py-3 px-4">Charge</th>
                        <th className="py-3 px-4">Valid Until</th>
                        <th className="py-3 px-4">Status</th>
                        <th className="py-3 px-4 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 text-sm">
                      {passes.map((p) => {
                        const isExpired = todayDateString() > p.validUntil;
                        const statusText = !p.active
                          ? 'Revoked'
                          : isExpired
                            ? 'Expired'
                            : 'Valid';
                        return (
                          <tr key={p.passId} className="hover:bg-slate-50">
                            <td className="py-3 px-4 font-mono font-medium text-slate-900">
                              {p.passId}
                            </td>
                            <td className="py-3 px-4 text-slate-700">
                              {formatPassLabel(p.category)}
                            </td>
                            <td className="py-3 px-4 text-slate-700">
                              {p.holderName} ·{' '}
                              <span className="font-mono text-xs">{p.holderId}</span>
                            </td>
                            <td className="py-3 px-4 font-mono text-slate-700">{p.regNo}</td>
                            <td className="py-3 px-4 font-mono tabular-nums text-slate-700">
                              Rs {p.purchasePrice.toFixed(2)}
                            </td>
                            <td className="py-3 px-4 font-mono tabular-nums text-slate-600">
                              {p.validUntil}
                            </td>
                            <td className="py-3 px-4">
                              <span
                                className={`text-xs font-medium ${
                                  statusText === 'Valid' ? 'text-emerald-700' : 'text-red-700'
                                }`}
                              >
                                {statusText}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-right">
                              <button
                                type="button"
                                onClick={() => handleTogglePassActive(p.passId)}
                                className="text-xs font-medium text-slate-900 hover:underline whitespace-nowrap"
                              >
                                {p.active ? 'Revoke' : 'Reactivate'}
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </section>
            </div>
          )}

          {/* SECTION 4: DAILY COLLECTION & REPORTS */}
          {activeNav === 'collection' && (
            <div className="space-y-6">
              <section className="bg-white border border-slate-200 rounded-xl grid grid-cols-2 lg:grid-cols-6 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
                <div className="p-4">
                  <p className="text-xs text-slate-500">Total Collection</p>
                  <p className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900">
                    Rs {metrics.totalParkingCollection.toFixed(2)}
                  </p>
                </div>
                <div className="p-4">
                  <p className="text-xs text-slate-500">Parking Fees</p>
                  <p className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900">
                    Rs {metrics.parkingFeeCollection.toFixed(2)}
                  </p>
                </div>
                <div className="p-4">
                  <p className="text-xs text-slate-500">EV Charging</p>
                  <p className="mt-1 text-lg font-semibold font-mono tabular-nums text-emerald-700">
                    Rs {metrics.evChargingCollection.toFixed(2)}
                  </p>
                </div>
                <div className="p-4">
                  <p className="text-xs text-slate-500">Monthly Passes</p>
                  <p className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900">
                    Rs {metrics.monthlyPassRevenue.toFixed(2)}
                  </p>
                </div>
                <div className="p-4">
                  <p className="text-xs text-slate-500">One-Day Passes</p>
                  <p className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900">
                    Rs {metrics.oneDayPassRevenue.toFixed(2)}
                  </p>
                </div>
                <div className="p-4">
                  <p className="text-xs text-slate-500">Occupied / Free</p>
                  <p className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900">
                    {metrics.occupiedSlots} / {metrics.availableSlots}
                  </p>
                </div>
              </section>

              <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-base font-semibold text-slate-900">
                      Daily Transaction Report ({transactions.length} exits settled)
                    </h2>
                    <p className="text-xs text-slate-500">
                      All totals above are computed dynamically from settled exit transactions and
                      issued passes.
                    </p>
                  </div>
                </div>

                {transactions.length === 0 ? (
                  <div className="p-12 text-center">
                    <p className="text-sm font-medium text-slate-900">
                      No exit transactions settled yet
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      Settle a parked vehicle exit to record its transaction in this daily report.
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                          <th className="py-3 px-4">Ticket ID</th>
                          <th className="py-3 px-4">Slot</th>
                          <th className="py-3 px-4">Vehicle</th>
                          <th className="py-3 px-4">Category</th>
                          <th className="py-3 px-4">Pass Rule</th>
                          <th className="py-3 px-4 text-right">Hours</th>
                          <th className="py-3 px-4 text-right">Parking</th>
                          <th className="py-3 px-4 text-right">EV Charge</th>
                          <th className="py-3 px-4 text-right">Total</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 text-sm">
                        {transactions.map((tx) => (
                          <tr key={tx.ticketId} className="hover:bg-slate-50">
                            <td className="py-3 px-4 font-mono text-slate-900">{tx.ticketId}</td>
                            <td className="py-3 px-4 font-mono text-slate-600">{tx.slotId}</td>
                            <td className="py-3 px-4 font-mono text-slate-900">{tx.regNo}</td>
                            <td className="py-3 px-4 text-slate-700">{tx.category}</td>
                            <td className="py-3 px-4 text-slate-600">{tx.passNote}</td>
                            <td className="py-3 px-4 text-right font-mono tabular-nums">
                              {tx.billedHours}
                            </td>
                            <td className="py-3 px-4 text-right font-mono tabular-nums">
                              Rs {tx.parkingFee.toFixed(2)}
                            </td>
                            <td className="py-3 px-4 text-right font-mono tabular-nums">
                              Rs {tx.chargingFee.toFixed(2)}
                            </td>
                            <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-900">
                              Rs {tx.totalFee.toFixed(2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </section>
            </div>
          )}

          {/* SECTION 5: FLOORS & RATES */}
          {activeNav === 'config' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div>
                  <h2 className="text-base font-semibold text-slate-900">
                    Parking Floor Configuration
                  </h2>
                  <p className="mt-1 text-xs text-slate-500">
                    Switch between standard campus deck presets when the facility is empty.
                  </p>
                </div>

                <div className="space-y-2.5">
                  {[
                    { label: '1 Floor × 20 Slots (20 total)', caps: [20] },
                    { label: '3 Floors × 50 Slots (150 total)', caps: [50, 50, 50] },
                    { label: '5 Floors × 100 Slots (500 total)', caps: [100, 100, 100, 100, 100] },
                    {
                      label: '5 Floors Jagged Default (10, 15, 20, 25, 30 = 100 total)',
                      caps: [10, 15, 20, 25, 30],
                    },
                  ].map((preset) => {
                    const isCurrent =
                      JSON.stringify(floorCapacities) === JSON.stringify(preset.caps);
                    return (
                      <div
                        key={preset.label}
                        className="flex items-center justify-between gap-4 p-3 rounded-lg border border-slate-200"
                      >
                        <span className="text-sm text-slate-800">{preset.label}</span>
                        <button
                          type="button"
                          onClick={() => handleApplyFloorPreset(preset.caps)}
                          disabled={isCurrent}
                          className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 ${
                            isCurrent
                              ? 'bg-slate-100 text-slate-500 cursor-default'
                              : 'bg-slate-900 text-white hover:bg-slate-800'
                          }`}
                        >
                          {isCurrent ? 'Active' : 'Apply'}
                        </button>
                      </div>
                    );
                  })}
                </div>

                <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-4">
                  <div className="text-xs text-slate-500">
                    Data persists automatically across page reloads via browser localStorage.
                  </div>
                  <button
                    type="button"
                    onClick={handleResetPersistedData}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-red-700 border border-red-200 rounded-md hover:bg-red-50 whitespace-nowrap shrink-0"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset Data</span>
                  </button>
                </div>
              </section>

              <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <h2 className="text-base font-semibold text-slate-900">
                      Centralised Fee Rules
                    </h2>
                    <p className="mt-1 text-xs text-slate-500">
                      Every started hour is billed in full using ceiling integer arithmetic.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setState((prev) => ({ ...prev, rates: { ...DEFAULT_RATES } }));
                      notify('success', 'Restored default campus parking rates.');
                    }}
                    className="text-xs font-medium text-slate-700 hover:underline whitespace-nowrap"
                  >
                    Reset Defaults
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  {(
                    [
                      { key: 'twoWheelerPerHour', label: 'TwoWheeler (Rs/hr)' },
                      { key: 'carPerHour', label: 'Car (Rs/hr)' },
                      { key: 'electricCarPerHour', label: 'ElectricCar (Rs/hr)' },
                      { key: 'evChargingPerKwh', label: 'EV Charging (Rs/kWh)' },
                      { key: 'ebikeFlatFee', label: 'E-Bike Flat Fee (Rs)' },
                      { key: 'visitorOneDayPassFee', label: 'Visitor One-Day Pass (Rs)' },
                    ] as Array<{ key: keyof PricingRates; label: string }>
                  ).map((field) => (
                    <div key={field.key}>
                      <label
                        htmlFor={`rate-${field.key}`}
                        className="block text-xs font-medium text-slate-600 mb-1"
                      >
                        {field.label}
                      </label>
                      <input
                        id={`rate-${field.key}`}
                        type="number"
                        min={0}
                        value={rates[field.key]}
                        onChange={(e) =>
                          setState((prev) => ({
                            ...prev,
                            rates: {
                              ...prev.rates,
                              [field.key]: Math.max(0, Number(e.target.value) || 0),
                            },
                          }))
                        }
                        className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg font-mono tabular-nums focus:outline-none focus:border-slate-900"
                      />
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-slate-200 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs text-slate-600">
                    <Clock className="w-4 h-4 text-slate-500 shrink-0" />
                    <span>
                      DeliveryVan peak rule: {rates.deliveryVanPeakMultiplier}x Car rate (Rs{' '}
                      {rates.carPerHour * rates.deliveryVanPeakMultiplier}/hr) between 09:00 and
                      17:00.
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-600">
                    <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span>Daily maximum parking cap: Rs {rates.dailyMaxCap.toFixed(2)}.</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200">
                  <p className="text-xs font-semibold text-slate-700 mb-2">
                    Documented Pricing Assumptions
                  </p>
                  <div className="space-y-1 text-xs text-slate-600">
                    {RATE_ASSUMPTIONS.map((row) => (
                      <div key={row.item} className="flex justify-between gap-4">
                        <span>{row.item}</span>
                        <span className="font-mono text-slate-800">{row.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </section>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
