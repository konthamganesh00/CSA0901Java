package Q3;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

/**
 * Q3 - Main Demonstration Driver
 * Displays headings, inputs, runs normal/boundary/invalid-input tests,
 * executes Attendance.main() (expected: "Unique students: 2"),
 * and runs HashSetExperiment.main().
 */
public class Main {

    private static void verify(boolean condition, String testName) {
        if (!condition) {
            throw new AssertionError("Test failed: " + testName);
        }
        System.out.println("[PASS] " + testName);
    }

    private static void runEdgeAndErrorTests() {
        System.out.println("\n--- Q3 Normal, Boundary & Invalid Input Tests ---");

        // 1. Normal test: Duplicate registration number deduplication
        Set<Student> set = new HashSet<>();
        set.add(new Student("23BCE1001", "Aarav"));
        set.add(new Student("23BCE1001", "Aarav"));
        set.add(new Student("23BCE1002", "Diya"));
        verify(set.size() == 2, "Duplicate registration number de-duplicated to size 2");

        // 2. Boundary tests: Empty set, null equals check, null regNo handling
        Set<Student> emptySet = new HashSet<>();
        verify(emptySet.isEmpty(), "Boundary test: empty attendance set has size 0");

        Student sample = new Student("23BCE1001", "Aarav");
        verify(!sample.equals(null) && sample.equals(sample),
                "equals() contract: non-nullity and reflexivity");

        Student nullReg1 = new Student(null, "Guest1");
        Student nullReg2 = new Student(null, "Guest2");
        verify(nullReg1.equals(nullReg2) && nullReg1.hashCode() == nullReg2.hashCode(),
                "Null-safe equals/hashCode for null registration number");

        // 3. Invalid input tests: TreeSet with null element & blank regNo validation
        Set<Student> treeSet = new TreeSet<>(Comparator.comparing(Student::getRegNo));
        try {
            treeSet.add(null);
            verify(false, "TreeSet.add(null) should throw NullPointerException");
        } catch (NullPointerException ex) {
            System.out.println("[PASS] TreeSet null element rejected cleanly: " + ex.getClass().getSimpleName());
        }

        try {
            Student.validated("   ", "Aarav");
            verify(false, "Blank registration number should throw IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            System.out.println("[PASS] Invalid blank regNo caught cleanly: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        System.out.println("==========================================================================");
        System.out.println("Q3 DEMONSTRATION: HASHCODE AND EQUALS CONTRACT");
        System.out.println("Problem: College Event Attendance De-duplication");
        System.out.println("==========================================================================");

        System.out.println("Sample Inputs:");
        System.out.println("  [23BCE1001 - Aarav, 23BCE1001 - Aarav, 23BCE1002 - Diya]");
        System.out.println("Expected Attendance Output: Unique students: 2");

        System.out.println("\n--- Executing Supplied Attendance Program ---");
        Attendance.main(args);

        runEdgeAndErrorTests();

        System.out.println("\n--- Executing HashSetExperiment ---");
        HashSetExperiment.main(args);
    }
}
