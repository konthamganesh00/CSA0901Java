package parking.model;

/**
 * Represents an electric car that extends Car and implements Chargeable for EV charging support.
 */
public class ElectricCar extends Car implements Chargeable {

    private double batteryCapacityKwh;
    private boolean chargingRequested;
    private double chargingUnitsKwh;

    public ElectricCar() {
        this("UNREGISTERED", "EV Owner", "0000000000", 50.0, true, PricingConfig.getDefaultEvChargingKwh());
    }

    public ElectricCar(String registrationNumber, String ownerName) {
        this(registrationNumber, ownerName, "N/A", 50.0, true, PricingConfig.getDefaultEvChargingKwh());
    }

    public ElectricCar(String registrationNumber, String ownerName, String contactNumber,
                       double batteryCapacityKwh, boolean chargingRequested) {
        this(registrationNumber, ownerName, contactNumber, batteryCapacityKwh,
                chargingRequested, PricingConfig.getDefaultEvChargingKwh());
    }

    public ElectricCar(String registrationNumber, String ownerName, String contactNumber,
                       double batteryCapacityKwh, boolean chargingRequested, double chargingUnitsKwh) {
        super(registrationNumber, ownerName, contactNumber, 4, VehicleType.ELECTRIC_CAR);
        this.batteryCapacityKwh = Math.max(10.0, batteryCapacityKwh);
        this.chargingRequested = chargingRequested;
        this.chargingUnitsKwh = Math.max(0.0, chargingUnitsKwh);
    }

    public double getBatteryCapacityKwh() {
        return batteryCapacityKwh;
    }

    public void setBatteryCapacityKwh(double batteryCapacityKwh) {
        if (batteryCapacityKwh > 0) {
            this.batteryCapacityKwh = batteryCapacityKwh;
        }
    }

    @Override
    public boolean isChargingRequested() {
        return chargingRequested;
    }

    @Override
    public void setChargingRequested(boolean chargingRequested) {
        this.chargingRequested = chargingRequested;
    }

    @Override
    public double getChargingUnitsKwh() {
        return chargingUnitsKwh;
    }

    @Override
    public void setChargingUnitsKwh(double chargingUnitsKwh) {
        if (chargingUnitsKwh >= 0) {
            this.chargingUnitsKwh = chargingUnitsKwh;
        }
    }

    @Override
    public double ratePerHour() {
        return PricingConfig.getElectricCarRatePerHour();
    }

    @Override
    public double chargingFee() {
        return chargingRequested ? (chargingUnitsKwh * PricingConfig.getEvChargingRatePerKwh()) : 0.0;
    }

    @Override
    public double calculateFee(int hours) {
        if (hours <= 0) {
            return 0.0;
        }
        return (hours * ratePerHour()) + chargingFee();
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" [Battery=%.1f kWh, Charging=%s (%.1f kWh @ Rs %.2f/kWh), ChargeFee=Rs %.2f]",
                batteryCapacityKwh, chargingRequested ? "Active" : "Off",
                chargingUnitsKwh, PricingConfig.getEvChargingRatePerKwh(), chargingFee());
    }
}
