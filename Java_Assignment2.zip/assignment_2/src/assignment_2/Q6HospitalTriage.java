package assignment_2;


import java.util.*;

class Patient {

    String name;
    int severity;
    long arrival;

    Patient(String name, int severity, long arrival) {
        this.name = name;
        this.severity = severity;
        this.arrival = arrival;
    }

    public String toString() {
        return name + "(S" + severity + ")";
    }
}

public class Q6HospitalTriage {

    PriorityQueue<Patient> queue;
    long counter = 0;

    Q6HospitalTriage() {

        queue = new PriorityQueue<>(
            Comparator.comparingInt((Patient p) -> p.severity)
            .thenComparingLong(p -> p.arrival)
        );
    }

    void admit(String name, int severity) {

        queue.add(new Patient(name, severity, counter++));
    }

    Patient next() {
        return queue.poll();
    }

    public static void main(String[] args) {

        Q6HospitalTriage er = new Q6HospitalTriage();

        er.admit("Ravi", 3);
        er.admit("Meena", 1);
        er.admit("John", 3);
        er.admit("Asha", 5);
        er.admit("Kumar", 1);
        er.admit("Lata", 2);

        System.out.println("PATIENT TREATMENT ORDER:");

        Patient p;

        while ((p = er.next()) != null) {
            System.out.println(p);
        }
    }
}
