# Q5 – Generics, `Comparable`, and `Comparator` (Inter-College Sports Leaderboard)

## Short Explanation
- **Generics (`Leaderboard<T>`):** Makes the leaderboard reusable for any ranked entity while preserving compile-time type safety.
- **Wildcards & Bounded Types:**
  - `addAll(List<? extends T>)` uses an **upper-bounded wildcard** (producer extends).
  - `sortWith(Comparator<? super T>)` and `copyStandingsTo(List<? super T>)` use **lower-bounded wildcards** (consumer super, following the PECS rule).
  - `sortNaturally(List<U>)` uses a **bounded type parameter** `<U extends Comparable<? super U>>`.
- **`Comparable` vs `Comparator`:**
  - `Comparable<Team>` defines the **natural default ordering** inside `Team.compareTo()`.
  - `Comparator<Team>` allows **external, customizable orderings** via `Comparator.comparingInt(Team::getPoints).thenComparingInt(Team::getGoalDifference).reversed().thenComparing(Team::getName)`.
- **Why `Bisons` ranks above `Panthers`:** Both teams have `9` points and `+4` goal difference. The third tie-breaker sorts names alphabetically (`"Bisons".compareTo("Panthers") < 0`), placing `Bisons` ahead of `Panthers`.
- **Comparator Consistency with `equals()`:** A `Comparator` is *consistent with `equals`* iff `(c.compare(a, b) == 0) == a.equals(b)`. If a `TreeSet` uses a points-only comparator, `Panthers(9,4)` returns `0` against `Bisons(9,4)` and is silently dropped as a duplicate!
- **Multiple Stable Sorting Passes vs Chained `Comparator`:** Because `List.sort()` / `Collections.sort()` uses **TimSort** (a stable sort), sorting in reverse tie-breaker order (Name ascending $\rightarrow$ Goal Difference descending $\rightarrow$ Points descending) produces the exact same output as a single chained `Comparator`, though a single chained `Comparator` runs in one $O(n \log n)$ pass instead of three.

---

## How to Run
- **Complete Demo + Tests:** Run `Q5.Main`
- **Supplied Demo + Extended Tests Only:** Run `Q5.LeaderboardDemo`

---

## Sample Input & Expected Output

### Sample Input
- `Cobras(6,1)`, `Panthers(9,4)`, `Eagles(9,6)`, `Bisons(9,4)`

### Primary Expected Output (`Q5.LeaderboardDemo`)
```text
[Eagles(9,6), Bisons(9,4), Panthers(9,4), Cobras(6,1)]
```

---

## Test Documentation
1. **Normal Test (`LeaderboardDemo.main`):** Verifies `[Eagles(9,6), Bisons(9,4), Panthers(9,4), Cobras(6,1)]` plus multi-way tie cases and 3-pass TimSort equivalence.
2. **Boundary Tests:** Empty `Leaderboard<Team>`, negative goal differences (`-5`, `-2`), and equal-point tie-breaks.
3. **Invalid Input Tests:** Blank team name (`IllegalArgumentException`), `null` entry (`NullPointerException`), and `null` comparator (`NullPointerException`).
