import java.time.LocalDate;
import java.time.LocalDateTime;
import parking.exception.InvalidPassException;
import parking.exception.InvalidSlotException;
import parking.exception.InvalidVehicleException;
import parking.exception.ParkingFullException;
import parking.model.Car;
import parking.model.DeliveryVan;
import parking.model.EBike;
import parking.model.ElectricCar;
import parking.model.MonthlyPass;
import parking.model.OneDayPass;
import parking.model.ParkingTicket;
import parking.model.TwoWheeler;
import parking.service.ParkingFacility;
import parking.service.ParkingService;
import parking.service.ReportService;

/**
 * Task 11 - Integrated Verification Suite covering Normal, Boundary, Invalid cases,
 * and Daily Collection Verification against manual arithmetic.
 *
 * Compile from CampusSmartParking root:
 *   javac -d bin src/parking/exception/*.java src/parking/model/*.java src/parking/service/*.java src/parking/app/*.java
 *   javac -cp bin -d bin AssignmentTasks/Task11/AutomatedSystemTest.java
 *   java -cp bin AutomatedSystemTest
 */
public class AutomatedSystemTest {

    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) throws Exception {
        System.out.println("=== CAMPUS SMART-PARKING SYSTEM: INTEGRATED TEST SUITE ===");
        ParkingTicket.resetCounterForTesting();

        ParkingService service = new ParkingService(new ParkingFacility(new int[]{10, 15, 20, 25, 30}));
        LocalDate today = LocalDate.now();

        // TC-01: Normal TwoWheeler 3h (Rs 10 * 3 = Rs 30.0)
        TwoWheeler bike = new TwoWheeler("TN01TW1001", "Arjun", "9876543210", true);
        ParkingTicket t1 = service.enterVehicle(bike, today.atTime(9, 0));
        service.exitVehicleByTicketId(t1.getTicketId(), today.atTime(12, 0), null);
        assertEquals("TC-01 TwoWheeler 3h", 30.0, t1.getTotalFee());

        // TC-02: Boundary 61 minutes -> 2 started hours for Car (Rs 30 * 2 = Rs 60.0)
        Car car = new Car("TN02CR2002", "Priya", "9876500001", 4);
        ParkingTicket t2 = service.enterVehicle(car, today.atTime(10, 0));
        service.exitVehicleByTicketId(t2.getTicketId(), today.atTime(11, 1), null);
        assertEquals("TC-02 Car 61 mins (2h ceil)", 60.0, t2.getTotalFee());

        // TC-03: ElectricCar 3h + EV Charging -> (40 * 3) + 90 = Rs 210.0
        ElectricCar ev = new ElectricCar("TN03EV3003", "Karthik", "9876500002", 60.0, true);
        ParkingTicket t3 = service.enterVehicle(ev, today.atTime(10, 0));
        service.exitVehicleByTicketId(t3.getTicketId(), today.atTime(13, 0), null);
        assertEquals("TC-03 ElectricCar 3h + Charging", 210.0, t3.getTotalFee());

        // TC-04: Student Monthly Pass (price Rs 200) -> Exit fee Rs 0.0
        MonthlyPass stuPass = service.getPassService().issueMonthlyPass(
                MonthlyPass.PassCategory.STUDENT, "STU101", "Divya", "TN04ST4004", 1);
        TwoWheeler stuBike = new TwoWheeler("TN04ST4004", "Divya");
        ParkingTicket t4 = service.enterVehicle(stuBike, today.atTime(8, 30));
        service.exitVehicleByTicketId(t4.getTicketId(), today.atTime(15, 30), stuPass.getPassId());
        assertEquals("TC-04 Student Monthly Pass Exit", 0.0, t4.getTotalFee());

        // TC-05: EBike Flat Fee -> Rs 15.0 regardless of 5 hours
        EBike ebike = new EBike("TN05EB5005", "Suresh");
        ParkingTicket t5 = service.enterVehicle(ebike, today.atTime(9, 0));
        service.exitVehicleByTicketId(t5.getTicketId(), today.atTime(14, 0), null);
        assertEquals("TC-05 EBike 5h Flat Fee", 15.0, t5.getTotalFee());

        // TC-06: DeliveryVan 2h inside 9 AM - 5 PM -> 2 * (2 * 30) = Rs 120.0
        DeliveryVan van = new DeliveryVan("TN06DV6006", "FastLogistics");
        ParkingTicket t6 = service.enterVehicle(van, today.atTime(11, 0));
        service.exitVehicleByTicketId(t6.getTicketId(), today.atTime(13, 0), null);
        assertEquals("TC-06 DeliveryVan 11:00-13:00 Peak", 120.0, t6.getTotalFee());

        // TC-07: Visitor One-Day Pass (price Rs 50) -> Exit parking fee Rs 0.0
        OneDayPass odp = service.getPassService().issueOneDayPass("VIS-99", "Rohan", "TN07OD7007", today);
        Car visitorCar = new Car("TN07OD7007", "Rohan");
        ParkingTicket t7 = service.enterVehicle(visitorCar, today.atTime(10, 0));
        service.exitVehicleByTicketId(t7.getTicketId(), today.atTime(16, 0), odp.getPassId());
        assertEquals("TC-07 Visitor One-Day Pass Exit", 0.0, t7.getTotalFee());

        // Manual Daily Collection check:
        // Exits: 30 + 60 + 210 + 0 + 15 + 120 + 0 = 435.0
        // Passes sold today: Student Monthly (200.0) + One-Day Pass (50.0) = 250.0
        // Grand Total = 435.0 + 250.0 = 685.0
        ReportService.DailyCollectionSummary summary = service.getReportService()
                .computeDailyCollection(today, service.getTicketService(), service.getPassService());
        assertEquals("TC-08 Daily Grand Total Collection", 685.0, summary.grandTotalCollection());

        // TC-09: Invalid Registration Rejected
        boolean invalidRegCaught = false;
        try {
            service.registerVehicle(new TwoWheeler("!!", "Bad"));
        } catch (InvalidVehicleException e) {
            invalidRegCaught = true;
        }
        assertTrue("TC-09 Invalid Registration Exception", invalidRegCaught);

        // TC-10: Invalid/Expired Pass Rejected
        MonthlyPass expiredPass = new MonthlyPass(MonthlyPass.PassCategory.STAFF, "STF-OLD", "Old",
                "TN09XX9999", today.minusMonths(2), today.minusDays(1));
        service.getPassService().registerPass(expiredPass);
        boolean expiredPassCaught = false;
        try {
            service.getPassService().validatePass(expiredPass.getPassId(), "TN09XX9999", today);
        } catch (InvalidPassException e) {
            expiredPassCaught = true;
        }
        assertTrue("TC-10 Expired Pass Rejection", expiredPassCaught);

        // TC-11: Full Facility Exception on small 1x2 facility
        ParkingService tinyService = new ParkingService(new ParkingFacility(new int[]{2}));
        tinyService.enterVehicle(new TwoWheeler("TN11A1", "U1"), LocalDateTime.now());
        tinyService.enterVehicle(new TwoWheeler("TN11A2", "U2"), LocalDateTime.now());
        boolean fullCaught = false;
        try {
            tinyService.enterVehicle(new TwoWheeler("TN11A3", "U3"), LocalDateTime.now());
        } catch (ParkingFullException e) {
            fullCaught = true;
        }
        assertTrue("TC-11 ParkingFullException when full", fullCaught);

        // TC-12: Invalid Slot Coordinate Exception
        boolean invalidSlotCaught = false;
        try {
            tinyService.getFacility().releaseSlot(4, 0);
        } catch (InvalidSlotException e) {
            invalidSlotCaught = true;
        }
        assertTrue("TC-12 InvalidSlotException on out-of-bounds", invalidSlotCaught);

        // TC-13: Duplicate Registration Number Rejected
        boolean duplicateRegCaught = false;
        try {
            service.registerVehicle(new Car("TN02CR2002", "Duplicate Owner"));
        } catch (InvalidVehicleException e) {
            duplicateRegCaught = true;
        }
        assertTrue("TC-13 Duplicate Registration Rejected", duplicateRegCaught);

        // TC-14: ElectricCar custom 10 kWh @ Rs 12/kWh -> (40 * 2) + (10 * 12) = Rs 200.0
        ElectricCar evCustomKwh = new ElectricCar("TN14EV1414", "Meena", "9876543211", 60.0, true, 10.0);
        double evCustomFee = service.getFeeCalculator().calculateFee(
                evCustomKwh, today.atTime(10, 0), today.atTime(12, 0));
        assertEquals("TC-14 EV 10kWh @ Rs 12/kWh", 200.0, evCustomFee);

        // TC-15: Negative Parking Duration Rejected
        boolean negativeDurCaught = false;
        try {
            service.getFeeCalculator().calculateBilledHours(today.atTime(14, 0), today.atTime(12, 0));
        } catch (IllegalArgumentException e) {
            negativeDurCaught = true;
        }
        assertTrue("TC-15 Negative Duration Rejected", negativeDurCaught);

        // TC-16: Persistence Save & Restart Reload
        java.nio.file.Path tempStore = java.nio.file.Files.createTempFile("campus_parking_test", ".txt");
        parking.service.PersistenceService persistence = new parking.service.PersistenceService(tempStore);
        persistence.saveRegisteredVehicles(service);
        ParkingService restartedService = new ParkingService();
        int restoredCount = persistence.loadRegisteredVehicles(restartedService);
        java.nio.file.Files.deleteIfExists(tempStore);
        assertTrue("TC-16 Persistence Restart Restore", restoredCount >= 7);

        System.out.println("\nSummary: PASSED=" + passed + ", FAILED=" + failed);
        System.out.println(service.getDailyCollectionReport(today));
    }

    private static void assertEquals(String name, double expected, double actual) {
        if (Math.abs(expected - actual) < 0.001) {
            System.out.printf("[PASS] %-36s -> Expected: %.2f | Actual: %.2f%n", name, expected, actual);
            passed++;
        } else {
            System.out.printf("[FAIL] %-36s -> Expected: %.2f | Actual: %.2f%n", name, expected, actual);
            failed++;
        }
    }

    private static void assertTrue(String name, boolean condition) {
        if (condition) {
            System.out.printf("[PASS] %-36s -> true%n", name);
            passed++;
        } else {
            System.out.printf("[FAIL] %-36s -> false%n", name);
            failed++;
        }
    }
}
