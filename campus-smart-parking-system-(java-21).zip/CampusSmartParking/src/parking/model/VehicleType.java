package parking.model;

/**
 * Supported vehicle categories in the Campus Smart-Parking System.
 */
public enum VehicleType {
    TWO_WHEELER("Two-Wheeler"),
    CAR("Car"),
    ELECTRIC_CAR("Electric Car"),
    E_BIKE("E-Bike"),
    DELIVERY_VAN("Delivery Van");

    private final String displayName;

    VehicleType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
