package Q4;

import java.util.Locale;

/**
 * Q4 - Medicine Entity for Hospital Pharmacy Inventory
 */
public class Medicine {

    private final String code;
    private final String name;
    private int quantity;
    private double price;

    public Medicine(String code, String name, int quantity, double price) {
        if (code == null || code.isBlank()) {
            throw new IllegalArgumentException("Medicine code cannot be null or blank.");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Medicine name cannot be null or blank.");
        }
        if (quantity < 0) {
            throw new IllegalArgumentException("Medicine quantity cannot be negative: " + quantity);
        }
        if (price < 0.0) {
            throw new IllegalArgumentException("Medicine price cannot be negative: " + price);
        }
        this.code = code;
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        if (quantity < 0) {
            throw new IllegalArgumentException("Quantity cannot be negative: " + quantity);
        }
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price < 0.0) {
            throw new IllegalArgumentException("Price cannot be negative: " + price);
        }
        this.price = price;
    }

    @Override
    public String toString() {
        return String.format(Locale.US, "%s | %-22s | Qty: %4d | Price: INR %.2f",
                code, name, quantity, price);
    }
}
