
package taskB1;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class PassStore {

    private final Path file;

    PassStore(Path file) {
        this.file = file;
    }

    // Add bus pass
    public void add(String passId, String regNo,
                    String name, int route, double amount)
                    throws IOException {

        try (BufferedWriter w = Files.newBufferedWriter(
                file,
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND)) {

            w.write(String.join(",",
                    passId,
                    regNo,
                    name,
                    String.valueOf(route),
                    String.valueOf(amount)));

            w.newLine();
        }
    }

    // Find bus pass by ID
    public String[] find(String passId) throws IOException {

        try (BufferedReader reader = Files.newBufferedReader(file)) {

            String line;

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",", -1);

                // Skip damaged records
                if (data.length != 5) {
                    continue;
                }

                if (data[0].equals(passId)) {
                    try {
                        Integer.parseInt(data[3]);
                        Double.parseDouble(data[4]);
                        return data;
                    } catch (NumberFormatException e) {
                        continue;
                    }
                }
            }
        }

        return null;
    }

    // List passes by route
    public void listByRoute(int route) throws IOException {

        try (BufferedReader reader = Files.newBufferedReader(file)) {

            String line;

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",", -1);

                if (data.length != 5) {
                    continue;
                }

                try {
                    if (Integer.parseInt(data[3]) == route) {
                        System.out.println(Arrays.toString(data));
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid record skipped");
                }
            }
        }
    }

    public static void main(String[] args) throws IOException {

        Path f = Files.createTempFile("passes", ".csv");

        PassStore store = new PassStore(f);

        store.add("P1001", "192311001", "Arun", 12, 4500);
        store.add("P1002", "192311002", "Divya", 7, 3800);

        // Add damaged record
        Files.writeString(f, "P1003,DAMAGED LINE\n",
                StandardOpenOption.APPEND);

        store.add("P1004", "192311004", "Kumar", 12, 4200);

        System.out.println("Search Result:");
        System.out.println(Arrays.toString(store.find("P1004")));

        System.out.println("\nDamaged Record Search:");
        System.out.println(Arrays.toString(store.find("P1003")));

        System.out.println("\nRoute 12 Passes:");
        store.listByRoute(12);

        Files.delete(f);
    }
}
