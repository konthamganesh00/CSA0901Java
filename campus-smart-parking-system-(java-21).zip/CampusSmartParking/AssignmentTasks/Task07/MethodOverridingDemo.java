import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Task 07 - Method Overriding, @Override, final keyword, toString(), equals(), and hashCode().
 */
public class MethodOverridingDemo {

    static abstract class VehicleBase {
        private final String registrationNumber;

        VehicleBase(String registrationNumber) {
            this.registrationNumber = registrationNumber;
        }

        // final method: cannot be overridden by subclasses to guarantee invariant ID format
        public final String getRegistrationNumber() {
            return registrationNumber;
        }

        public double calculateFee(int hours) {
            return hours * 20.0;
        }

        @Override
        public String toString() {
            return getClass().getSimpleName() + "[" + registrationNumber + "]";
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof VehicleBase other)) {
                return false;
            }
            return Objects.equals(this.registrationNumber, other.registrationNumber);
        }

        @Override
        public int hashCode() {
            return Objects.hash(registrationNumber);
        }
    }

    static class TwoWheeler extends VehicleBase {
        TwoWheeler(String regNo) {
            super(regNo);
        }

        @Override
        public double calculateFee(int hours) {
            return hours * 10.0;
        }
    }

    static final class Car extends VehicleBase { // final class cannot be further extended
        Car(String regNo) {
            super(regNo);
        }

        @Override
        public double calculateFee(int hours) {
            return hours * 30.0;
        }
    }

    public static void main(String[] args) {
        VehicleBase bike = new TwoWheeler("TN01A1");
        VehicleBase car1 = new Car("TN02B2");
        VehicleBase car2 = new Car("TN02B2");

        System.out.println(bike + " 3h fee: Rs " + bike.calculateFee(3));
        System.out.println(car1 + " 3h fee: Rs " + car1.calculateFee(3));
        System.out.println("car1.equals(car2): " + car1.equals(car2));

        Set<VehicleBase> parkedSet = new HashSet<>();
        parkedSet.add(car1);
        parkedSet.add(car2); // Duplicate regNo prevented because equals() & hashCode() match!
        System.out.println("Unique vehicles in HashSet: " + parkedSet.size());
    }
}
