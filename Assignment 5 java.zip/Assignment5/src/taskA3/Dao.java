
package taskA3;

import java.util.List;

public interface Dao<T, K> {

    void insert(T obj);

    T findById(K id);

    List<T> findAll();

    void update(T obj);

    void delete(K id);
}
