/**
 * Task 04 - Classes, Objects, Default/Parameterised/Overloaded Constructors,
 * Constructor Chaining (this(...)), Copy Constructor, and Static Factory Alternative.
 */
public class ConstructorAndObjectDemo {

    static class VehicleProfile {
        private String regNo;
        private String ownerName;
        private String category;
        private double hourlyRate;

        // 1. Default constructor chaining to 4-arg constructor
        public VehicleProfile() {
            this("UNASSIGNED", "Guest Owner", "Car", 30.0);
        }

        // 2. Overloaded 2-arg constructor chaining to 4-arg constructor
        public VehicleProfile(String regNo, String ownerName) {
            this(regNo, ownerName, "Car", 30.0);
        }

        // 3. Full parameterised constructor using 'this' to disambiguate fields
        public VehicleProfile(String regNo, String ownerName, String category, double hourlyRate) {
            this.regNo = regNo;
            this.ownerName = ownerName;
            this.category = category;
            this.hourlyRate = hourlyRate;
        }

        // 4. Copy constructor creating an independent defensive copy on the heap
        public VehicleProfile(VehicleProfile other) {
            this(other.regNo, other.ownerName, other.category, other.hourlyRate);
        }

        // 5. Alternative Static Factory Method
        public static VehicleProfile createElectricCar(String regNo, String ownerName) {
            return new VehicleProfile(regNo, ownerName, "ElectricCar", 40.0);
        }

        // Alternative Setter chaining
        public VehicleProfile setHourlyRate(double hourlyRate) {
            this.hourlyRate = hourlyRate;
            return this;
        }

        @Override
        public String toString() {
            return String.format("VehicleProfile[reg=%s, owner=%s, type=%s, rate=Rs %.1f]",
                    regNo, ownerName, category, hourlyRate);
        }
    }

    public static void main(String[] args) {
        VehicleProfile v1 = new VehicleProfile();
        VehicleProfile v2 = new VehicleProfile("TN01A1111", "Ananya");
        VehicleProfile v3 = new VehicleProfile("TN02B2222", "Karthik", "TwoWheeler", 10.0);
        VehicleProfile v3Copy = new VehicleProfile(v3); // Copy constructor
        v3Copy.setHourlyRate(12.0); // Modifying copy does not mutate original v3
        VehicleProfile v4 = VehicleProfile.createElectricCar("TN03C3333", "Meera");

        System.out.println("Default Constructor : " + v1);
        System.out.println("2-Arg Overloaded    : " + v2);
        System.out.println("Original 4-Arg      : " + v3);
        System.out.println("Copy Constructor    : " + v3Copy);
        System.out.println("Static Factory      : " + v4);
    }
}
