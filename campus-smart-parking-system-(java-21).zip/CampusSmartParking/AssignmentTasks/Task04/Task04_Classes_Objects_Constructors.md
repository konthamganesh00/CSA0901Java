# TASK 4 – Classes, Objects and Constructors

## 1. Class Definitions, Fields and Methods
In `parking.model`, each real-world entity is modeled as a class with private instance fields (e.g., `registrationNumber`, `ownerName`, `contactNumber`, `vehicleType` in `Vehicle`) and public accessor/behaviour methods (`getRegistrationNumber()`, `ratePerHour()`, `calculateFee(int)`).

## 2. Constructors Demonstrated
- **Default Constructor** (`TwoWheeler()`, `Car()`, `ElectricCar()`): Initializes safe default values when no arguments are supplied.
- **Parameterised Constructor**: Accepts all required object attributes at creation time so objects are never left in an inconsistent half-initialized state.
- **Overloaded Constructors**: Multiple constructors with distinct parameter lists (0-arg, 2-arg, 3-arg, 4-arg) provide flexibility for callers.
- **Constructor Chaining (`this(...)`)**: All smaller constructors delegate to the master constructor via `this(...)`, eliminating duplicate validation logic.
- **`this` Keyword**: Differentiates instance fields from constructor/method parameters (`this.registrationNumber = ...`) and returns the current instance in fluent setters.
- **Copy Constructor**: Accepts another object of the same class (`public VehicleProfile(VehicleProfile other)`) to create a distinct heap object with identical field values without aliasing bugs.

## 3. Stack vs Heap Memory Model
When `Car c = new Car("TN01A1", "Ravi");` executes:
1. **Stack**: The local reference variable `c` and constructor stack frame parameters are pushed onto the current thread's stack.
2. **Heap**: The `new` operator allocates memory on the heap for the `Car` object (including inherited `Vehicle` fields and `String` references).
3. **Assignment**: The heap memory address is stored inside reference variable `c` on the stack. When `c` goes out of scope, the stack frame pops; if no references remain, the heap object becomes eligible for Garbage Collection.

## 4. Alternative Comparison: Constructors vs Setters vs Static Factory Methods

| Approach | Immutability / Validation | Readability | Polymorphic Subtype Selection |
|---|---|---|---|
| **Constructors (`new`)** | Enforces mandatory fields at birth | Clear for simple objects | Fixed to exact named class |
| **JavaBean Setters** | Risk of partially initialized objects | Good for optional fields | Cannot enforce required combinations |
| **Static Factory Methods** | Full validation + descriptive names (`createElectricCar`) | Very expressive | Can return any subclass or cached instance |
