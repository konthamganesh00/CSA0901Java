package parking.model;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Abstract base class representing a parking pass issued to a campus user or visitor.
 */
public abstract class ParkingPass {

    private static int passSequence = 500;

    private final String passId;
    private final String holderId;
    private final String holderName;
    private final String vehicleRegistrationNumber;
    private final LocalDate issueDate;
    private LocalDate expiryDate;
    private boolean active;
    private final double purchasePrice;

    protected ParkingPass(String passPrefix, String holderId, String holderName,
                          String vehicleRegistrationNumber, LocalDate issueDate,
                          LocalDate expiryDate, double purchasePrice) {
        this.passId = passPrefix + "-" + (++passSequence);
        this.holderId = (holderId == null || holderId.isBlank()) ? "N/A" : holderId.trim();
        this.holderName = (holderName == null || holderName.isBlank()) ? "Guest" : holderName.trim();
        this.vehicleRegistrationNumber = (vehicleRegistrationNumber == null)
                ? ""
                : vehicleRegistrationNumber.trim().toUpperCase().replaceAll("\\s+", "");
        this.issueDate = (issueDate == null) ? LocalDate.now() : issueDate;
        this.expiryDate = (expiryDate == null) ? this.issueDate : expiryDate;
        this.active = true;
        this.purchasePrice = Math.max(0.0, purchasePrice);
    }

    public abstract String getPassTypeName();

    /**
     * Applies pass pricing rules to the calculated base parking fee.
     *
     * @param baseParkingFee standard parking fee before pass rules
     * @return adjusted parking fee after applying the valid pass
     */
    public abstract double applyToParkingFee(double baseParkingFee);

    public boolean isValid() {
        return isValidOn(LocalDate.now());
    }

    public boolean isValidOn(LocalDate date) {
        if (!active || date == null) {
            return false;
        }
        return !date.isBefore(issueDate) && !date.isAfter(expiryDate);
    }

    public void revoke() {
        this.active = false;
    }

    public String getPassId() {
        return passId;
    }

    public String getHolderId() {
        return holderId;
    }

    public String getHolderName() {
        return holderName;
    }

    public String getVehicleRegistrationNumber() {
        return vehicleRegistrationNumber;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    protected void setExpiryDate(LocalDate expiryDate) {
        if (expiryDate != null) {
            this.expiryDate = expiryDate;
        }
    }

    public boolean isActive() {
        return active;
    }

    public double getPurchasePrice() {
        return purchasePrice;
    }

    @Override
    public String toString() {
        return String.format("%s [ID=%s, Holder=%s (%s), Vehicle=%s, Valid=%s to %s, Status=%s]",
                getPassTypeName(), passId, holderName, holderId, vehicleRegistrationNumber,
                issueDate, expiryDate, isValid() ? "VALID" : "EXPIRED/REVOKED");
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ParkingPass other)) {
            return false;
        }
        return Objects.equals(passId, other.passId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(passId);
    }
}
