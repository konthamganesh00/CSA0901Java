/**
 * Task 06 - Alternative Composition Design ("HAS-A" instead of "IS-A").
 * Demonstrates delegating pricing behaviour to a RateStrategy object instead of subclassing.
 */
public class CompositionParkingDemo {

    interface RateStrategy {
        double calculate(int hours);
        String getTypeName();
    }

    static class HourlyRateStrategy implements RateStrategy {
        private final String typeName;
        private final double ratePerHour;
        private final double extraFlatFee;

        HourlyRateStrategy(String typeName, double ratePerHour, double extraFlatFee) {
            this.typeName = typeName;
            this.ratePerHour = ratePerHour;
            this.extraFlatFee = extraFlatFee;
        }

        @Override
        public double calculate(int hours) {
            return (hours * ratePerHour) + extraFlatFee;
        }

        @Override
        public String getTypeName() {
            return typeName;
        }
    }

    static class ComposedVehicle {
        private final String regNo;
        private RateStrategy rateStrategy; // HAS-A composition

        ComposedVehicle(String regNo, RateStrategy rateStrategy) {
            this.regNo = regNo;
            this.rateStrategy = rateStrategy;
        }

        public void setRateStrategy(RateStrategy rateStrategy) {
            this.rateStrategy = rateStrategy;
        }

        public double computeFee(int hours) {
            return rateStrategy.calculate(hours);
        }

        @Override
        public String toString() {
            return rateStrategy.getTypeName() + " " + regNo;
        }
    }

    public static void main(String[] args) {
        ComposedVehicle car = new ComposedVehicle("TN02B2", new HourlyRateStrategy("Car", 30.0, 0.0));
        ComposedVehicle ev = new ComposedVehicle("TN03C3", new HourlyRateStrategy("ElectricCar", 40.0, 90.0));
        System.out.println(car + " (3 hrs) -> Rs " + car.computeFee(3));
        System.out.println(ev + " (3 hrs) -> Rs " + ev.computeFee(3));
    }
}
