package Q3;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

/**
 * Q3 - HashSetExperiment
 * Demonstrates:
 *   1. HashSet WITHOUT hashCode() (broken de-duplication)
 *   2. HashSet WITH corrected hashCode() and equals()
 *   3. Additional tests: Mutable field trap in HashSet + TreeSet + HashMap comparison
 */
public class HashSetExperiment {

    /**
     * Intentionally broken Student class: overrides equals() but NOT hashCode().
     * Violates the Java Object contract: equal objects must return equal hash codes.
     */
    static class StudentWithoutHashCode {
        private final String regNo;
        private final String name;

        StudentWithoutHashCode(String regNo, String name) {
            this.regNo = regNo;
            this.name = name;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (!(obj instanceof StudentWithoutHashCode other)) return false;
            return Objects.equals(this.regNo, other.regNo);
        }

        @Override
        public String toString() {
            return regNo + " - " + name;
        }
    }

    public static void main(String[] args) {
        System.out.println("==========================================================================");
        System.out.println("Q3: equals() & hashCode() Experiments - College Event Attendance");
        System.out.println("==========================================================================");

        // 1. HashSet WITHOUT hashCode()
        System.out.println("\n--- Experiment 1: HashSet WITHOUT hashCode() ---");
        Set<StudentWithoutHashCode> brokenSet = new HashSet<>();
        StudentWithoutHashCode b1 = new StudentWithoutHashCode("23BCE1001", "Aarav");
        StudentWithoutHashCode b2 = new StudentWithoutHashCode("23BCE1001", "Aarav");
        StudentWithoutHashCode b3 = new StudentWithoutHashCode("23BCE1002", "Diya");

        brokenSet.add(b1);
        brokenSet.add(b2);
        brokenSet.add(b3);

        System.out.println("b1.equals(b2)   : " + b1.equals(b2));
        System.out.println("b1.hashCode()   : " + b1.hashCode());
        System.out.println("b2.hashCode()   : " + b2.hashCode());
        System.out.println("Broken HashSet size (expected 2, actual): " + brokenSet.size());
        System.out.println("Broken HashSet contents: " + brokenSet);

        // 2. HashSet WITH corrected hashCode() and equals()
        System.out.println("\n--- Experiment 2: HashSet WITH corrected hashCode() ---");
        Set<Student> fixedSet = new HashSet<>();
        Student s1 = new Student("23BCE1001", "Aarav");
        Student s2 = new Student("23BCE1001", "Aarav Sharma");
        Student s3 = new Student("23BCE1002", "Diya");

        fixedSet.add(s1);
        fixedSet.add(s2);
        fixedSet.add(s3);

        System.out.println("s1.equals(s2)   : " + s1.equals(s2));
        System.out.println("s1.hashCode()   : " + s1.hashCode());
        System.out.println("s2.hashCode()   : " + s2.hashCode());
        System.out.println("Unique students: " + fixedSet.size());
        System.out.println("Fixed HashSet contents: " + fixedSet);

        // 3a. Additional Test: Mutable field trap in HashSet
        System.out.println("\n--- Experiment 3A: Mutable Field Trap in HashSet ---");
        Set<Student> mutableSet = new HashSet<>();
        Student mutableStudent = new Student("23BCE1099", "Kiran");
        mutableSet.add(mutableStudent);
        System.out.println("Before mutation - contains(mutableStudent): " + mutableSet.contains(mutableStudent));

        // Mutate regNo (part of hashCode/equals) while object is inside HashSet
        mutableStudent.setRegNo("23BCE9999");
        System.out.println("After mutating regNo to 23BCE9999:");
        System.out.println("  contains(mutableStudent): " + mutableSet.contains(mutableStudent)
                + " (lookup checks new bucket, object sits in old bucket!)");
        System.out.println("  contains(new Student(\"23BCE9999\", \"Kiran\")): "
                + mutableSet.contains(new Student("23BCE9999", "Kiran")));
        System.out.println("  Set size remains: " + mutableSet.size()
                + " (Lesson: key fields used in hashCode/equals should be final/immutable)");

        // 3b. Additional Test: TreeSet and HashMap for Attendance De-duplication
        System.out.println("\n--- Experiment 3B: TreeSet & HashMap Comparison ---");
        Set<Student> treeSet = new TreeSet<>(Comparator.comparing(Student::getRegNo));
        treeSet.add(new Student("23BCE1002", "Diya"));
        treeSet.add(new Student("23BCE1001", "Aarav"));
        treeSet.add(new Student("23BCE1001", "Aarav Duplicate"));
        System.out.println("TreeSet (sorted by regNo) unique count: " + treeSet.size());
        System.out.println("TreeSet contents: " + treeSet);

        Map<String, Student> attendanceMap = new HashMap<>();
        attendanceMap.putIfAbsent("23BCE1001", new Student("23BCE1001", "Aarav"));
        attendanceMap.putIfAbsent("23BCE1001", new Student("23BCE1001", "Aarav Duplicate"));
        attendanceMap.putIfAbsent("23BCE1002", new Student("23BCE1002", "Diya"));
        System.out.println("HashMap<regNo, Student> unique count: " + attendanceMap.size());
        System.out.println("HashMap values: " + attendanceMap.values());
    }
}
