package parking.exception;

/**
 * Thrown when all parking slots across every floor are occupied.
 */
public class ParkingFullException extends ParkingException {

    private static final long serialVersionUID = 1L;

    public ParkingFullException(String message) {
        super(message);
    }
}
