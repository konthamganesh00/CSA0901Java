
package taskA4;

import java.io.Serializable;
import java.sql.Connection;

public class Resident implements Serializable {

    private static final long serialVersionUID = 1L;

    String name;
    String regNo;

    transient String password;
    transient Connection connection;

    public Resident(String name, String regNo, String password) {
        this.name = name;
        this.regNo = regNo;
        this.password = password;
    }

    public String toString() {
        return "Name: " + name
                + ", Register Number: " + regNo
                + ", Password: " + password;
    }
}
