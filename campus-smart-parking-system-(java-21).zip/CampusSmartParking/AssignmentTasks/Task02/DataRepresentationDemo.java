import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Task 02 - Data Representation, Jagged Arrays, Type Casting, Integer Division Precision,
 * and Comparison with 1D Arrays and ArrayList.
 */
public class DataRepresentationDemo {

    public static void main(String[] args) {
        // 1. Primitive & Reference Data Types
        int floorCount = 5;
        double carHourlyRate = 30.0;
        boolean evChargingEnabled = true;
        char currencySymbol = 'R';
        String vehicleReg = "TN01AB1234";
        System.out.println("Sample Types -> floors=" + floorCount + ", rate=" + carHourlyRate
                + ", ev=" + evChargingEnabled + ", code=" + currencySymbol + ", reg=" + vehicleReg);

        // 2. Jagged Array Representation (different slot capacities per floor)
        int[] capacities = {10, 15, 20, 25, 30};
        String[][] jaggedSlots = new String[capacities.length][];
        for (int f = 0; f < capacities.length; f++) {
            jaggedSlots[f] = new String[capacities[f]];
            for (int s = 0; s < capacities[f]; s++) {
                jaggedSlots[f][s] = "F" + (f + 1) + "-S" + (s + 1);
            }
        }
        System.out.println("Jagged Floor Capacities: " + Arrays.toString(capacities));
        System.out.println("Floor 1 length=" + jaggedSlots[0].length + ", Floor 5 length=" + jaggedSlots[4].length);

        // 3. Integer Division Pitfall vs Ceiling Arithmetic & Explicit Casting
        int parkedMinutes = 61;
        int buggyHours = parkedMinutes / 60;              // Integer division truncates 61/60 to 1!
        int ceilingIntHours = (parkedMinutes + 59) / 60;  // Exact ceiling: (61 + 59) / 60 = 2 hours
        double exactHours = (double) parkedMinutes / 60;  // Explicit widening cast: 1.0167 hours
        int mathCeilHours = (int) Math.ceil(exactHours);  // Narrowing cast back to int: 2 hours

        System.out.println("\n=== Integer Division & Casting Demonstration ===");
        System.out.println("Parked Minutes        : " + parkedMinutes);
        System.out.println("Buggy (mins / 60)     : " + buggyHours + " hr (UNDERCHARGES!)");
        System.out.println("Ceiling ((m+59)/60)   : " + ceilingIntHours + " hrs (CORRECT)");
        System.out.printf("Exact cast (double)   : %.4f hrs -> Math.ceil = %d hrs%n", exactHours, mathCeilHours);

        // 4. Alternative 1D Flattened Array vs ArrayList Demonstration
        int totalSlots = 10 + 15 + 20 + 25 + 30;
        boolean[] flat1DArray = new boolean[totalSlots];
        ArrayList<String> dynamicWaitlistOrSlots = new ArrayList<>();
        dynamicWaitlistOrSlots.add("F1-S01");
        dynamicWaitlistOrSlots.add("F1-S02");
        System.out.println("\n1D Flattened length=" + flat1DArray.length
                + ", ArrayList sample size=" + dynamicWaitlistOrSlots.size());

        // 5. Safe Scanner Input Parsing Pattern (non-interactive demo fallback)
        String simulatedInput = "125";
        try (Scanner sc = new Scanner(simulatedInput)) {
            String raw = sc.nextLine().trim();
            int parsedMinutes = Integer.parseInt(raw); // String -> int conversion
            System.out.println("Parsed Scanner input '" + raw + "' -> " + parsedMinutes + " minutes.");
        }
    }
}
