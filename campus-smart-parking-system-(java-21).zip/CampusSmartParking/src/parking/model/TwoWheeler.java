package parking.model;

/**
 * Represents a two-wheeler vehicle (motorcycle or scooter).
 */
public class TwoWheeler extends Vehicle {

    private boolean hasHelmetStorage;

    public TwoWheeler() {
        this("UNREGISTERED", "Campus Rider", "0000000000", false);
    }

    public TwoWheeler(String registrationNumber, String ownerName) {
        this(registrationNumber, ownerName, "N/A", false);
    }

    public TwoWheeler(String registrationNumber, String ownerName, String contactNumber, boolean hasHelmetStorage) {
        this(registrationNumber, ownerName, contactNumber, hasHelmetStorage, VehicleType.TWO_WHEELER);
    }

    protected TwoWheeler(String registrationNumber, String ownerName, String contactNumber,
                         boolean hasHelmetStorage, VehicleType vehicleType) {
        super(registrationNumber, ownerName, contactNumber, vehicleType);
        this.hasHelmetStorage = hasHelmetStorage;
    }

    public boolean isHasHelmetStorage() {
        return hasHelmetStorage;
    }

    public void setHasHelmetStorage(boolean hasHelmetStorage) {
        this.hasHelmetStorage = hasHelmetStorage;
    }

    @Override
    public double ratePerHour() {
        return PricingConfig.getTwoWheelerRatePerHour();
    }

    @Override
    public double calculateFee(int hours) {
        if (hours <= 0) {
            return 0.0;
        }
        return hours * ratePerHour();
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" [HelmetStorage=%s]", hasHelmetStorage ? "Yes" : "No");
    }
}
