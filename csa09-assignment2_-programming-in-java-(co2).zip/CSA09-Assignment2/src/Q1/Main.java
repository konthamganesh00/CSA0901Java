package Q1;

import java.io.IOException;

/**
 * Q1 - Main Demonstration Driver
 * Runs user-friendly demonstrations, normal/boundary/invalid-input tests,
 * and invokes StringBenchmark to generate ExperimentalData/Q1_StringBenchmark.csv.
 */
public class Main {

    private static void verify(boolean condition, String testName) {
        if (!condition) {
            throw new AssertionError("Test failed: " + testName);
        }
        System.out.println("[PASS] " + testName);
    }

    private static void runValidationAndBoundaryTests() {
        System.out.println("\n--- Q1 Normal, Boundary & Invalid Input Tests ---");

        // 1. Normal test: all three implementations must produce identical output
        String s1 = StringBenchmark.buildShortTicketWithString(
                "4123456789", "Aarav Sharma", "B2", "LB-12", 1450.00, "12609", "MAS-SBC", "2026-11-20");
        String s2 = StringBenchmark.buildShortTicketWithStringBuilder(
                "4123456789", "Aarav Sharma", "B2", "LB-12", 1450.00, "12609", "MAS-SBC", "2026-11-20");
        String s3 = StringBenchmark.buildShortTicketWithStringBuffer(
                "4123456789", "Aarav Sharma", "B2", "LB-12", 1450.00, "12609", "MAS-SBC", "2026-11-20");

        verify(s1.equals(s2) && s2.equals(s3), "Normal ticket equivalence across String, StringBuilder, StringBuffer");

        // 2. Boundary test: zero fare and minimal empty coach/berth values
        String zeroFareTicket = StringBenchmark.buildShortTicketWithStringBuilder(
                "0000000001", "Guest", "", "", 0.00, "00000", "A-B", "2026-01-01");
        verify(zeroFareTicket.contains("Fare:INR 0.00"), "Boundary test with zero fare and empty coach/berth");

        // 3. Invalid input test: null PNR and negative fare must be rejected cleanly
        try {
            StringBenchmark.validateTicketInputs(null, "Aarav", -100.0);
            verify(false, "Invalid ticket input should throw IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            System.out.println("[PASS] Invalid input caught cleanly: " + ex.getMessage());
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println("==========================================================================");
        System.out.println("Q1 DEMONSTRATION: STRING, STRINGBUILDER AND STRINGBUFFER");
        System.out.println("Problem: Railway E-Ticket Generation");
        System.out.println("==========================================================================");

        System.out.println("Sample Inputs:");
        System.out.println("  PNR=4123456789, Name=Aarav Sharma, Coach=B2, Berth=LB-12, Fare=1450.00");

        runValidationAndBoundaryTests();

        System.out.println("\n--- Executing Full Q1 Benchmark & CSV Export ---");
        StringBenchmark.main(args);
    }
}
