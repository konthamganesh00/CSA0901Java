
package task01;

public class task2 {

    public static void main(String[] args) {

        System.out.println("TASK 2 - HOSPITAL OUTPATIENT APPOINTMENT DESK");

        System.out.println("\n2.1 - MODEL THE EVENTS");

        System.out.println("Department - ItemEvent - ItemListener - Update doctor list");
        System.out.println("Doctor - ItemEvent - ItemListener - Select doctor");
        System.out.println("Time Slot - ItemEvent - ItemListener - Select time");
        System.out.println("Book Button - ActionEvent - ActionListener - Book appointment");
        System.out.println("Window - WindowEvent - WindowListener - Close window");

        System.out.println("\n2.2 - COMPONENT HIERARCHY");

        System.out.println("JFrame - Hospital Appointment Desk");
        System.out.println("  JPanel");
        System.out.println("    JLabel - Patient ID");
        System.out.println("    JTextField - Patient ID");
        System.out.println("    JLabel - Department");
        System.out.println("    JComboBox - Department");
        System.out.println("    JLabel - Doctor");
        System.out.println("    JComboBox - Doctor");
        System.out.println("    JLabel - Time Slot");
        System.out.println("    JComboBox - Time Slot");
        System.out.println("    JButton - Book Appointment");

        System.out.println("\n2.3 - HANDLER LOGIC");

        System.out.println("A) Refresh Doctor List:");
        System.out.println("1. Get selected department.");
        System.out.println("2. Clear doctor list.");
        System.out.println("3. Get doctors for selected department.");
        System.out.println("4. Add doctors to doctor list.");

        System.out.println("\nB) Validate and Book:");
        System.out.println("1. Read patient ID, department, doctor and time.");
        System.out.println("2. Check whether fields are empty.");
        System.out.println("3. Validate patient ID.");
        System.out.println("4. Check doctor availability.");
        System.out.println("5. Book appointment if available.");
        System.out.println("6. Display confirmation or error.");

        System.out.println("\n2.4 - EVENT SEQUENCE");

        System.out.println("1. Create JFrame.");
        System.out.println("2. Initialize components.");
        System.out.println("3. Register listeners.");
        System.out.println("4. Display window.");
        System.out.println("5. Enter patient details.");
        System.out.println("6. Select department and update doctors.");
        System.out.println("7. Select doctor and time slot.");
        System.out.println("8. Click Book Appointment.");
        System.out.println("9. Validate and confirm booking.");
        System.out.println("10. windowClosing() handles closing.");

        System.out.println("\nAPPLET LIFE CYCLE");

        System.out.println("init() - Initializes components.");
        System.out.println("start() - Starts execution.");
        System.out.println("paint() - Displays output.");
        System.out.println("stop() - Stops execution.");
        System.out.println("destroy() - Releases resources.");

        System.out.println("\nTASK 2 COMPLETED");
    }
}
