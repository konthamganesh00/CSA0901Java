package Q5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Q5 - Inter-College Sports Leaderboard Demo
 * Completes both TODO sections while preserving main() and the supplied team data.
 */
public class LeaderboardDemo {

    public static void main(String[] args) {
        List<Team> teams = new ArrayList<>();
        teams.add(new Team("Cobras", 6, 1));
        teams.add(new Team("Panthers", 9, 4));
        teams.add(new Team("Eagles", 9, 6));
        teams.add(new Team("Bisons", 9, 4));

        // Requirement 1 (Completed): Define Comparator using comparing(), thenComparing(), and reversed()
        // Rule: higher points first -> higher goal difference first -> alphabetical name
        Comparator<Team> rankingComparator = Comparator
                .comparingInt(Team::getPoints)
                .thenComparingInt(Team::getGoalDifference)
                .reversed()
                .thenComparing(Team::getName);

        // Requirement 2 (Completed): Sort using generic Leaderboard<Team> and display the ranked standings
        Leaderboard<Team> leaderboard = new Leaderboard<>();
        leaderboard.addAll(teams);
        leaderboard.sortWith(rankingComparator);

        System.out.println(leaderboard.getEntries());

        // Extended tests: ties, multiple stable sorts, bounded types, wildcards, consistency
        runExtendedTests(rankingComparator);
    }

    private static void runExtendedTests(Comparator<Team> fullRankingComparator) {
        System.out.println("\n--- Extended Test 1: Multiple Ties (Points, Goal Difference, Name) ---");
        List<Team> tieTeams = new ArrayList<>(List.of(
                new Team("Wolves", 12, 5),
                new Team("Falcons", 12, 5),
                new Team("Titans", 12, 8),
                new Team("Hawks", 9, -2),
                new Team("Lions", 9, 0),
                new Team("Bears", 9, -2)
        ));
        Leaderboard<Team> tieBoard = new Leaderboard<>();
        tieBoard.addAll(tieTeams);
        tieBoard.sortWith(fullRankingComparator);
        Leaderboard.printStandings("Tie-breaker standings", tieBoard.getEntries());

        System.out.println("\n--- Extended Test 2: Natural Comparable vs Multiple Stable Sorts ---");
        List<Team> naturalSorted = Leaderboard.sortNaturally(tieTeams);
        Leaderboard.printStandings("Via Comparable + Collections.sort()", naturalSorted);

        // Multiple stable sorting passes (TimSort is guaranteed stable):
        // Pass 1 (lowest priority): Name ascending
        // Pass 2 (middle priority): Goal Difference descending
        // Pass 3 (highest priority): Points descending
        List<Team> multiPass = new ArrayList<>(tieTeams);
        Collections.sort(multiPass, Comparator.comparing(Team::getName));
        multiPass.sort(Comparator.comparingInt(Team::getGoalDifference).reversed());
        multiPass.sort(Comparator.comparingInt(Team::getPoints).reversed());
        Leaderboard.printStandings("Via 3 stable sorting passes", multiPass);
        System.out.println("Chained Comparator matches 3 stable passes: "
                + tieBoard.getEntries().equals(multiPass));

        System.out.println("\n--- Extended Test 3: Lower-Bounded Wildcard Copy & Comparator Consistency ---");
        List<Object> archive = new ArrayList<>();
        tieBoard.copyStandingsTo(archive);
        System.out.println("Copied standings count into List<Object>: " + archive.size());

        // Demonstrating why Comparator must be consistent with equals() when used in TreeSet:
        Comparator<Team> pointsOnlyComparator = Comparator.comparingInt(Team::getPoints).reversed();
        Set<Team> inconsistentTreeSet = new TreeSet<>(pointsOnlyComparator);
        inconsistentTreeSet.add(new Team("Bisons", 9, 4));
        inconsistentTreeSet.add(new Team("Panthers", 9, 4)); // compare() == 0, treated as duplicate!
        System.out.println("Points-only Comparator in TreeSet drops Panthers -> size = "
                + inconsistentTreeSet.size() + " : " + inconsistentTreeSet);

        Set<Team> consistentTreeSet = new TreeSet<>(fullRankingComparator);
        consistentTreeSet.add(new Team("Bisons", 9, 4));
        consistentTreeSet.add(new Team("Panthers", 9, 4));
        System.out.println("Consistent full Comparator in TreeSet keeps both -> size = "
                + consistentTreeSet.size() + " : " + consistentTreeSet);
    }
}
