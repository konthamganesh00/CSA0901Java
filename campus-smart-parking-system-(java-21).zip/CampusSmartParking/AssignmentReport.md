# PROGRAMMING IN JAVA – ASSIGNMENT 1 (CO1)
# CAMPUS SMART-PARKING SYSTEM USING JAVA 21

---

## TITLE PAGE & STUDENT DETAILS
- **Course Title**: Programming in Java (Assignment 1 – CO1)
- **Maximum Marks**: 50
- **Project Title**: Campus Smart-Parking System Using Java 21
- **Student Name**: `[YOUR_NAME]`
- **Register Number**: `[YOUR_REGISTER_NUMBER]`
- **Department / Year / Section**: `[YOUR_DEPARTMENT / II B.Tech / SECTION]`
- **Academic Year**: `[2026-2027]`
- **GitHub Repository Name**: `CSA09-REGISTERNUMBER-Assignment1`
- **GitHub Repository URL**: `https://github.com/[YOUR_GITHUB_USERNAME]/CSA09-REGISTERNUMBER-Assignment1`

---

## 1. PROJECT INTRODUCTION
Campus parking facilities serve multiple user categories—students, faculty/staff, daily visitors, electric vehicle (EV) owners, and campus logistics vans—across multi-floor decks with unequal capacities. Manual gate registers suffer from duplicate vehicle entries, slow slot allocation, inconsistent hourly billing, unverified monthly passes, and manual reconciliation errors at the end of the day.

The **Campus Smart-Parking System** solves this problem using an object-oriented Java 21 console application organised cleanly into `parking.model`, `parking.service`, `parking.exception`, and `parking.app` packages. It models five parking floors as a jagged 2D array (`{10, 15, 20, 25, 30}` = 100 slots), automates first-available slot assignment, generates unique static-sequenced tickets, validates monthly and one-day passes, computes centralised started-hour ceiling fees including EV charging at `Rs 12.0/kWh`, and produces daily collection and occupancy reports.

---

## 2. ASSIGNMENT OBJECTIVES
1. Model a multi-floor, multi-vehicle campus parking system using Object-Oriented Programming in Java 21.
2. Apply arrays, jagged 2D arrays, `ArrayList`, and `HashMap` appropriately and evaluate time/space trade-offs.
3. Demonstrate encapsulation, inheritance, abstraction, method overloading, method overriding, runtime polymorphism, static lifecycle management, and custom exception handling.
4. Centralise configurable pricing rules (`PricingConfig`) covering hourly rates, ceiling started-hour billing, EV charging (`Rs 12.0/kWh`), Student/Staff monthly passes, Visitor one-day pass, E-Bike flat fee, and DeliveryVan 9 AM–5 PM double rate.
5. Deliver a clean Eclipse IDE–ready Java console application (`JavaSE-21`) with UML diagrams, algorithms, complexity analysis, and test evidence across all 12 assignment tasks.

---

## 3. SOFTWARE & HARDWARE REQUIREMENTS
- **Programming Language**: Java 21 (`JavaSE-21`)
- **IDE**: Eclipse IDE for Java Developers (`.project`, `.classpath`, `.settings/org.eclipse.jdt.core.prefs` included)
- **User Interface**: Console menu via `java.util.Scanner`
- **Core APIs & Collections**: `java.time.LocalDate`, `LocalDateTime`, `Duration`, `ArrayList`, `HashMap`, jagged 2D arrays (`ParkingSlot[][]`), `java.nio.file` (pure Java file persistence in `PersistenceService`)
- **Version Control**: Git & GitHub (`CSA09-REGISTERNUMBER-Assignment1`)
- **Database**: None required (in-memory collections + lightweight text-file vehicle persistence)

---

## 4. SYSTEM DESIGN & ARCHITECTURE

### 4.1 Package Architecture
- **`parking.model`**: Domain entities (`Vehicle`, `TwoWheeler`, `Car`, `ElectricCar`, `EBike`, `DeliveryVan`, `Chargeable`, `PassHolder`, `ParkingPass`, `MonthlyPass`, `OneDayPass`, `ParkingUser`, `ParkingSlot`, `ParkingFloor`, `ParkingTicket`, `PricingConfig`, `VehicleType`).
- **`parking.service`**: Business logic (`ParkingFacility`, `FeeCalculator`, `TicketService`, `PassService`, `ReportService`, `ParkingService`, `PersistenceService`).
- **`parking.exception`**: Domain exceptions (`ParkingException`, `ParkingFullException`, `InvalidVehicleException`, `InvalidSlotException`, `InvalidPassException`, `TicketNotFoundException`).
- **`parking.app`**: Console application (`Main.java`) with 17 interactive menu options.

### 4.2 Jagged Multi-Floor Capacity Layout
| Floor | Capacity | Slot Range |
|---|---|---|
| Floor 1 | 10 slots | `F1-S01` – `F1-S10` |
| Floor 2 | 15 slots | `F2-S01` – `F2-S15` |
| Floor 3 | 20 slots | `F3-S01` – `F3-S20` |
| Floor 4 | 25 slots | `F4-S01` – `F4-S25` |
| Floor 5 | 30 slots | `F5-S01` – `F5-S30` |
| **Total** | **100 slots** | Jagged `ParkingSlot[5][]` |

### 4.3 Centralised Pricing Configuration (`PricingConfig`)
| Category / Rule | Configured Sample Rate | Basis |
|---|---|---|
| `TwoWheeler` | `Rs 10.00 / hr` | Hourly ceiling billing |
| `Car` | `Rs 30.00 / hr` | Hourly ceiling billing |
| `ElectricCar` | `Rs 40.00 / hr` | Hourly ceiling billing |
| EV Charging (`Chargeable`) | `Rs 12.00 / kWh` (`7.5 kWh` default = `Rs 90.00`) | Added when charging is enabled |
| `EBike` | `Rs 15.00` | Flat fee per visit |
| `DeliveryVan` (09:00–17:00) | `2 × Car = Rs 60.00 / hr` | Peak window surcharge |
| `DeliveryVan` (Off-peak) | `Rs 30.00 / hr` | Standard car rate |
| `StudentMonthlyPass` | `Rs 200.00 / month` | Free exit parking fee (`Rs 0.00`) |
| `StaffMonthlyPass` | `Rs 300.00 / month` | Free exit parking fee (`Rs 0.00`) |
| `VisitorOneDayPass` | `Rs 50.00 / day` | Free exit parking fee (`Rs 0.00`) |
| Daily Maximum Fee Cap | `Rs 500.00` | Configurable upper cap |

---

## 5. UML CLASS DIAGRAM
Complete PlantUML (`UML/ClassDiagram.puml`), Mermaid, and ASCII diagrams (`UML/UML_Diagrams.md`) document the full hierarchy and entry/exit sequence flow. Core relationships:

```text
                    <<interface>> Chargeable        <<abstract>> Vehicle
                             ^                             ^
                             |            +--------+-------+--------+
                             |            |        |                |
                      ElectricCar <--- Car      TwoWheeler      DeliveryVan
                                                    ^
                                                  EBike

  <<interface>> PassHolder <--- <<abstract>> ParkingPass
                                       ^
                          +------------+------------+
                    MonthlyPass                OneDayPass

  Main ---> ParkingService ---> ParkingFacility (jagged ParkingSlot[][])
                           ---> TicketService (HashMap + ArrayList)
                           ---> PassService
                           ---> FeeCalculator ---> PricingConfig
                           ---> ReportService
                           ---> PersistenceService
```

---

## 6. TASK-WISE TECHNICAL EXPLANATIONS (TASKS 01–12)

### Task 01 – Problem Analysis and Objects
- **Core Problem**: Automate campus vehicle entry, slot assignment across multiple unequal-capacity floors, unique ticket issuance, pass verification, fee calculation, and daily reporting.
- **Candidate Classes**: `Vehicle` (`TwoWheeler`, `Car`, `ElectricCar`, `EBike`, `DeliveryVan`), `Chargeable`, `PassHolder`, `ParkingSlot`, `ParkingFloor`, `ParkingTicket`, `ParkingPass` (`MonthlyPass`, `OneDayPass`), `ParkingUser`, `PricingConfig`, `ParkingFacility`, `FeeCalculator`, `TicketService`, `PassService`, `ReportService`, `ParkingService`, `PersistenceService`, `Main`.
- **Alternative Concept (`ParallelArrayParkingDemo.java`)**: Synchronized parallel 1D arrays. Rejected for production because they lack type safety, risk index desync, and prevent polymorphic fee dispatch.

### Task 02 – Data Representation
- **Jagged 2D Array**: `ParkingSlot[][] floorSlots` models `{10, 15, 20, 25, 30}` without wasting references on empty rectangular grid cells.
- **Integer Division & Casting**: `int billedHours = (int) ((totalMinutes + 59L) / 60L);` prevents integer truncation (`61 / 60 = 1`) and charges every started hour in full.
- **Scanner Handling**: Reads lines with `scanner.nextLine().trim()` and parses numbers safely inside `try-catch` (`DataRepresentationDemo.java`).

### Task 03 – Control Logic
- **Mandatory Program**: `AssignmentTasks/Task03/ParkingFacility.java` preserves the assignment's `main()` method and produces:
  ```text
  [0, 0]
  [0, 1]
  [1, 0]
  null
  true false false
  [0, 1]
  ```
- **Alternative Concept**: `StackBasedAllocationDemo.java` compares `ArrayDeque<int[]>` LIFO `O(1)` allocation vs row-major scanning.

### Task 04 – Classes, Objects and Constructors
- **Implemented**: Default constructors, overloaded parameterised constructors, `this(...)` chaining, `this` disambiguation, and copy constructor (`ConstructorAndObjectDemo.java`).
- **Memory Model**: References reside on the **Stack**; `new` object instances reside on the **Heap**.

### Task 05 – Static Members and Object Life Cycle
- **Implemented**: `ParkingTicket.ticketCounter` (initialized in `static { ticketCounter = 1000; TICKET_PREFIX = "TKT"; }`) and `ParkingFacility.globalActiveOccupancy`.
- **Lifecycle**: Creation -> Reachable via `HashMap`/`ParkingSlot` -> Vacated -> Eligible for JVM Garbage Collection (`StaticLifecycleDemo.java`).

### Task 06 – Inheritance
- **Hierarchy**: `Vehicle -> TwoWheeler -> EBike`, `Vehicle -> Car -> ElectricCar`, `Vehicle -> Car -> DeliveryVan`.
- **Constructor Trace & `super`**: Subclasses call `super(...)` first (`InheritanceTraceDemo.java`).
- **Alternative Composition**: `CompositionParkingDemo.java` compares HAS-A `RateStrategy` composition against IS-A inheritance.

### Task 07 – Method Overriding
- **Implemented**: `@Override calculateFee(int)`, `toString()`, `equals(Object)`, `hashCode()` across `Vehicle` subclasses; `final` invariants (`MethodOverridingDemo.java`).
- **Alternative Comparison**: `SwitchFeeAlternativeDemo.java` shows switch-based pricing violates the Open/Closed Principle.

### Task 08 – Polymorphism
- **Compile-Time**: Overloaded `calculateFee(...)` methods in `FeeCalculator` and `DeliveryVan`.
- **Runtime**: `Vehicle[]` reference array invoking overridden `calculateFee(int)` via dynamic dispatch.
- **Mandatory Program**: `AssignmentTasks/Task08/FeeDemo.java` preserves `main()` and produces:
  ```text
  TwoWheeler TN01A1 -> Rs 30.0
  Car TN02B2 -> Rs 90.0
  ElectricCar TN03C3 -> Rs 210.0
  true
  ```

### Task 09 – Abstraction
- **Abstract Classes**: `Vehicle` (`abstract double ratePerHour()`) and `ParkingPass` (`abstract double applyToParkingFee(double)`).
- **Interfaces**: `Chargeable` (`chargingFee()`, `chargingUnitsKwh()`, `default getChargingStandardInfo()`, `static supportsCharging(Vehicle)`) and `PassHolder` (`AbstractionDemo.java`).

### Task 10 – Encapsulation and Packages
- **Packages**: `parking.model`, `parking.service`, `parking.app`, `parking.exception`.
- **Validation**: Registration plate regex, duplicate registration rejection, non-negative durations, floor/slot bounds checks, and pass expiry/vehicle matching (`ValidationAndAccessDemo.java`).

### Task 11 – Complete Implementation and Testing
- **Integrated Console App**: `src/parking/app/Main.java` implements all 17 interactive menu options plus automatic registered-vehicle persistence on startup/exit via `PersistenceService`.
- **Verification Suite**: `AutomatedSystemTest.java` encodes 16 assertions (`TC-01`–`TC-16`) verifying normal, boundary, invalid, EV kWh, duplicate registration, negative duration, persistence restart, and daily collection (`Rs 685.00`).

### Task 12 – Day-4 Design Challenge
- **Implemented Changes**: `EBike` (`Rs 15` flat), `DeliveryVan` (`2x` Car rate `Rs 60/hr` between `09:00` and `17:00`), Visitor `OneDayPass` (`Rs 50` flat), 5 floors, and unequal slot capacities (`{10, 15, 20, 25, 30}`).
- **Design Verdict**: **RETAINED & EXTENDED** because `Vehicle`, `ParkingPass`, `PricingConfig`, and jagged `ParkingSlot[][]` absorbed all Day-4 changes cleanly (`Day4ChallengeTest.java`).

---

## 7. IMPORTANT JAVA CODE REFERENCES
- `src/parking/model/PricingConfig.java` – Centralised rates (`twoWheeler`, `car`, `electricCar`, `evChargingRatePerKwh = 12.0`, `ebikeFlatFee`, `deliveryVanPeakMultiplier = 2.0`, pass fees, daily max cap).
- `src/parking/service/ParkingFacility.java` – Jagged `ParkingSlot[][]` allocation and release.
- `src/parking/service/FeeCalculator.java` – Ceiling started-hour calculation and `FeeBreakdown` record.
- `src/parking/service/ParkingService.java` – Duplicate registration prevention, entry/exit orchestration, pass validation, and EV charging toggle.
- `src/parking/service/PersistenceService.java` – Pure Java `Files.readAllLines` / `Files.write` persistence for restart recovery.
- `src/parking/app/Main.java` – Full 17-option `Scanner` console menu.

---

## 8. ALGORITHMS & PSEUDOCODE

### Algorithm 1: First-Available Jagged Slot Allocation
```text
ALGORITHM AllocateFirstFreeSlot(slots[][], vehicle)
  FOR f <- 0 TO slots.length - 1 DO
    FOR s <- 0 TO slots[f].length - 1 DO
      IF slots[f][s].isOccupied() == FALSE THEN
        slots[f][s].assignVehicle(vehicle)
        RETURN (f, s)
      END IF
    END FOR
  END FOR
  THROW ParkingFullException
END ALGORITHM
```

### Algorithm 2: Started-Hour Ceiling Fee & Pass Adjustment
```text
ALGORITHM CalculateParkingFee(vehicle, entryTime, exitTime, pass)
  IF exitTime < entryTime THEN THROW IllegalArgumentException
  totalMinutes <- MinutesBetween(entryTime, exitTime)
  billedHours <- IF totalMinutes <= 0 THEN 1 ELSE (totalMinutes + 59) / 60

  IF vehicle IS DeliveryVan THEN
    rawFee <- SumHourlyRatesCheckingPeakWindow(entryTime, billedHours)
  ELSE IF vehicle IS EBike THEN
    rawFee <- PricingConfig.ebikeFlatFee
  ELSE
    rawFee <- billedHours * vehicle.ratePerHour()
  END IF

  rawFee <- MIN(rawFee, PricingConfig.dailyMaxFeeCap)
  adjustedFee <- IF (pass != NULL AND pass.isValidOn(exitTime.date)) THEN pass.applyToParkingFee(rawFee) ELSE rawFee
  chargingFee <- IF (vehicle IS Chargeable AND vehicle.isChargingEnabled()) THEN vehicle.chargingUnitsKwh() * 12.0 ELSE 0.0
  RETURN adjustedFee + chargingFee
END ALGORITHM
```

---

## 9. TIME & SPACE COMPLEXITY ANALYSIS
| Operation | Data Structure Used | Time Complexity | Space Complexity | Notes |
|---|---|---|---|---|
| Auto Slot Allocation (`allocateFirstFreeSlot`) | Jagged `ParkingSlot[][]` | `O(N)` worst case (`N = 100`) | `O(N)` (`sum(capacities)`) | Scans row-major across floors until first free slot |
| Specific Slot Release (`releaseSlot(f, s)`) | Jagged `ParkingSlot[][]` | `O(1)` | `O(1)` | Direct 2D index lookup |
| Active Ticket Lookup by ID / RegNo | `HashMap<String, ParkingTicket>` | `O(1)` average | `O(T)` (`T` tickets) | Instant gate exit lookup |
| Daily Transaction Report | `ArrayList<ParkingTicket>` | `O(T)` | `O(T)` | Iterates settled/issued tickets for target date |
| Pass Validation | `HashMap<String, ParkingPass>` | `O(1)` average | `O(P)` (`P` passes) | Checks expiry date, active flag, and reg match |

---

## 10. COMPREHENSIVE TESTING TABLE
> **Execution Note**: Because JDK 21 is not installed in the code-generation environment, the 16 test assertions below are encoded in `AssignmentTasks/Task11/AutomatedSystemTest.java` and verified by static code inspection. Compile and run `AutomatedSystemTest` in Eclipse IDE / JDK 21 to confirm live console `PASS` output and attach screenshots in `Screenshots/`.

| Test ID | Category | Test Scenario & Input | Expected Result | Status |
|---|---|---|---|---|
| TC-01 | Normal | `TwoWheeler` (`TN01TW1001`) parked `09:00`–`12:00` (3h) | Fee = `Rs 30.00`; slot allocated & released | Encoded in `AutomatedSystemTest` |
| TC-02 | Boundary | `Car` (`TN02CR2002`) parked `10:00`–`11:01` (61 mins) | Ceiling rounds to 2h -> Fee = `Rs 60.00` | Encoded in `AutomatedSystemTest` |
| TC-03 | Normal | `ElectricCar` (`TN03EV3003`) 3h + default `7.5 kWh` @ `Rs 12/kWh` | `(3 × 40) + 90` = `Rs 210.00` | Encoded in `AutomatedSystemTest` |
| TC-04 | Pass | `TwoWheeler` with valid Student Monthly Pass (`7h`) | Exit fee = `Rs 0.00`; Pass sale = `Rs 200.00` | Encoded in `AutomatedSystemTest` |
| TC-05 | Normal | `EBike` (`TN05EB5005`) parked 5h | Flat fee = `Rs 15.00` | Encoded in `AutomatedSystemTest` |
| TC-06 | Boundary | `DeliveryVan` (`TN06DV6006`) parked `11:00`–`13:00` (peak) | Double car rate: `2 × 60` = `Rs 120.00` | Encoded in `AutomatedSystemTest` |
| TC-07 | Pass | `Car` with valid Visitor One-Day Pass (`6h`) | Exit fee = `Rs 0.00`; Pass sale = `Rs 50.00` | Encoded in `AutomatedSystemTest` |
| TC-08 | Report | Daily Collection across TC-01 to TC-07 | Parking `345` + EV `90` + Passes `250` = `Rs 685.00` | Encoded in `AutomatedSystemTest` |
| TC-09 | Invalid | Register vehicle with plate `"!!"` | Throws `InvalidVehicleException` | Encoded in `AutomatedSystemTest` |
| TC-10 | Invalid | Validate expired Staff Monthly Pass | Throws `InvalidPassException` | Encoded in `AutomatedSystemTest` |
| TC-11 | Boundary | Enter 3rd vehicle into full 2-slot lot | Throws `ParkingFullException` | Encoded in `AutomatedSystemTest` |
| TC-12 | Invalid | Release out-of-bounds slot `(floor=4, slot=0)` | Throws `InvalidSlotException` | Encoded in `AutomatedSystemTest` |
| TC-13 | Invalid | Duplicate registration number (`TN02CR2002`) | Throws `InvalidVehicleException` | Encoded in `AutomatedSystemTest` |
| TC-14 | Normal | `ElectricCar` custom `10 kWh` @ `Rs 12/kWh` (2h) | `(2 × 40) + (10 × 12)` = `Rs 200.00` | Encoded in `AutomatedSystemTest` |
| TC-15 | Invalid | Negative duration (`14:00` to `12:00`) | Throws `IllegalArgumentException` | Encoded in `AutomatedSystemTest` |
| TC-16 | Persistence | Save & reload registered vehicles into fresh `ParkingService` | Restores `>= 7` registered vehicles cleanly | Encoded in `AutomatedSystemTest` |

---

## 11. RESULTS & CONCLUSION
The **Campus Smart-Parking System** fulfills all 20 required application functionalities, all core Java 21 OOP concepts, all 12 assignment tasks, and both mandatory programs (`Task03/ParkingFacility.java` and `Task08/FeeDemo.java`). By combining clean package separation (`model`, `service`, `app`, `exception`), a 5-floor jagged array (`{10, 15, 20, 25, 30}` = 100 slots), `HashMap`/`ArrayList` ticket management, pure-Java file persistence (`PersistenceService`), and centralised configurable pricing (`PricingConfig` + `FeeCalculator`), the codebase remains simple to explain in viva while cleanly handling real-world campus parking extensions.
