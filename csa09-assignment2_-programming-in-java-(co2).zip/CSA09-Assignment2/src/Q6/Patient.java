package Q6;

/**
 * Q6 - Patient Model for Hospital Emergency Triage
 * Severity 1 = critical (highest priority), Severity 5 = non-urgent (lowest priority).
 * arrivalSeq preserves strict FIFO order among patients with equal severity.
 */
public class Patient {

    private final String name;
    private final int severity;
    private final long arrivalSeq;

    public Patient(String name, int severity, long arrivalSeq) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Patient name cannot be null or blank.");
        }
        if (severity < 1 || severity > 5) {
            throw new IllegalArgumentException("Severity must be between 1 and 5: " + severity);
        }
        if (arrivalSeq < 1L) {
            throw new IllegalArgumentException("Arrival sequence must be positive: " + arrivalSeq);
        }
        this.name = name;
        this.severity = severity;
        this.arrivalSeq = arrivalSeq;
    }

    public String getName() {
        return name;
    }

    public int getSeverity() {
        return severity;
    }

    public long getArrivalSeq() {
        return arrivalSeq;
    }

    @Override
    public String toString() {
        return name + "(S" + severity + ")";
    }
}
