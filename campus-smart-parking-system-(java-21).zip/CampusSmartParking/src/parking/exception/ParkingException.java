package parking.exception;

/**
 * Base checked exception for all Campus Smart-Parking System domain errors.
 */
public class ParkingException extends Exception {

    private static final long serialVersionUID = 1L;

    public ParkingException(String message) {
        super(message);
    }

    public ParkingException(String message, Throwable cause) {
        super(message, cause);
    }
}
