# TASK 2 – Data Representation

## 1. Data Types for Important Fields

| Field | Java Data Type | Justification |
|---|---|---|
| `registrationNumber` | `String` | Alphanumeric license plates (`TN01AB1234`) |
| `floorNumber`, `slotNumber` | `int` | Discrete integer indices and counts |
| `billedHours` | `int` | Whole started hours after ceiling rounding |
| `ratePerHour`, `totalFee` | `double` | Monetary rupee amounts with decimal precision |
| `occupied`, `chargingRequested` | `boolean` | Binary state flags |
| `entryTime`, `exitTime` | `java.time.LocalDateTime` | Accurate date-time duration and peak-hour checks |
| `issueDate`, `expiryDate` | `java.time.LocalDate` | Calendar date pass validity |
| `floorSlots` | `ParkingSlot[][]` | Jagged 2D array modeling variable floor capacities |
| `activeTicketsByRegNo` | `HashMap<String, ParkingTicket>` | O(1) lookup by registration plate |
| `ticketHistory` | `ArrayList<ParkingTicket>` | Dynamic chronological log of all tickets |

## 2. Array and Jagged Array Representation
A rectangular 2D array (`new ParkingSlot[5][20]`) forces every floor to share the same capacity. Because real campus parking decks have different structural sizes (e.g., Floor 1 = 10 slots, Floor 2 = 15, Floor 3 = 20, Floor 4 = 25, Floor 5 = 30), Java's **jagged array** allocates each row independently:
```java
ParkingSlot[][] floorSlots = new ParkingSlot[floorCapacities.length][];
for (int f = 0; f < floorCapacities.length; f++) {
    floorSlots[f] = new ParkingSlot[floorCapacities[f]];
}
```

## 3. Scanner Input Handling & Type Conversion
Reading raw lines via `scanner.nextLine().trim()` and explicitly converting with `Integer.parseInt(...)` or `Double.parseDouble(...)` inside `try-catch (NumberFormatException)` prevents the classic `Scanner.nextInt()` newline-skipping bug and recovers cleanly from invalid user text.

## 4. Integer Division and Casting
In Java, dividing two `int` values truncates toward zero:
- `61 / 60` evaluates to `1` (losing 1 minute of a started second hour).
- **Correct Ceiling Integer Arithmetic**: `(minutes + 59) / 60` evaluates `(61 + 59) / 60 = 120 / 60 = 2`.
- **Widening & Narrowing Cast**: `(int) Math.ceil((double) minutes / 60)` converts `minutes` to `double` before division, preventing truncation.

## 5. Alternative Comparison: Jagged 2D Array vs Flattened 1D Array vs ArrayList

| Structure | Random Access | Variable Floor Sizes | Memory Overhead | Best Use Case |
|---|---|---|---|---|
| **Jagged 2D Array (`ParkingSlot[][]`)** | `O(1)` via `[floor][slot]` | Native row lengths | Minimal (`O(N)` object refs) | Fixed-floor multi-deck parking layout |
| **Flattened 1D Array (`ParkingSlot[]`)** | `O(1)` via offset math | Needs separate `prefixSum[]` array | Lowest | Homogeneous single-lot or GPU-style buffers |
| **`ArrayList<ArrayList<ParkingSlot>>`** | `O(1)` amortized `.get()` | Native | Higher (boxing/list wrappers) | Dynamically adding/removing slots at runtime |

## 6. Complexity Summary
- Building jagged facility of `N` total slots across `F` floors: **Time `O(N)`**, **Space `O(N)`**.
- Accessing any slot `(f, s)`: **Time `O(1)`**, **Space `O(1)`**.
