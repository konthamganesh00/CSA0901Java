package parking.model;

/**
 * Represents a standard four-wheeler car.
 */
public class Car extends Vehicle {

    private int numberOfDoors;

    public Car() {
        this("UNREGISTERED", "Campus Driver", "0000000000", 4);
    }

    public Car(String registrationNumber, String ownerName) {
        this(registrationNumber, ownerName, "N/A", 4);
    }

    public Car(String registrationNumber, String ownerName, String contactNumber, int numberOfDoors) {
        this(registrationNumber, ownerName, contactNumber, numberOfDoors, VehicleType.CAR);
    }

    protected Car(String registrationNumber, String ownerName, String contactNumber,
                  int numberOfDoors, VehicleType vehicleType) {
        super(registrationNumber, ownerName, contactNumber, vehicleType);
        this.numberOfDoors = Math.max(2, numberOfDoors);
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public void setNumberOfDoors(int numberOfDoors) {
        if (numberOfDoors >= 2) {
            this.numberOfDoors = numberOfDoors;
        }
    }

    @Override
    public double ratePerHour() {
        return PricingConfig.getCarRatePerHour();
    }

    @Override
    public double calculateFee(int hours) {
        if (hours <= 0) {
            return 0.0;
        }
        return hours * ratePerHour();
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" [Doors=%d]", numberOfDoors);
    }
}
