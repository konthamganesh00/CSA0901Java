import java.util.Scanner;

/**
 * Task 01 - Alternative Design Demonstration using Parallel String Arrays.
 * Compares procedural parallel-array storage against the Object-Oriented Vehicle/Slot model.
 */
public class ParallelArrayParkingDemo {

    private static final int MAX_SLOTS = 5;

    public static void main(String[] args) {
        String[] slotCodes = {"F1-S01", "F1-S02", "F1-S03", "F1-S04", "F1-S05"};
        String[] regNumbers = new String[MAX_SLOTS];
        String[] vehicleTypes = new String[MAX_SLOTS];
        boolean[] occupied = new boolean[MAX_SLOTS];

        // Park two sample vehicles using parallel arrays
        parkVehicle(slotCodes, regNumbers, vehicleTypes, occupied, "TN01A1001", "Car");
        parkVehicle(slotCodes, regNumbers, vehicleTypes, occupied, "TN01B2002", "TwoWheeler");

        System.out.println("=== Parallel Array Parking State ===");
        for (int i = 0; i < MAX_SLOTS; i++) {
            if (occupied[i]) {
                System.out.printf("%s -> %s (%s)%n", slotCodes[i], regNumbers[i], vehicleTypes[i]);
            } else {
                System.out.printf("%s -> FREE%n", slotCodes[i]);
            }
        }

        // Release first vehicle
        releaseVehicle(regNumbers, vehicleTypes, occupied, "TN01A1001");
        System.out.println("After TN01A1001 exit, F1-S01 occupied? " + occupied[0]);
    }

    private static boolean parkVehicle(String[] slotCodes, String[] regNumbers,
                                       String[] vehicleTypes, boolean[] occupied,
                                       String regNo, String type) {
        for (int i = 0; i < slotCodes.length; i++) {
            if (!occupied[i]) {
                occupied[i] = true;
                regNumbers[i] = regNo;
                vehicleTypes[i] = type;
                return true;
            }
        }
        return false;
    }

    private static boolean releaseVehicle(String[] regNumbers, String[] vehicleTypes,
                                          boolean[] occupied, String regNo) {
        for (int i = 0; i < occupied.length; i++) {
            if (occupied[i] && regNo.equalsIgnoreCase(regNumbers[i])) {
                occupied[i] = false;
                regNumbers[i] = null;
                vehicleTypes[i] = null;
                return true;
            }
        }
        return false;
    }
}
