package assignment_3;


class ScannerStation extends Thread {

    private int scripts;

    ScannerStation(String name, int scripts) {
        super(name);
        this.scripts = scripts;
    }

    public void run() {
        try {
            for (int i = 1; i <= scripts; i++) {
                System.out.println(getName() + " scanning script " + i);
                Thread.sleep(500);
            }

            System.out.println(getName() + " completed " + scripts + " scripts");

        } catch (InterruptedException e) {
            System.out.println(getName() + " interrupted");
        }
    }
}

class RunnableStation implements Runnable {

    private int scripts;
    private String stationName;

    RunnableStation(String stationName, int scripts) {
        this.stationName = stationName;
        this.scripts = scripts;
    }

    public void run() {
        try {
            for (int i = 1; i <= scripts; i++) {
                System.out.println(stationName + " scanning script " + i);
                Thread.sleep(500);
            }

            System.out.println(stationName + " completed " + scripts + " scripts");

        } catch (InterruptedException e) {
            System.out.println(stationName + " interrupted");
        }
    }
}

public class Q4ThreadScanning {

    public static void main(String[] args) throws InterruptedException {

        ScannerStation s1 = new ScannerStation("Station 1", 3);
        ScannerStation s2 = new ScannerStation("Station 2", 3);

        Thread s3 = new Thread(new RunnableStation("Station 3", 3));
        Thread s4 = new Thread(new RunnableStation("Station 4", 3));

        // Set thread priorities
        s1.setPriority(Thread.MAX_PRIORITY);
        s2.setPriority(Thread.MIN_PRIORITY);

        // Start all threads
        s1.start();
        s2.start();
        s3.start();
        s4.start();

        System.out.println("Station 1 alive: " + s1.isAlive());

        // Wait for all threads to finish
        s1.join();
        s2.join();
        s3.join();
        s4.join();

        System.out.println("All scanning stations completed.");
        System.out.println("Station 1 alive: " + s1.isAlive());
    }
}
