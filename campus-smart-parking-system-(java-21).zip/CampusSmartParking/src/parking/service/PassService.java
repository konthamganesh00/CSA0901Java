package parking.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import parking.exception.InvalidPassException;
import parking.model.MonthlyPass;
import parking.model.OneDayPass;
import parking.model.ParkingPass;

/**
 * Manages issuance, lookup, validation, renewal, and revocation of Student Monthly Passes,
 * Staff Monthly Passes, and Visitor One-Day Passes.
 */
public class PassService {

    private final Map<String, ParkingPass> passesById = new HashMap<>();
    private final Map<String, ParkingPass> passesByVehicleReg = new HashMap<>();
    private final List<ParkingPass> allPasses = new ArrayList<>();

    public MonthlyPass issueMonthlyPass(MonthlyPass.PassCategory category, String holderId,
                                        String holderName, String vehicleRegNo, int durationMonths)
            throws InvalidPassException {
        if (category == null) {
            throw new InvalidPassException("Monthly pass category (STUDENT/STAFF) is required.");
        }
        if (holderName == null || holderName.isBlank()) {
            throw new InvalidPassException("Pass holder name cannot be empty.");
        }
        if (vehicleRegNo == null || vehicleRegNo.isBlank()) {
            throw new InvalidPassException("Vehicle registration number is required for a pass.");
        }
        int months = Math.max(1, durationMonths);
        LocalDate issueDate = LocalDate.now();
        LocalDate expiryDate = issueDate.plusMonths(months);

        MonthlyPass pass = new MonthlyPass(category, holderId, holderName, vehicleRegNo, issueDate, expiryDate);
        registerPass(pass);
        return pass;
    }

    public OneDayPass issueOneDayPass(String visitorId, String visitorName, String vehicleRegNo,
                                      LocalDate validDate) throws InvalidPassException {
        if (visitorName == null || visitorName.isBlank()) {
            throw new InvalidPassException("Visitor name cannot be empty.");
        }
        if (vehicleRegNo == null || vehicleRegNo.isBlank()) {
            throw new InvalidPassException("Vehicle registration number is required for a one-day pass.");
        }
        LocalDate date = (validDate == null) ? LocalDate.now() : validDate;
        OneDayPass pass = new OneDayPass(visitorId, visitorName, vehicleRegNo, date);
        registerPass(pass);
        return pass;
    }

    public void registerPass(ParkingPass pass) {
        if (pass != null) {
            passesById.put(pass.getPassId().toUpperCase(), pass);
            if (!pass.getVehicleRegistrationNumber().isBlank()) {
                passesByVehicleReg.put(pass.getVehicleRegistrationNumber().toUpperCase(), pass);
            }
            allPasses.add(pass);
        }
    }

    public ParkingPass getPassById(String passId) throws InvalidPassException {
        if (passId == null || passId.isBlank()) {
            throw new InvalidPassException("Pass ID cannot be empty.");
        }
        ParkingPass pass = passesById.get(passId.trim().toUpperCase());
        if (pass == null) {
            throw new InvalidPassException("Parking pass not found: " + passId);
        }
        return pass;
    }

    /**
     * Validates a pass by ID for a given vehicle and date. Throws InvalidPassException if expired or mismatched.
     */
    public ParkingPass validatePass(String passId, String vehicleRegNo, LocalDate date)
            throws InvalidPassException {
        ParkingPass pass = getPassById(passId);
        if (!pass.isActive()) {
            throw new InvalidPassException("Pass " + pass.getPassId() + " has been revoked.");
        }
        LocalDate checkDate = (date == null) ? LocalDate.now() : date;
        if (!pass.isValidOn(checkDate)) {
            throw new InvalidPassException("Pass " + pass.getPassId() + " is expired (Valid: "
                    + pass.getIssueDate() + " to " + pass.getExpiryDate() + ").");
        }
        if (vehicleRegNo != null && !vehicleRegNo.isBlank()
                && !pass.getVehicleRegistrationNumber().isBlank()) {
            String normalizedReg = vehicleRegNo.trim().toUpperCase().replaceAll("\\s+", "");
            if (!pass.getVehicleRegistrationNumber().equalsIgnoreCase(normalizedReg)) {
                throw new InvalidPassException("Pass " + pass.getPassId()
                        + " is registered to vehicle " + pass.getVehicleRegistrationNumber()
                        + ", not " + normalizedReg + ".");
            }
        }
        return pass;
    }

    public ParkingPass findPassForVehicle(String vehicleRegNo) {
        if (vehicleRegNo == null || vehicleRegNo.isBlank()) {
            return null;
        }
        String normalized = vehicleRegNo.trim().toUpperCase().replaceAll("\\s+", "");
        return passesByVehicleReg.get(normalized);
    }

    public void revokePass(String passId) throws InvalidPassException {
        ParkingPass pass = getPassById(passId);
        pass.revoke();
    }

    public List<ParkingPass> getAllPasses() {
        return new ArrayList<>(allPasses);
    }

    public List<MonthlyPass> getMonthlyPasses() {
        List<MonthlyPass> result = new ArrayList<>();
        for (ParkingPass pass : allPasses) {
            if (pass instanceof MonthlyPass mp) {
                result.add(mp);
            }
        }
        return result;
    }

    public List<OneDayPass> getOneDayPasses() {
        List<OneDayPass> result = new ArrayList<>();
        for (ParkingPass pass : allPasses) {
            if (pass instanceof OneDayPass odp) {
                result.add(odp);
            }
        }
        return result;
    }

    public double getTotalOneDayPassRevenueForDate(LocalDate date) {
        double sum = 0.0;
        for (ParkingPass pass : allPasses) {
            if (pass instanceof OneDayPass && pass.getIssueDate().equals(date)) {
                sum += pass.getPurchasePrice();
            }
        }
        return sum;
    }

    public double getTotalMonthlyPassRevenueForDate(LocalDate date) {
        double sum = 0.0;
        for (ParkingPass pass : allPasses) {
            if (pass instanceof MonthlyPass && pass.getIssueDate().equals(date)) {
                sum += pass.getPurchasePrice();
            }
        }
        return sum;
    }
}
