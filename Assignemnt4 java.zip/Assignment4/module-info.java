module Assignment4 {
    requires java.desktop;
    requires java.sql;
}