import java.time.LocalDate;
import java.time.LocalDateTime;
import parking.model.DeliveryVan;
import parking.model.EBike;
import parking.model.OneDayPass;
import parking.model.ParkingTicket;
import parking.service.FeeCalculator;
import parking.service.ParkingFacility;
import parking.service.ParkingService;

/**
 * Task 12 - Day-4 Design Challenge Verification Test.
 * Tests all 5 changed requirements:
 *   1. EBike flat fee (Rs 15.0)
 *   2. DeliveryVan double car rate between 9 AM and 5 PM (Rs 60/hr peak vs Rs 30/hr off-peak)
 *   3. Visitor OneDayPass (Rs 50 flat)
 *   4. 5 Parking Floors
 *   5. Different Slot Capacities per Floor (10, 15, 20, 25, 30)
 */
public class Day4ChallengeTest {

    public static void main(String[] args) throws Exception {
        System.out.println("=== TASK 12: DAY-4 DESIGN CHALLENGE VERIFICATION ===");

        // Requirement 4 & 5: 5 floors with jagged capacities
        ParkingFacility facility = new ParkingFacility(new int[]{10, 15, 20, 25, 30});
        ParkingService service = new ParkingService(facility);
        FeeCalculator calc = service.getFeeCalculator();

        System.out.println("Floors configured : " + facility.getFloorCount());
        System.out.println("Total capacity    : " + facility.getTotalCapacity());

        LocalDate today = LocalDate.now();

        // Requirement 1: EBike flat fee
        EBike ebike = new EBike("TN12EB01", "Vikram", "9000011111", 48);
        ParkingTicket tEBike = service.enterVehicle(ebike, today.atTime(10, 0));
        service.exitVehicleByTicketId(tEBike.getTicketId(), today.atTime(16, 0), null);
        System.out.printf("EBike (6h stay) Fee            : Rs %.2f (Expected: Rs 15.00)%n", tEBike.getTotalFee());

        // Requirement 2a: DeliveryVan inside 9 AM - 5 PM (10:00 - 12:00 = 2 peak hours @ Rs 60/hr)
        DeliveryVan van = new DeliveryVan("TN12DV02", "Campus Courier", "9000022222", 1500.0);
        double peakFee = calc.calculateFee(van, today.atTime(10, 0), today.atTime(12, 0));
        System.out.printf("DeliveryVan Peak (10:00-12:00) : Rs %.2f (Expected: Rs 120.00)%n", peakFee);

        // Requirement 2b: DeliveryVan outside 9 AM - 5 PM (18:00 - 20:00 = 2 off-peak hours @ Rs 30/hr)
        double offPeakFee = calc.calculateFee(van, today.atTime(18, 0), today.atTime(20, 0));
        System.out.printf("DeliveryVan Off-Peak (18-20)   : Rs %.2f (Expected: Rs 60.00)%n", offPeakFee);

        // Requirement 2c: DeliveryVan spanning boundary (16:00 - 18:00 = 1 peak hr + 1 off-peak hr = Rs 90.00)
        double mixedFee = calc.calculateFee(van, today.atTime(16, 0), today.atTime(18, 0));
        System.out.printf("DeliveryVan Mixed (16:00-18:00): Rs %.2f (Expected: Rs 90.00)%n", mixedFee);

        // Requirement 3: Visitor One-Day Pass
        OneDayPass odp = service.getPassService().issueOneDayPass("VIS-404", "Neha", "TN12VIS99", today);
        System.out.println("Issued Visitor Pass            : " + odp);
        LocalDateTime entry = today.atTime(9, 15);
        LocalDateTime exit = today.atTime(17, 45);
        FeeCalculator.FeeBreakdown breakdown = calc.calculateFeeBreakdown(
                new parking.model.Car("TN12VIS99", "Neha"), entry, exit, odp);
        System.out.printf("Visitor with OneDayPass exit   : Rs %.2f (%s)%n",
                breakdown.finalTotalFee(), breakdown.passNote());
    }
}
