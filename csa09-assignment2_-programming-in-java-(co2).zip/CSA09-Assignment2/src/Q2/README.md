# Q2 – ArrayList, LinkedList, and ArrayDeque (Music Playlist Editor)

## Short Explanation
A music playlist editor exercises different access and modification patterns:

- **`ArrayList<String>`** is backed by a contiguous resizable array. It provides **$O(1)$** random access (`get(k)`) and amortized **$O(1)$** append at the end, plus excellent CPU cache locality during iteration. However, inserting or removing at the front or middle requires `System.arraycopy` shifting of subsequent elements (**$O(n)$**).
- **`LinkedList<String>`** is a doubly linked list of `Node` objects. It provides **$O(1)$** insertion and removal at both ends (`addFirst`, `removeFirst`, `addLast`, `removeLast`), but **$O(n)$** random access (`get(k)`) and **$O(n)$** middle insert/remove because it must traverse from the nearest end to reach index `size / 2`. It also carries higher memory overhead (~24–40 extra bytes per node for `prev`/`next` references and object header).
- **`ArrayDeque<String>`** is a resizable circular array (`head` and `tail` indices). It provides amortized **$O(1)$** operations at **both ends** (`addFirst`, `addLast`, `removeFirst`, `removeLast`) without per-node object allocations or pointer chasing, making it ideal for an **"Up Next" playback queue**. Because it does not implement `List`, it does not support indexed middle access (`get(k)`) or middle insertion/removal.
- **Plain Array (`String[]`) with Manual Shifting:** `ArrayList` essentially wraps an `Object[]` array and automates bounds checking, capacity doubling (`Arrays.copyOf`), and element shifting (`System.arraycopy`). Writing manual `for`-loop shifts is error-prone and tedious compared to `ArrayList`.

---

## Complexity Comparison

| Operation | `ArrayList` | `LinkedList` | `ArrayDeque` | Plain `String[]` (Manual) |
|---|---|---|---|---|
| Add at end | $O(1)$ amortized | $O(1)$ | $O(1)$ amortized | $O(1)$ amortized (manual resize) |
| Insert at front | $O(n)$ | $O(1)$ | $O(1)$ amortized | $O(n)$ manual right-shift |
| Insert in middle | $O(n)$ (shift) | $O(n)$ (traverse) | N/A | $O(n)$ manual right-shift |
| Remove at front | $O(n)$ | $O(1)$ | $O(1)$ | $O(n)$ manual left-shift |
| Remove in middle | $O(n)$ (shift) | $O(n)$ (traverse) | N/A | $O(n)$ manual left-shift |
| Access `k`th element | $O(1)$ | $O(n)$ | N/A | $O(1)$ |
| Iterate all songs | $O(n)$ (contiguous) | $O(n)$ (pointer chase) | $O(n)$ (contiguous) | $O(n)$ |
| Extra space per element | ~0 (capacity slack) | 2 pointers + Node header | ~0 (capacity slack) | ~0 |

---

## How to Run
- **User-Friendly Demo + Tests + Benchmark:** Run `Q2.Main`
- **Benchmark Only:** Run `Q2.PlaylistBenchmark`

---

## Sample Input & Expected Output

### Sample Input
- Playlist operations: `Add ["Track-A", "Track-C"]`, insert `"Track-B"` at index `1`
- Benchmark sizes: `1,000`, `10,000`, `50,000` songs (`Track-0` .. `Track-(N-1)`)

### Expected Output Format
```text
[PASS] ArrayList end + middle insert ordering
[PASS] LinkedList addFirst + removeLast ordering
[PASS] ArrayDeque Up Next queue priority front dequeue
[PASS] Boundary test: empty list check and safe pollFirst() returning null
[PASS] Empty ArrayDeque removeFirst() caught cleanly: NoSuchElementException
[PASS] Invalid playlist index caught cleanly: Index 99 out of bounds for length 3
...
Saved raw benchmark measurements to: .../ExperimentalData/Q2_ListBenchmark.csv
```

---

## Test Documentation
- **Normal Tests:** Verified end/middle insert, `LinkedList` front/back ops, and `ArrayDeque` Up Next queue ordering.
- **Boundary Tests:** Verified empty list, safe `pollFirst()` returning `null`, and `removeFirst()` exception on empty deque.
- **Invalid Input Test:** Verified `get(99)` throws `IndexOutOfBoundsException`.
- **Benchmark Protocol:** 2 warmup runs + 5 measured runs per test using `System.nanoTime()`, writing real results to `ExperimentalData/Q2_ListBenchmark.csv`.
