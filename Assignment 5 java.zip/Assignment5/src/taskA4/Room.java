
package taskA4;

import java.io.Serializable;
import java.util.ArrayList;

public class Room implements Serializable {

    private static final long serialVersionUID = 1L;

    int roomNo;
    ArrayList<Resident> residents = new ArrayList<>();

    public Room(int roomNo) {
        this.roomNo = roomNo;
    }

    public void addResident(Resident r) {
        residents.add(r);
    }

    public String toString() {
        return "Room Number: " + roomNo
                + "\nResidents: " + residents;
    }
}
