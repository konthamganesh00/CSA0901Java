# TASK 5 – Static Members and Object Life Cycle

## 1. Static Members Implemented in the System
- **Static Ticket Counter**: `ParkingTicket.ticketCounter` (initialized to `1000` inside a `static { ... }` block) ensures every generated ticket (`TKT-1001`, `TKT-1002`, ...) is globally unique across the entire application lifecycle.
- **Static Total Occupancy**: `ParkingFacility.globalActiveOccupancy` tracks live parked vehicles across all active facility instances.
- **Static Methods**: `ParkingTicket.generateNextTicketId()`, `ParkingTicket.getTotalTicketsIssued()`, `Vehicle.isValidRegistrationNumber(String)`, and `Chargeable.supportsCharging(Vehicle)` perform class-level utility operations without requiring an object instance.
- **Static Block**: Runs exactly once when the JVM classloader loads `ParkingTicket`, initializing shared constants (`TICKET_PREFIX = "TKT"`) and counters before any constructor executes.

## 2. Object Life Cycle & Garbage Collection
Every `ParkingTicket` or `Vehicle` transitions through four stages:
1. **Creation**: Memory allocated on Heap via `new ParkingTicket(...)` and constructor initializes fields.
2. **In-Use (Reachable)**: Referenced by `activeTicketsByRegNo` (`HashMap`) and `ParkingSlot.parkedVehicle`.
3. **Released / Unreferenced**: On vehicle exit, `ParkingSlot.vacate()` sets `parkedVehicle = null` and `TicketService.markTicketSettled()` removes it from the active map (keeping settled records only if retained in `ticketHistory`).
4. **Garbage Collection**: Once no live GC root references an object (e.g., temporary `FeeBreakdown` records or vacated demo objects), the JVM Garbage Collector automatically reclaims its heap memory.

## 3. Static vs Instance Variables Comparison

| Feature | Static Variable (`static`) | Instance Variable (non-static) |
|---|---|---|
| Memory Allocation | Method Area / Metaspace (one shared copy per class) | Heap (separate copy inside every object) |
| Lifetime | From class loading until JVM shutdown / class unloading | From `new` until Garbage Collected |
| Access | `ClassName.variable` | `objectRef.variable` |
| Smart-Parking Example | `ticketCounter`, `globalActiveOccupancy` | `ticketId`, `entryTime`, `slotCode` |

## 4. Complexity and Space Analysis
- **Static counter increment**: `O(1)` time, `O(1)` shared class-level space (`4 bytes` for `int`).
- **Instance fields per ticket**: `O(1)` space per ticket object; `T` tickets consume `O(T)` heap memory total.
