# TASK 8 – Polymorphism

## 1. Compile-Time Polymorphism (Method Overloading)
Multiple methods share the same name with different parameter lists, resolved by the compiler at compile time:
- In `FeeCalculator`: `calculateFee(Vehicle, int)`, `calculateFee(Vehicle, LocalDateTime, LocalDateTime)`, and `calculateFee(Vehicle, LocalDateTime, LocalDateTime, ParkingPass)`.
- In `DeliveryVan`: `ratePerHour()` vs `ratePerHour(LocalTime)` and `calculateFee(int)` vs `calculateFee(int, boolean)` vs `calculateFee(LocalDateTime, LocalDateTime)`.

## 2. Runtime Polymorphism (Dynamic Method Dispatch)
In `FeeDemo`:
- `Vehicle[] vehicles` holds **upcast** references (`TwoWheeler`, `Car`, `ElectricCar`) under the superclass type `Vehicle`.
- When `v.calculateFee(hours)` executes inside the `for-each` loop, the JVM inspects the actual runtime object on the heap (`TwoWheeler`, `Car`, or `ElectricCar`) and dynamically dispatches the appropriate overridden `calculateFee(int)` implementation.
- `vehicles[2] instanceof Chargeable` evaluates to `true` because `ElectricCar` implements `Chargeable`.

## 3. Mandatory `FeeDemo.java` Expected Output
```text
TwoWheeler TN01A1 -> Rs 30.0
Car TN02B2 -> Rs 90.0
ElectricCar TN03C3 -> Rs 210.0
true
```
