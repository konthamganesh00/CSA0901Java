package parking.model;

import java.time.LocalDate;

/**
 * Day-4 Challenge Addition: Visitor One-Day Pass.
 * Valid only for a single calendar day and applies the configured flat one-day pass fee.
 */
public class OneDayPass extends ParkingPass {

    public OneDayPass(String visitorId, String visitorName, String vehicleRegistrationNumber) {
        this(visitorId, visitorName, vehicleRegistrationNumber, LocalDate.now());
    }

    public OneDayPass(String visitorId, String visitorName, String vehicleRegistrationNumber,
                      LocalDate validDate) {
        super("ODP",
                visitorId,
                visitorName,
                vehicleRegistrationNumber,
                validDate == null ? LocalDate.now() : validDate,
                validDate == null ? LocalDate.now() : validDate,
                PricingConfig.getVisitorOneDayPassFee());
    }

    @Override
    public String getPassTypeName() {
        return "Visitor One-Day Pass";
    }

    @Override
    public double applyToParkingFee(double baseParkingFee) {
        // When valid, the visitor pays the configured One-Day Pass flat rate on issue
        // and owes Rs 0.0 extra standard parking fee at exit.
        if (isValid()) {
            return 0.0;
        }
        return baseParkingFee;
    }
}
