package Q3;

import java.util.HashSet;
import java.util.Set;

/**
 * Q3 - College Event Attendance De-duplication
 * Completed Attendance program preserving main() and input data.
 * Because Student implements both equals() and hashCode() using regNo,
 * duplicate check-ins with the same registration number are de-duplicated.
 */
public class Attendance {

    public static void main(String[] args) {
        Set<Student> attendees = new HashSet<>();

        attendees.add(new Student("23BCE1001", "Aarav"));
        attendees.add(new Student("23BCE1001", "Aarav"));
        attendees.add(new Student("23BCE1002", "Diya"));

        System.out.println("Unique students: " + attendees.size());
    }
}
