package Q2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Q2 - ArrayList, LinkedList, and ArrayDeque Benchmark
 * Problem: Music Playlist Editor
 *
 * Compares ArrayList, LinkedList, and ArrayDeque on:
 *   1. Adding at the end
 *   2. Inserting at the front
 *   3. Inserting in the middle
 *   4. Removing at the front
 *   5. Removing in the middle
 *   6. Accessing the kth element
 *   7. Iterating through all songs
 *
 * Tests sizes: 1,000, 10,000, and 50,000 songs.
 * Also demonstrates a plain String[] array with manual shifting.
 * Writes raw measurements to ExperimentalData/Q2_ListBenchmark.csv.
 */
public class PlaylistBenchmark {

    private static final int[] PLAYLIST_SIZES = {1_000, 10_000, 50_000};
    private static final int MIDDLE_AND_RANDOM_OPS = 1_000;
    private static final int WARMUP_RUNS = 2;
    private static final int MEASURED_RUNS = 5;

    private static volatile long blackhole = 0;

    record BenchmarkRow(
            int playlistSize,
            String operation,
            String structure,
            int opCount,
            int iteration,
            long elapsedNanos,
            double elapsedMillis,
            String notes
    ) {}

    @FunctionalInterface
    interface TimedTask {
        long execute();
    }

    private static String[] buildSongPool(int count) {
        String[] songs = new String[count];
        for (int i = 0; i < count; i++) {
            songs[i] = "Track-" + i;
        }
        return songs;
    }

    private static List<BenchmarkRow> measure(
            int size,
            String operation,
            String structure,
            int opCount,
            TimedTask task,
            String notes) {

        for (int w = 0; w < WARMUP_RUNS; w++) {
            blackhole += task.execute();
        }

        List<BenchmarkRow> rows = new ArrayList<>();
        for (int iter = 1; iter <= MEASURED_RUNS; iter++) {
            long start = System.nanoTime();
            long result = task.execute();
            long end = System.nanoTime();

            blackhole += result;
            long nanos = end - start;
            rows.add(new BenchmarkRow(
                    size,
                    operation,
                    structure,
                    opCount,
                    iter,
                    nanos,
                    nanos / 1_000_000.0,
                    notes
            ));
        }
        return rows;
    }

    private static void populateArrayList(ArrayList<String> list, String[] songs) {
        for (String s : songs) {
            list.add(s);
        }
    }

    private static void populateLinkedList(LinkedList<String> list, String[] songs) {
        for (String s : songs) {
            list.add(s);
        }
    }

    private static void populateArrayDeque(ArrayDeque<String> deque, String[] songs) {
        for (String s : songs) {
            deque.addLast(s);
        }
    }

    private static List<BenchmarkRow> runSizeSuite(int size) {
        List<BenchmarkRow> rows = new ArrayList<>();
        String[] songs = buildSongPool(size);

        // Precompute deterministic random indices for kth-element access
        Random rng = new Random(42 + size);
        int[] lookupIndices = new int[MIDDLE_AND_RANDOM_OPS];
        for (int i = 0; i < MIDDLE_AND_RANDOM_OPS; i++) {
            lookupIndices[i] = rng.nextInt(size);
        }

        // 1. Add at the end (N ops)
        rows.addAll(measure(size, "AddEnd", "ArrayList", size, () -> {
            ArrayList<String> list = new ArrayList<>();
            populateArrayList(list, songs);
            return list.size();
        }, "Amortized O(1)"));

        rows.addAll(measure(size, "AddEnd", "LinkedList", size, () -> {
            LinkedList<String> list = new LinkedList<>();
            populateLinkedList(list, songs);
            return list.size();
        }, "O(1) tail append"));

        rows.addAll(measure(size, "AddEnd", "ArrayDeque", size, () -> {
            ArrayDeque<String> deque = new ArrayDeque<>();
            populateArrayDeque(deque, songs);
            return deque.size();
        }, "Amortized O(1) circular buffer"));

        // 2. Insert at the front (N ops)
        rows.addAll(measure(size, "InsertFront", "ArrayList", size, () -> {
            ArrayList<String> list = new ArrayList<>();
            for (String s : songs) {
                list.add(0, s);
            }
            return list.size();
        }, "O(n) per insert due to shifting"));

        rows.addAll(measure(size, "InsertFront", "LinkedList", size, () -> {
            LinkedList<String> list = new LinkedList<>();
            for (String s : songs) {
                list.addFirst(s);
            }
            return list.size();
        }, "O(1) head link update"));

        rows.addAll(measure(size, "InsertFront", "ArrayDeque", size, () -> {
            ArrayDeque<String> deque = new ArrayDeque<>();
            for (String s : songs) {
                deque.addFirst(s);
            }
            return deque.size();
        }, "Amortized O(1) circular head wrap"));

        // 3. Insert in the middle (1,000 inserts into N-song playlist)
        rows.addAll(measure(size, "InsertMiddle", "ArrayList", MIDDLE_AND_RANDOM_OPS, () -> {
            ArrayList<String> list = new ArrayList<>(size + MIDDLE_AND_RANDOM_OPS);
            populateArrayList(list, songs);
            for (int i = 0; i < MIDDLE_AND_RANDOM_OPS; i++) {
                list.add(list.size() / 2, "NewSong-" + i);
            }
            return list.size();
        }, "O(n) shift right from middle"));

        rows.addAll(measure(size, "InsertMiddle", "LinkedList", MIDDLE_AND_RANDOM_OPS, () -> {
            LinkedList<String> list = new LinkedList<>();
            populateLinkedList(list, songs);
            for (int i = 0; i < MIDDLE_AND_RANDOM_OPS; i++) {
                list.add(list.size() / 2, "NewSong-" + i);
            }
            return list.size();
        }, "O(n) traversal to middle index"));

        rows.add(new BenchmarkRow(size, "InsertMiddle", "ArrayDeque", 0, 1, -1L, -1.0,
                "N/A - Deque does not support indexed middle insertion"));

        // 4. Remove at the front (N ops)
        rows.addAll(measure(size, "RemoveFront", "ArrayList", size, () -> {
            ArrayList<String> list = new ArrayList<>(size);
            populateArrayList(list, songs);
            long count = 0;
            while (!list.isEmpty()) {
                list.remove(0);
                count++;
            }
            return count;
        }, "O(n) left-shift on every removal"));

        rows.addAll(measure(size, "RemoveFront", "LinkedList", size, () -> {
            LinkedList<String> list = new LinkedList<>();
            populateLinkedList(list, songs);
            long count = 0;
            while (!list.isEmpty()) {
                list.removeFirst();
                count++;
            }
            return count;
        }, "O(1) head unlink"));

        rows.addAll(measure(size, "RemoveFront", "ArrayDeque", size, () -> {
            ArrayDeque<String> deque = new ArrayDeque<>(size);
            populateArrayDeque(deque, songs);
            long count = 0;
            while (!deque.isEmpty()) {
                deque.removeFirst();
                count++;
            }
            return count;
        }, "O(1) circular head advance"));

        // 5. Remove in the middle (1,000 removals from N-song playlist)
        rows.addAll(measure(size, "RemoveMiddle", "ArrayList", MIDDLE_AND_RANDOM_OPS, () -> {
            ArrayList<String> list = new ArrayList<>(size);
            populateArrayList(list, songs);
            long count = 0;
            for (int i = 0; i < MIDDLE_AND_RANDOM_OPS && !list.isEmpty(); i++) {
                list.remove(list.size() / 2);
                count++;
            }
            return count;
        }, "O(n) shift left from middle"));

        rows.addAll(measure(size, "RemoveMiddle", "LinkedList", MIDDLE_AND_RANDOM_OPS, () -> {
            LinkedList<String> list = new LinkedList<>();
            populateLinkedList(list, songs);
            long count = 0;
            for (int i = 0; i < MIDDLE_AND_RANDOM_OPS && !list.isEmpty(); i++) {
                list.remove(list.size() / 2);
                count++;
            }
            return count;
        }, "O(n) traversal to middle index"));

        rows.add(new BenchmarkRow(size, "RemoveMiddle", "ArrayDeque", 0, 1, -1L, -1.0,
                "N/A - Deque does not support indexed middle removal"));

        // 6. Access kth element (1,000 random lookups)
        ArrayList<String> prebuiltArrayList = new ArrayList<>(size);
        populateArrayList(prebuiltArrayList, songs);
        LinkedList<String> prebuiltLinkedList = new LinkedList<>();
        populateLinkedList(prebuiltLinkedList, songs);

        rows.addAll(measure(size, "GetKthElement", "ArrayList", MIDDLE_AND_RANDOM_OPS, () -> {
            long sum = 0;
            for (int idx : lookupIndices) {
                sum += prebuiltArrayList.get(idx).length();
            }
            return sum;
        }, "O(1) direct array indexing"));

        rows.addAll(measure(size, "GetKthElement", "LinkedList", MIDDLE_AND_RANDOM_OPS, () -> {
            long sum = 0;
            for (int idx : lookupIndices) {
                sum += prebuiltLinkedList.get(idx).length();
            }
            return sum;
        }, "O(n) node traversal"));

        rows.add(new BenchmarkRow(size, "GetKthElement", "ArrayDeque", 0, 1, -1L, -1.0,
                "N/A - Deque does not provide get(index)"));

        // 7. Iterate through all songs (N elements)
        ArrayDeque<String> prebuiltDeque = new ArrayDeque<>(size);
        populateArrayDeque(prebuiltDeque, songs);

        rows.addAll(measure(size, "IterateAll", "ArrayList", size, () -> {
            long sum = 0;
            for (String s : prebuiltArrayList) {
                sum += s.length();
            }
            return sum;
        }, "O(n) contiguous cache-friendly scan"));

        rows.addAll(measure(size, "IterateAll", "LinkedList", size, () -> {
            long sum = 0;
            for (String s : prebuiltLinkedList) {
                sum += s.length();
            }
            return sum;
        }, "O(n) pointer chasing"));

        rows.addAll(measure(size, "IterateAll", "ArrayDeque", size, () -> {
            long sum = 0;
            for (String s : prebuiltDeque) {
                sum += s.length();
            }
            return sum;
        }, "O(n) contiguous circular buffer scan"));

        return rows;
    }

    private static void printSummaryTable(List<BenchmarkRow> rows) {
        System.out.printf("%-8s | %-14s | %-11s | %-8s | %-12s | %s%n",
                "Size", "Operation", "Structure", "OpCount", "Avg Time(ms)", "Notes");
        System.out.println("-".repeat(95));

        List<String> keys = new ArrayList<>();
        for (BenchmarkRow r : rows) {
            String key = r.playlistSize() + "|" + r.operation() + "|" + r.structure();
            if (!keys.contains(key)) {
                keys.add(key);
            }
        }

        for (String key : keys) {
            List<BenchmarkRow> group = new ArrayList<>();
            for (BenchmarkRow r : rows) {
                String k = r.playlistSize() + "|" + r.operation() + "|" + r.structure();
                if (k.equals(key)) {
                    group.add(r);
                }
            }
            BenchmarkRow sample = group.get(0);
            if (sample.elapsedNanos() < 0) {
                System.out.printf("%-8d | %-14s | %-11s | %-8s | %-12s | %s%n",
                        sample.playlistSize(), sample.operation(), sample.structure(),
                        "N/A", "N/A", sample.notes());
            } else {
                double avgMs = group.stream().mapToDouble(BenchmarkRow::elapsedMillis).average().orElse(0.0);
                System.out.printf(Locale.US, "%-8d | %-14s | %-11s | %-8d | %12.4f | %s%n",
                        sample.playlistSize(), sample.operation(), sample.structure(),
                        sample.opCount(), avgMs, sample.notes());
            }
        }
    }

    /**
     * Demonstrates why ArrayList simplifies plain array management and how manual
     * shifting works on a raw String[] playlist.
     */
    private static void demonstratePlainArrayShifting() {
        System.out.println("\n--- Plain Array (String[]) Manual Shifting & Up Next Queue Demo ---");
        String[] playlist = new String[4];
        int size = 0;

        // Add at end
        playlist[size++] = "Song A";
        playlist[size++] = "Song B";
        playlist[size++] = "Song C";

        // Manual insert at front (index 0) requires shifting right
        int insertIndex = 0;
        for (int i = size; i > insertIndex; i--) {
            playlist[i] = playlist[i - 1];
        }
        playlist[insertIndex] = "Intro Track";
        size++;

        // Manual resize when full
        if (size == playlist.length) {
            String[] bigger = new String[playlist.length * 2];
            System.arraycopy(playlist, 0, bigger, 0, size);
            playlist = bigger;
        }

        // Manual remove at middle (index 2) requires shifting left
        int removeIndex = 2;
        for (int i = removeIndex; i < size - 1; i++) {
            playlist[i] = playlist[i + 1];
        }
        playlist[--size] = null;

        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < size; i++) {
            if (i > 0) sb.append(", ");
            sb.append(playlist[i]);
        }
        sb.append("]");
        System.out.println("Plain array after manual insert/remove: " + sb);

        // ArrayDeque as an "Up Next" music queue
        Deque<String> upNextQueue = new ArrayDeque<>();
        upNextQueue.addLast("Track 1");
        upNextQueue.addLast("Track 2");
        upNextQueue.addFirst("Play Next Priority Track");
        System.out.println("ArrayDeque Up Next Queue order: " + upNextQueue);
        System.out.println("Now playing (pollFirst): " + upNextQueue.pollFirst());
    }

    private static Path resolveCsvPath(String fileName) throws IOException {
        Path direct = Path.of("ExperimentalData");
        Path nested = Path.of("CSA09-Assignment2", "ExperimentalData");
        Path dir = Files.exists(direct) ? direct : (Files.exists(nested) ? nested : direct);
        Files.createDirectories(dir);
        return dir.resolve(fileName);
    }

    private static void writeCsv(List<BenchmarkRow> rows, Path csvPath) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(csvPath)) {
            writer.write("PlaylistSize,Operation,Structure,OperationCount,Iteration,ElapsedNanos,ElapsedMillis,Notes\n");
            for (BenchmarkRow r : rows) {
                writer.write(String.format(Locale.US,
                        "%d,%s,%s,%d,%d,%d,%.4f,\"%s\"%n",
                        r.playlistSize(),
                        r.operation(),
                        r.structure(),
                        r.opCount(),
                        r.iteration(),
                        r.elapsedNanos(),
                        r.elapsedMillis(),
                        r.notes()));
            }
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println("==========================================================================");
        System.out.println("Q2: Music Playlist Editor - ArrayList vs LinkedList vs ArrayDeque");
        System.out.println("==========================================================================");

        demonstratePlainArrayShifting();

        List<BenchmarkRow> allRows = new ArrayList<>();
        for (int size : PLAYLIST_SIZES) {
            System.out.println("\nRunning playlist benchmark for N = " + size + " songs...");
            List<BenchmarkRow> sizeRows = runSizeSuite(size);
            allRows.addAll(sizeRows);
            printSummaryTable(sizeRows);
        }

        Path csvPath = resolveCsvPath("Q2_ListBenchmark.csv");
        writeCsv(allRows, csvPath);
        System.out.println("\nSaved raw benchmark measurements to: " + csvPath.toAbsolutePath());
        System.out.println("Blackhole checksum: " + blackhole);
    }
}
