package parking.service;

import java.time.LocalDate;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import parking.model.ParkingSlot;
import parking.model.ParkingTicket;
import parking.model.VehicleType;

/**
 * Generates formatted Daily Parking Collection Reports, Occupancy Reports,
 * and Parked Vehicle Summaries.
 */
public class ReportService {

    /**
     * Immutable summary of daily financial collections.
     */
    public record DailyCollectionSummary(
            LocalDate reportDate,
            int totalExitTransactions,
            double totalParkingFees,
            double totalEvChargingFees,
            double totalOneDayPassRevenue,
            double totalMonthlyPassRevenue,
            double grandTotalCollection
    ) {
    }

    public DailyCollectionSummary computeDailyCollection(LocalDate date,
                                                         TicketService ticketService,
                                                         PassService passService) {
        LocalDate targetDate = (date == null) ? LocalDate.now() : date;
        int exits = 0;
        double parkingFees = 0.0;
        double chargingFees = 0.0;

        for (ParkingTicket ticket : ticketService.getSettledTickets()) {
            if (ticket.getExitTime() != null && ticket.getExitTime().toLocalDate().equals(targetDate)) {
                exits++;
                parkingFees += ticket.getBaseParkingFee();
                chargingFees += ticket.getChargingFee();
            }
        }

        double oneDayPassRevenue = passService.getTotalOneDayPassRevenueForDate(targetDate);
        double monthlyPassRevenue = passService.getTotalMonthlyPassRevenueForDate(targetDate);
        double grandTotal = parkingFees + chargingFees + oneDayPassRevenue + monthlyPassRevenue;

        return new DailyCollectionSummary(
                targetDate,
                exits,
                parkingFees,
                chargingFees,
                oneDayPassRevenue,
                monthlyPassRevenue,
                grandTotal
        );
    }

    public String buildDailyCollectionReport(LocalDate date, TicketService ticketService, PassService passService) {
        LocalDate targetDate = (date == null) ? LocalDate.now() : date;
        DailyCollectionSummary summary = computeDailyCollection(targetDate, ticketService, passService);

        Map<VehicleType, Integer> countByType = new EnumMap<>(VehicleType.class);
        Map<VehicleType, Double> revenueByType = new EnumMap<>(VehicleType.class);
        for (VehicleType vt : VehicleType.values()) {
            countByType.put(vt, 0);
            revenueByType.put(vt, 0.0);
        }

        for (ParkingTicket ticket : ticketService.getSettledTickets()) {
            if (ticket.getExitTime() != null && ticket.getExitTime().toLocalDate().equals(targetDate)) {
                VehicleType type = ticket.getVehicle().getVehicleType();
                countByType.put(type, countByType.get(type) + 1);
                revenueByType.put(type, revenueByType.get(type) + ticket.getTotalFee());
            }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("============================================================\n");
        sb.append("           DAILY PARKING COLLECTION REPORT (").append(targetDate).append(")\n");
        sb.append("============================================================\n");
        sb.append(String.format("Total Settled Exit Transactions : %d%n", summary.totalExitTransactions()));
        sb.append(String.format("Parking Fees Collected (Exits)  : Rs %.2f%n", summary.totalParkingFees()));
        sb.append(String.format("EV Charging Fees Collected      : Rs %.2f%n", summary.totalEvChargingFees()));
        sb.append(String.format("Visitor One-Day Pass Sales      : Rs %.2f%n", summary.totalOneDayPassRevenue()));
        sb.append(String.format("Monthly Pass Subscriptions      : Rs %.2f%n", summary.totalMonthlyPassRevenue()));
        sb.append("------------------------------------------------------------\n");
        sb.append(String.format("GRAND TOTAL COLLECTION          : Rs %.2f%n", summary.grandTotalCollection()));
        sb.append("------------------------------------------------------------\n");
        sb.append("Breakdown by Vehicle Category (Settled Exits):\n");
        for (VehicleType vt : VehicleType.values()) {
            sb.append(String.format("  %-15s : %2d exits | Rs %8.2f%n",
                    vt.getDisplayName(), countByType.get(vt), revenueByType.get(vt)));
        }
        sb.append("============================================================");
        return sb.toString();
    }

    public String buildOccupancyReport(ParkingFacility facility) {
        int totalCap = facility.getTotalCapacity();
        int occupied = facility.getCurrentOccupancy();
        int available = facility.getAvailableCount();
        double occupancyPct = totalCap == 0 ? 0.0 : (occupied * 100.0) / totalCap;

        StringBuilder sb = new StringBuilder();
        sb.append("============================================================\n");
        sb.append("               PARKING OCCUPANCY REPORT\n");
        sb.append("============================================================\n");
        for (int f = 0; f < facility.getFloorCount(); f++) {
            int cap = facility.getFloorCapacity(f);
            int occ = facility.getFloorOccupiedCount(f);
            int free = cap - occ;
            double floorPct = cap == 0 ? 0.0 : (occ * 100.0) / cap;
            sb.append(String.format("Floor %d : Capacity=%3d | Occupied=%3d | Free=%3d | Load=%5.1f%%%n",
                    f + 1, cap, occ, free, floorPct));
        }
        sb.append("------------------------------------------------------------\n");
        sb.append(String.format("TOTAL   : Capacity=%3d | Occupied=%3d | Free=%3d | Load=%5.1f%%%n",
                totalCap, occupied, available, occupancyPct));
        sb.append(String.format("Global Active Occupancy (Static Tracker): %d%n",
                ParkingFacility.getGlobalActiveOccupancy()));
        sb.append("============================================================");
        return sb.toString();
    }

    public String buildFloorVisualMap(ParkingFacility facility) {
        ParkingSlot[][] matrix = facility.getRawSlotMatrix();
        StringBuilder sb = new StringBuilder();
        sb.append("============================================================\n");
        sb.append("             ALL PARKING FLOORS (JAGGED LAYOUT)\n");
        sb.append("============================================================\n");
        for (int f = 0; f < matrix.length; f++) {
            sb.append(String.format("Floor %d (%d slots): ", f + 1, matrix[f].length));
            for (int s = 0; s < matrix[f].length; s++) {
                ParkingSlot slot = matrix[f][s];
                if (slot.isOccupied()) {
                    sb.append("[").append(slot.getSlotCode()).append(":")
                      .append(slot.getParkedVehicle().getRegistrationNumber()).append("] ");
                } else {
                    sb.append("[").append(slot.getSlotCode()).append(":FREE] ");
                }
            }
            sb.append("\n");
        }
        sb.append("============================================================");
        return sb.toString();
    }

    public String buildParkedVehiclesReport(List<ParkingTicket> activeTickets) {
        StringBuilder sb = new StringBuilder();
        sb.append("============================================================\n");
        sb.append("                 CURRENTLY PARKED VEHICLES\n");
        sb.append("============================================================\n");
        if (activeTickets.isEmpty()) {
            sb.append("No vehicles are currently parked in the facility.\n");
        } else {
            for (ParkingTicket ticket : activeTickets) {
                sb.append(ticket.toString()).append("\n");
            }
        }
        sb.append("============================================================");
        return sb.toString();
    }
}
