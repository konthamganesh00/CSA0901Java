
package task01;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.FileWriter;
import java.io.IOException;

public class EventRegistration extends JFrame {

    JTextField studentId = new JTextField(15);
    JTextField studentName = new JTextField(15);
    JTextField email = new JTextField(15);

    JComboBox<String> event = new JComboBox<>(
        new String[]{
            "Coding Competition",
            "Cultural Fest",
            "Sports Day",
            "Technical Symposium"
        }
    );

    JComboBox<String> filter = new JComboBox<>(
        new String[]{
            "All Events",
            "Coding Competition",
            "Cultural Fest",
            "Sports Day",
            "Technical Symposium"
        }
    );

    JButton register = new JButton("Register");
    JButton view = new JButton("View Registrations");
    JButton export = new JButton("Export CSV");

    DefaultTableModel model = new DefaultTableModel(
        new String[]{"ID", "Student ID", "Name", "Email", "Event"}, 0
    );

    JTable table = new JTable(model);

    String url = "jdbc:mysql://localhost:3306/campus_events";
    String user = "root";
    String password = "12345";

    public EventRegistration() {

        setTitle("Campus Event Registration");
        setLayout(new BorderLayout(10, 10));

        JPanel form = new JPanel(new GridLayout(5, 2, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Student Registration"));

        form.add(new JLabel("Student ID:"));
        form.add(studentId);

        form.add(new JLabel("Student Name:"));
        form.add(studentName);

        form.add(new JLabel("Email:"));
        form.add(email);

        form.add(new JLabel("Select Event:"));
        form.add(event);

        form.add(register);
        form.add(view);

        add(form, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout());
        bottom.add(new JLabel("Filter Event:"));
        bottom.add(filter);
        bottom.add(export);

        add(bottom, BorderLayout.SOUTH);

        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Options");

        JMenuItem refresh = new JMenuItem("Refresh");
        JMenuItem exit = new JMenuItem("Exit");

        menu.add(refresh);
        menu.add(exit);
        menuBar.add(menu);

        setJMenuBar(menuBar);

        register.addActionListener(e -> registerStudent());
        view.addActionListener(e -> loadRegistrations());
        filter.addActionListener(e -> loadRegistrations());
        export.addActionListener(e -> exportCSV());

        refresh.addActionListener(e -> loadRegistrations());
        exit.addActionListener(e -> dispose());

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setSize(850, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);

        loadRegistrations();
    }

    Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    void registerStudent() {

        String id = studentId.getText().trim();
        String name = studentName.getText().trim();
        String mail = email.getText().trim();
        String selectedEvent = (String) event.getSelectedItem();

        if (id.isEmpty() || name.isEmpty() || mail.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields");
            return;
        }

        if (!mail.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            JOptionPane.showMessageDialog(this, "Enter a valid email address");
            return;
        }

        register.setEnabled(false);

        SwingWorker<String, Void> worker = new SwingWorker<String, Void>() {

            protected String doInBackground() {

                String sql = "INSERT INTO registrations "
                    + "(student_id, student_name, email, event_name) "
                    + "VALUES (?, ?, ?, ?)";

                try (Connection con = getConnection();
                     PreparedStatement ps = con.prepareStatement(sql)) {

                    ps.setString(1, id);
                    ps.setString(2, name);
                    ps.setString(3, mail);
                    ps.setString(4, selectedEvent);

                    ps.executeUpdate();
                    return "Registration Successful";

                } catch (SQLIntegrityConstraintViolationException ex) {
                    return "Student already registered for this event";

                } catch (SQLException ex) {
                    return "Database Error: " + ex.getMessage();
                }
            }

            protected void done() {
                try {
                    JOptionPane.showMessageDialog(EventRegistration.this, get());

                    studentId.setText("");
                    studentName.setText("");
                    email.setText("");

                    loadRegistrations();

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(EventRegistration.this, ex.getMessage());
                }

                register.setEnabled(true);
            }
        };

        worker.execute();
    }

    void loadRegistrations() {

        model.setRowCount(0);

        String selected = (String) filter.getSelectedItem();

        SwingWorker<Void, Object[]> worker = new SwingWorker<Void, Object[]>() {

            protected Void doInBackground() {

                String sql = "SELECT id, student_id, student_name, email, event_name "
                           + "FROM registrations";

                if (selected != null && !selected.equals("All Events")) {
                    sql += " WHERE event_name = ?";
                }

                sql += " ORDER BY id DESC";

                try (Connection con = getConnection();
                     PreparedStatement ps = con.prepareStatement(sql)) {

                    if (selected != null && !selected.equals("All Events")) {
                        ps.setString(1, selected);
                    }

                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            publish(new Object[]{
                                rs.getInt("id"),
                                rs.getString("student_id"),
                                rs.getString("student_name"),
                                rs.getString("email"),
                                rs.getString("event_name")
                            });
                        }
                    }

                } catch (SQLException ex) {
                    SwingUtilities.invokeLater(() ->
                        JOptionPane.showMessageDialog(
                            EventRegistration.this,
                            "Database Error: " + ex.getMessage()
                        )
                    );
                }

                return null;
            }

            protected void process(java.util.List<Object[]> rows) {
                for (Object[] row : rows) {
                    model.addRow(row);
                }
            }
        };

        worker.execute();
    }

    void exportCSV() {

        try (FileWriter writer = new FileWriter("EventRegistrations.csv")) {

            for (int i = 0; i < model.getColumnCount(); i++) {
                writer.write(model.getColumnName(i) + ",");
            }

            writer.write("\n");

            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    String value = String.valueOf(model.getValueAt(i, j));
                    writer.write("\"" + value.replace("\"", "\"\"") + "\",");
                }
                writer.write("\n");
            }

            JOptionPane.showMessageDialog(this, "CSV Exported Successfully");

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Export Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EventRegistration());
    }
}
