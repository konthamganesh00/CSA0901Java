/**
 * Task 07 - Alternative Switch-Based Fee Calculation Comparison.
 * Shows why switch-based fee calculation violates the Open/Closed Principle compared to overriding.
 */
public class SwitchFeeAlternativeDemo {

    public static double calculateFeeWithSwitch(String vehicleType, int hours, boolean evCharging) {
        return switch (vehicleType.toUpperCase()) {
            case "TWOWHEELER" -> hours * 10.0;
            case "CAR" -> hours * 30.0;
            case "ELECTRICCAR" -> (hours * 40.0) + (evCharging ? 90.0 : 0.0);
            case "EBIKE" -> 15.0;
            default -> throw new IllegalArgumentException("Unknown vehicle type: " + vehicleType);
        };
    }

    public static void main(String[] args) {
        System.out.println("Switch TwoWheeler (3h) : Rs " + calculateFeeWithSwitch("TWOWHEELER", 3, false));
        System.out.println("Switch Car (3h)        : Rs " + calculateFeeWithSwitch("CAR", 3, false));
        System.out.println("Switch ElectricCar (3h): Rs " + calculateFeeWithSwitch("ELECTRICCAR", 3, true));
    }
}
