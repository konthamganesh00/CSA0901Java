package Q6;

import java.util.ArrayDeque;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 * Q6 - Hospital Emergency Triage using PriorityQueue + Comparator.
 * Completes TODO 1 while preserving main() and producing the exact expected output:
 *   Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)
 *
 * Also implements admitPatient, removeNextPatient, displayTreatmentOrder,
 * an 8-patient test scenario, and a priority-aging fairness demonstration.
 */
public class Triage {

    // Requirement 1 (Completed): Comparator ordering by severity ascending (1 highest -> 5 lowest),
    // breaking ties by arrival sequence ascending (FIFO within equal severity).
    public static final Comparator<Patient> TRIAGE_COMPARATOR = Comparator
            .comparingInt(Patient::getSeverity)
            .thenComparingLong(Patient::getArrivalSeq);

    private final PriorityQueue<Patient> queue = new PriorityQueue<>(TRIAGE_COMPARATOR);
    private long nextArrivalSeq = 1L;

    public Patient admitPatient(String name, int severity) {
        Patient patient = new Patient(name, severity, nextArrivalSeq++);
        queue.offer(patient);
        return patient;
    }

    public Patient removeNextPatient() {
        return queue.poll();
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }

    public int waitingCount() {
        return queue.size();
    }

    /**
     * Displays treatment order non-destructively using a copy of the PriorityQueue.
     * Note: Iterating a PriorityQueue directly does NOT guarantee sorted order;
     * polling repeatedly yields the true priority order.
     */
    public String formatTreatmentOrder() {
        PriorityQueue<Patient> copy = new PriorityQueue<>(queue);
        StringBuilder sb = new StringBuilder();
        while (!copy.isEmpty()) {
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(copy.poll());
        }
        return sb.toString();
    }

    public void displayTreatmentOrder() {
        System.out.println(formatTreatmentOrder());
    }

    public static void main(String[] args) {
        Triage triage = new Triage();

        // Mixed arrival order: Ravi(S3), Asha(S5), Meena(S1), Lata(S2), John(S3), Kumar(S1)
        triage.admitPatient("Ravi", 3);
        triage.admitPatient("Asha", 5);
        triage.admitPatient("Meena", 1);
        triage.admitPatient("Lata", 2);
        triage.admitPatient("John", 3);
        triage.admitPatient("Kumar", 1);

        // Exact expected output:
        // Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)
        StringBuilder out = new StringBuilder();
        while (!triage.isEmpty()) {
            if (out.length() > 0) {
                out.append(' ');
            }
            out.append(triage.removeNextPatient());
        }
        System.out.println(out);

        // Extended tests: 8-patient scenario, Normal Queue vs PriorityQueue, Priority Aging
        runEightPatientScenario();
        demonstrateNormalQueueVsPriorityQueue();
        demonstratePriorityAging();
    }

    private static void runEightPatientScenario() {
        System.out.println("\n--- Extended Test: 8-Patient Emergency Ward Scenario ---");
        Triage er = new Triage();
        er.admitPatient("Vikram", 4);
        er.admitPatient("Sita", 2);
        er.admitPatient("Arjun", 5);
        er.admitPatient("Neha", 1);
        er.admitPatient("Ramesh", 3);
        er.admitPatient("Pooja", 2);
        er.admitPatient("Kiran", 1);
        er.admitPatient("Divya", 4);

        System.out.println("Waiting count: " + er.waitingCount());
        System.out.print("Treatment order (non-destructive peek): ");
        er.displayTreatmentOrder();

        System.out.println("Treating first 3 patients:");
        for (int i = 1; i <= 3; i++) {
            System.out.println("  Treated #" + i + ": " + er.removeNextPatient());
        }
        System.out.print("Remaining treatment order: ");
        er.displayTreatmentOrder();
    }

    private static void demonstrateNormalQueueVsPriorityQueue() {
        System.out.println("\n--- Normal FIFO Queue vs PriorityQueue ---");
        Queue<Patient> fifoQueue = new ArrayDeque<>();
        fifoQueue.offer(new Patient("Ravi", 3, 1));
        fifoQueue.offer(new Patient("Asha", 5, 2));
        fifoQueue.offer(new Patient("Meena", 1, 3));

        System.out.print("Normal Queue (FIFO ignores severity): ");
        while (!fifoQueue.isEmpty()) {
            System.out.print(fifoQueue.poll() + " ");
        }
        System.out.println();
    }

    private static void demonstratePriorityAging() {
        System.out.println("\n--- Priority Aging Concept (Preventing Starvation) ---");
        // Suppose Asha(S5) has waited 60 minutes while threshold is 20 minutes per boost:
        // effectiveSeverity = max(1, baseSeverity - waitMinutes / 20)
        int baseSeverity = 5;
        int waitMinutes = 60;
        int agedSeverity = Math.max(1, baseSeverity - (waitMinutes / 20));
        System.out.println("Asha base severity: S" + baseSeverity
                + ", after waiting " + waitMinutes + " mins -> aged effective severity: S" + agedSeverity);
    }
}
