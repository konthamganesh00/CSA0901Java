import assert from 'node:assert/strict';
import {
  allocateSlotForVehicle,
  buildJaggedFacility,
  calculateFeeQuote,
  computeReportsSummary,
  createInitialParkingState,
  DEFAULT_RATES,
  findActiveSlotByRegOrTicket,
  loadPersistedState,
  PassRecord,
  registerVehicleInRegistry,
  savePersistedState,
  StorageLike,
  todayDateString,
  validatePassEligibility,
} from '../src/parkingLogic.ts';

function createMemoryStorage(): StorageLike {
  const map = new Map<string, string>();
  return {
    getItem: (k) => map.get(k) ?? null,
    setItem: (k, v) => {
      map.set(k, v);
    },
    removeItem: (k) => {
      map.delete(k);
    },
  };
}

function runTests() {
  const today = todayDateString();

  // 1. Vehicle Registration & Duplicate Prevention
  const reg1 = registerVehicleInRegistry([], 'TN01AA1111', 'Arjun', 'TwoWheeler', 'Student');
  assert.equal(reg1.ok, true);
  if (!reg1.ok) throw new Error('Expected reg1 ok');
  const dup = registerVehicleInRegistry(reg1.nextRegistry, 'tn01aa1111', 'Someone Else', 'Car', 'Visitor');
  assert.equal(dup.ok, false, 'Duplicate registration must be rejected');

  // 2. Full Parking Capacity & Invalid Slot Rejection
  let tinySlots = buildJaggedFacility([2]);
  const a1 = allocateSlotForVehicle(
    tinySlots,
    {
      regNo: 'TN01AA1111',
      ownerName: 'Arjun',
      category: 'TwoWheeler',
      userCategory: 'Student',
      entryTimeIso: new Date().toISOString(),
      passId: null,
      passType: 'None',
      chargingRequested: false,
      chargingKwh: 0,
    },
    1001
  );
  assert.equal(a1.ok, true);
  if (!a1.ok) throw new Error('a1 failed');
  assert.equal(a1.allocatedSlot.id, 'F1-S01');
  tinySlots = a1.nextSlots;

  // Reject occupied slot explicitly
  const occupiedReject = allocateSlotForVehicle(
    tinySlots,
    {
      regNo: 'TN01BB2222',
      ownerName: 'Bala',
      category: 'Car',
      userCategory: 'Visitor',
      entryTimeIso: new Date().toISOString(),
      passId: null,
      passType: 'None',
      chargingRequested: false,
      chargingKwh: 0,
    },
    a1.nextTicketSeq,
    'F1-S01'
  );
  assert.equal(occupiedReject.ok, false, 'Occupied slot must never be allocated');

  // Reject invalid slot coordinate
  const invalidSlotReject = allocateSlotForVehicle(
    tinySlots,
    {
      regNo: 'TN01BB2222',
      ownerName: 'Bala',
      category: 'Car',
      userCategory: 'Visitor',
      entryTimeIso: new Date().toISOString(),
      passId: null,
      passType: 'None',
      chargingRequested: false,
      chargingKwh: 0,
    },
    a1.nextTicketSeq,
    'F9-S99'
  );
  assert.equal(invalidSlotReject.ok, false, 'Invalid slot ID must be rejected');

  // Fill second slot -> facility full
  const a2 = allocateSlotForVehicle(
    tinySlots,
    {
      regNo: 'TN01BB2222',
      ownerName: 'Bala',
      category: 'Car',
      userCategory: 'Visitor',
      entryTimeIso: new Date().toISOString(),
      passId: null,
      passType: 'None',
      chargingRequested: false,
      chargingKwh: 0,
    },
    a1.nextTicketSeq
  );
  assert.equal(a2.ok, true);
  if (!a2.ok) throw new Error('a2 failed');
  tinySlots = a2.nextSlots;

  const fullReject = allocateSlotForVehicle(
    tinySlots,
    {
      regNo: 'TN01CC3333',
      ownerName: 'Charan',
      category: 'Car',
      userCategory: 'Visitor',
      entryTimeIso: new Date().toISOString(),
      passId: null,
      passType: 'None',
      chargingRequested: false,
      chargingKwh: 0,
    },
    a2.nextTicketSeq
  );
  assert.equal(fullReject.ok, false, 'Full capacity must reject 3rd vehicle');

  // Search by Reg No and Ticket ID
  assert.equal(findActiveSlotByRegOrTicket(tinySlots, 'TKT-1002')?.id, 'F1-S02');
  assert.equal(findActiveSlotByRegOrTicket(tinySlots, 'tn01aa1111')?.id, 'F1-S01');

  // 3. Pricing Rules for All 5 Vehicle Categories
  const entryMorningPeak = new Date(`${today}T10:00:00`);
  const exitPeak3h = new Date(`${today}T13:00:00`);

  const q2w = calculateFeeQuote(
    {
      ticketId: 'TKT-1',
      regNo: 'TN01A1',
      ownerName: 'A',
      category: 'TwoWheeler',
      userCategory: 'Visitor',
      entryTimeIso: entryMorningPeak.toISOString(),
      passId: null,
      passType: 'None',
      chargingRequested: false,
      chargingKwh: 0,
    },
    DEFAULT_RATES,
    { exitTimeIso: exitPeak3h.toISOString() }
  );
  assert.equal(q2w.ok && q2w.totalFee, 30);

  const qCar = calculateFeeQuote(
    {
      ticketId: 'TKT-2',
      regNo: 'TN02B2',
      ownerName: 'B',
      category: 'Car',
      userCategory: 'Visitor',
      entryTimeIso: entryMorningPeak.toISOString(),
      passId: null,
      passType: 'None',
      chargingRequested: false,
      chargingKwh: 0,
    },
    DEFAULT_RATES,
    { exitTimeIso: new Date(`${today}T11:01:00`).toISOString() } // 61 mins -> 2 hrs ceiling
  );
  assert.equal(qCar.ok && qCar.billedHours, 2);
  assert.equal(qCar.ok && qCar.totalFee, 60);

  // ElectricCar: 3 hrs * 40 + 10 kWh * Rs 12/kWh = 120 + 120 = Rs 240
  const qEv = calculateFeeQuote(
    {
      ticketId: 'TKT-3',
      regNo: 'TN03C3',
      ownerName: 'C',
      category: 'ElectricCar',
      userCategory: 'Visitor',
      entryTimeIso: entryMorningPeak.toISOString(),
      passId: null,
      passType: 'None',
      chargingRequested: true,
      chargingKwh: 10,
    },
    DEFAULT_RATES,
    { exitTimeIso: exitPeak3h.toISOString() }
  );
  assert.equal(qEv.ok && qEv.chargingFee, 120);
  assert.equal(qEv.ok && qEv.totalFee, 240);

  // EBike: Flat Rs 15 regardless of 5h stay
  const qEbike = calculateFeeQuote(
    {
      ticketId: 'TKT-4',
      regNo: 'TN04D4',
      ownerName: 'D',
      category: 'EBike',
      userCategory: 'Student',
      entryTimeIso: entryMorningPeak.toISOString(),
      passId: null,
      passType: 'None',
      chargingRequested: false,
      chargingKwh: 0,
    },
    DEFAULT_RATES,
    { exitTimeIso: new Date(`${today}T15:00:00`).toISOString() }
  );
  assert.equal(qEbike.ok && qEbike.totalFee, 15);

  // DeliveryVan: 10:00 - 12:00 (2 peak hrs @ Rs 60/hr = Rs 120), 18:00 - 20:00 (2 off-peak hrs @ Rs 30/hr = Rs 60)
  const qVanPeak = calculateFeeQuote(
    {
      ticketId: 'TKT-5',
      regNo: 'TN05E5',
      ownerName: 'E',
      category: 'DeliveryVan',
      userCategory: 'Visitor',
      entryTimeIso: new Date(`${today}T10:00:00`).toISOString(),
      passId: null,
      passType: 'None',
      chargingRequested: false,
      chargingKwh: 0,
    },
    DEFAULT_RATES,
    { exitTimeIso: new Date(`${today}T12:00:00`).toISOString() }
  );
  assert.equal(qVanPeak.ok && qVanPeak.totalFee, 120);

  const qVanOffPeak = calculateFeeQuote(
    {
      ticketId: 'TKT-6',
      regNo: 'TN05E5',
      ownerName: 'E',
      category: 'DeliveryVan',
      userCategory: 'Visitor',
      entryTimeIso: new Date(`${today}T18:00:00`).toISOString(),
      passId: null,
      passType: 'None',
      chargingRequested: false,
      chargingKwh: 0,
    },
    DEFAULT_RATES,
    { exitTimeIso: new Date(`${today}T20:00:00`).toISOString() }
  );
  assert.equal(qVanOffPeak.ok && qVanOffPeak.totalFee, 60);

  // Negative duration rejected
  const negDur = calculateFeeQuote(
    {
      ticketId: 'TKT-NEG',
      regNo: 'TN05E5',
      ownerName: 'E',
      category: 'Car',
      userCategory: 'Visitor',
      entryTimeIso: new Date(`${today}T14:00:00`).toISOString(),
      passId: null,
      passType: 'None',
      chargingRequested: false,
      chargingKwh: 0,
    },
    DEFAULT_RATES,
    { exitTimeIso: new Date(`${today}T12:00:00`).toISOString() }
  );
  assert.equal(negDur.ok, false, 'Negative duration must be rejected');

  // 4. Student Monthly, Staff Monthly, Visitor One-Day Pass & Invalid/Expired Pass Rejection
  const stuPass: PassRecord = {
    passId: 'MP-STU-900',
    category: 'StudentMonthly',
    holderName: 'Stu',
    holderId: 'S1',
    regNo: 'TN10S1',
    validUntil: '2026-12-31',
    active: true,
    purchasePrice: 200,
    issuedAtDate: today,
  };
  const staffPass: PassRecord = {
    passId: 'MP-STF-901',
    category: 'StaffMonthly',
    holderName: 'Prof',
    holderId: 'F1',
    regNo: 'TN10F1',
    validUntil: '2026-12-31',
    active: true,
    purchasePrice: 300,
    issuedAtDate: today,
  };
  const oneDayPass: PassRecord = {
    passId: 'ODP-902',
    category: 'VisitorOneDay',
    holderName: 'Vis',
    holderId: 'V1',
    regNo: 'TN10V1',
    validUntil: today,
    active: true,
    purchasePrice: 50,
    issuedAtDate: today,
  };
  const expiredPass: PassRecord = {
    ...stuPass,
    passId: 'MP-STU-OLD',
    validUntil: '2025-01-01',
  };

  assert.equal(validatePassEligibility(stuPass, 'TN10S1', 'Student', today).valid, true);
  assert.equal(validatePassEligibility(stuPass, 'TN10S1', 'Visitor', today).valid, false, 'Student pass rejected for Visitor');
  assert.equal(validatePassEligibility(staffPass, 'TN10F1', 'Staff', today).valid, true);
  assert.equal(validatePassEligibility(oneDayPass, 'TN10V1', 'Visitor', today).valid, true);
  assert.equal(validatePassEligibility(expiredPass, 'TN10S1', 'Student', today).valid, false, 'Expired pass must be rejected');

  const qStuFree = calculateFeeQuote(
    {
      ticketId: 'TKT-S',
      regNo: 'TN10S1',
      ownerName: 'Stu',
      category: 'Car',
      userCategory: 'Student',
      entryTimeIso: entryMorningPeak.toISOString(),
      passId: stuPass.passId,
      passType: 'StudentMonthly',
      chargingRequested: false,
      chargingKwh: 0,
    },
    DEFAULT_RATES,
    { exitTimeIso: exitPeak3h.toISOString(), resolvedPass: stuPass, checkDateStr: today }
  );
  assert.equal(qStuFree.ok && qStuFree.totalFee, 0);

  // 5. Persistence Save & Restart Reload
  const memStorage = createMemoryStorage();
  const initialState = createInitialParkingState();
  initialState.ticketSeq = 1099;
  savePersistedState(initialState, memStorage);
  const reloaded = loadPersistedState(memStorage);
  assert.equal(reloaded.ticketSeq, 1099);
  assert.equal(reloaded.slots.length, 100);
  const report = computeReportsSummary(reloaded);
  assert.equal(report.occupiedSlots, 6);
  assert.equal(report.availableSlots, 94);
  assert.equal(report.monthlyPassRevenue, 500);
  assert.equal(report.oneDayPassRevenue, 50);

  console.log('ALL 14 PARKING ENGINE & PERSISTENCE TESTS PASSED.');
}

runTests();
