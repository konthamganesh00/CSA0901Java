package Q3;

import java.util.Objects;

/**
 * Q3 - Student Model with proper equals(), hashCode(), and toString().
 * Two Student records represent the same attendee when their registration
 * number (regNo) matches.
 */
public class Student {

    private String regNo;
    private String name;

    public Student(String regNo, String name) {
        this.regNo = regNo;
        this.name = name;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Student other)) {
            return false;
        }
        return Objects.equals(this.regNo, other.regNo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(regNo);
    }

    /**
     * Validates non-blank registration number and student name for strict check-in.
     */
    public static Student validated(String regNo, String name) {
        if (regNo == null || regNo.isBlank()) {
            throw new IllegalArgumentException("Registration number cannot be null or blank.");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Student name cannot be null or blank.");
        }
        return new Student(regNo.trim(), name.trim());
    }

    @Override
    public String toString() {
        String r = (regNo != null) ? regNo : "UNKNOWN";
        String n = (name != null) ? name : "UNNAMED";
        return r + " - " + n;
    }
}
