package Q4;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import java.util.function.Supplier;

/**
 * Q4 - MapBenchmark
 * Benchmarks HashMap, TreeMap, LinkedHashMap, and SortedArray (Arrays.binarySearch)
 * across three inventory sizes: 1,000, 10,000, and 50,000 medicines.
 *
 * Metrics measured:
 *   1. Insertion time (N medicines)
 *   2. 100,000 lookup operations
 *   3. Iteration time (N entries)
 *   4. Report generation time (N formatted lines via StringBuilder)
 *
 * Writes raw per-iteration measurements to ExperimentalData/Q4_MapBenchmark.csv.
 */
public class MapBenchmark {

    private static final int[] INVENTORY_SIZES = {1_000, 10_000, 50_000};
    private static final int LOOKUP_OPS = 100_000;
    private static final int WARMUP_RUNS = 2;
    private static final int MEASURED_RUNS = 5;

    private static volatile long blackhole = 0;

    record BenchmarkRow(
            int inventorySize,
            String operation,
            String structure,
            int opCount,
            int iteration,
            long elapsedNanos,
            double elapsedMillis
    ) {}

    @FunctionalInterface
    interface TimedTask {
        long run();
    }

    private static List<BenchmarkRow> measure(
            int size,
            String operation,
            String structure,
            int opCount,
            TimedTask task) {

        for (int w = 0; w < WARMUP_RUNS; w++) {
            blackhole += task.run();
        }

        List<BenchmarkRow> rows = new ArrayList<>();
        for (int iter = 1; iter <= MEASURED_RUNS; iter++) {
            long start = System.nanoTime();
            long result = task.run();
            long end = System.nanoTime();
            blackhole += result;

            long nanos = end - start;
            rows.add(new BenchmarkRow(
                    size,
                    operation,
                    structure,
                    opCount,
                    iter,
                    nanos,
                    nanos / 1_000_000.0
            ));
        }
        return rows;
    }

    private static Medicine[] generateShuffledMedicines(int size) {
        Medicine[] meds = new Medicine[size];
        for (int i = 0; i < size; i++) {
            String code = String.format("MED%06d", i);
            meds[i] = new Medicine(code, "Medicine-" + i, 50 + (i % 200), 10.0 + (i % 500));
        }
        // Deterministic shuffle so TreeMap insertion exercises tree balancing
        Random rng = new Random(12345L + size);
        for (int i = meds.length - 1; i > 0; i--) {
            int j = rng.nextInt(i + 1);
            Medicine tmp = meds[i];
            meds[i] = meds[j];
            meds[j] = tmp;
        }
        return meds;
    }

    private static String[] generateLookupKeys(int size, int lookupCount) {
        String[] keys = new String[lookupCount];
        Random rng = new Random(999L + size);
        for (int i = 0; i < lookupCount; i++) {
            keys[i] = String.format("MED%06d", rng.nextInt(size));
        }
        return keys;
    }

    private static void benchmarkMapImplementation(
            int size,
            String name,
            Supplier<Map<String, Medicine>> mapFactory,
            Medicine[] shuffledMeds,
            String[] lookupKeys,
            List<BenchmarkRow> allRows) {

        // 1. Insertion
        allRows.addAll(measure(size, "Insertion", name, size, () -> {
            Map<String, Medicine> map = mapFactory.get();
            for (Medicine m : shuffledMeds) {
                map.put(m.getCode(), m);
            }
            return map.size();
        }));

        // Prepopulate map for Lookup, Iteration, and Report Generation
        Map<String, Medicine> populated = mapFactory.get();
        for (Medicine m : shuffledMeds) {
            populated.put(m.getCode(), m);
        }

        // 2. 100,000 Lookups
        allRows.addAll(measure(size, "Lookup_100k", name, LOOKUP_OPS, () -> {
            long qtySum = 0;
            for (String key : lookupKeys) {
                Medicine m = populated.get(key);
                if (m != null) {
                    qtySum += m.getQuantity();
                }
            }
            return qtySum;
        }));

        // 3. Iteration
        allRows.addAll(measure(size, "Iteration", name, size, () -> {
            long qtySum = 0;
            for (Map.Entry<String, Medicine> entry : populated.entrySet()) {
                qtySum += entry.getValue().getQuantity();
            }
            return qtySum;
        }));

        // 4. Report Generation
        allRows.addAll(measure(size, "ReportGeneration", name, size, () -> {
            StringBuilder report = new StringBuilder(size * 48);
            for (Map.Entry<String, Medicine> entry : populated.entrySet()) {
                Medicine m = entry.getValue();
                report.append(m.getCode())
                      .append(',')
                      .append(m.getName())
                      .append(',')
                      .append(m.getQuantity())
                      .append('\n');
            }
            return report.length();
        }));
    }

    private static void benchmarkSortedArray(
            int size,
            String[] lookupKeys,
            List<BenchmarkRow> allRows) {

        // Build already-sorted array for binarySearch comparison
        String[] sortedCodes = new String[size];
        Medicine[] sortedMeds = new Medicine[size];
        for (int i = 0; i < size; i++) {
            sortedCodes[i] = String.format("MED%06d", i);
            sortedMeds[i] = new Medicine(sortedCodes[i], "Medicine-" + i, 50 + (i % 200), 10.0 + (i % 500));
        }

        // 100,000 Binary Search Lookups
        allRows.addAll(measure(size, "Lookup_100k", "SortedArray", LOOKUP_OPS, () -> {
            long qtySum = 0;
            for (String key : lookupKeys) {
                int idx = Arrays.binarySearch(sortedCodes, key);
                if (idx >= 0) {
                    qtySum += sortedMeds[idx].getQuantity();
                }
            }
            return qtySum;
        }));

        // Iteration
        allRows.addAll(measure(size, "Iteration", "SortedArray", size, () -> {
            long qtySum = 0;
            for (Medicine m : sortedMeds) {
                qtySum += m.getQuantity();
            }
            return qtySum;
        }));

        // Report Generation
        allRows.addAll(measure(size, "ReportGeneration", "SortedArray", size, () -> {
            StringBuilder report = new StringBuilder(size * 48);
            for (Medicine m : sortedMeds) {
                report.append(m.getCode())
                      .append(',')
                      .append(m.getName())
                      .append(',')
                      .append(m.getQuantity())
                      .append('\n');
            }
            return report.length();
        }));
    }

    private static void printSummaryForSize(int size, List<BenchmarkRow> allRows) {
        System.out.println("\n--- Inventory Size N = " + size + " ---");
        System.out.printf("%-16s | %-14s | %-10s | %-12s%n",
                "Operation", "Structure", "OpCount", "Avg Time(ms)");
        System.out.println("-".repeat(62));

        List<String> keys = new ArrayList<>();
        for (BenchmarkRow r : allRows) {
            if (r.inventorySize() == size) {
                String k = r.operation() + "|" + r.structure();
                if (!keys.contains(k)) {
                    keys.add(k);
                }
            }
        }

        for (String key : keys) {
            List<BenchmarkRow> group = new ArrayList<>();
            for (BenchmarkRow r : allRows) {
                if (r.inventorySize() == size && (r.operation() + "|" + r.structure()).equals(key)) {
                    group.add(r);
                }
            }
            BenchmarkRow sample = group.get(0);
            double avgMs = group.stream().mapToDouble(BenchmarkRow::elapsedMillis).average().orElse(0.0);
            System.out.printf(Locale.US, "%-16s | %-14s | %-10d | %12.4f%n",
                    sample.operation(), sample.structure(), sample.opCount(), avgMs);
        }
    }

    private static Path resolveCsvPath(String fileName) throws IOException {
        Path direct = Path.of("ExperimentalData");
        Path nested = Path.of("CSA09-Assignment2", "ExperimentalData");
        Path dir = Files.exists(direct) ? direct : (Files.exists(nested) ? nested : direct);
        Files.createDirectories(dir);
        return dir.resolve(fileName);
    }

    private static void writeCsv(List<BenchmarkRow> rows, Path csvPath) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(csvPath)) {
            writer.write("InventorySize,Operation,Structure,OperationCount,Iteration,ElapsedNanos,ElapsedMillis\n");
            for (BenchmarkRow r : rows) {
                writer.write(String.format(Locale.US, "%d,%s,%s,%d,%d,%d,%.4f%n",
                        r.inventorySize(),
                        r.operation(),
                        r.structure(),
                        r.opCount(),
                        r.iteration(),
                        r.elapsedNanos(),
                        r.elapsedMillis()));
            }
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println("==========================================================================");
        System.out.println("Q4: Pharmacy Map Benchmark (HashMap vs TreeMap vs LinkedHashMap vs SortedArray)");
        System.out.println("==========================================================================");

        List<BenchmarkRow> allRows = new ArrayList<>();

        for (int size : INVENTORY_SIZES) {
            Medicine[] shuffledMeds = generateShuffledMedicines(size);
            String[] lookupKeys = generateLookupKeys(size, LOOKUP_OPS);

            benchmarkMapImplementation(size, "HashMap", HashMap::new, shuffledMeds, lookupKeys, allRows);
            benchmarkMapImplementation(size, "TreeMap", TreeMap::new, shuffledMeds, lookupKeys, allRows);
            benchmarkMapImplementation(size, "LinkedHashMap", LinkedHashMap::new, shuffledMeds, lookupKeys, allRows);
            benchmarkSortedArray(size, lookupKeys, allRows);

            printSummaryForSize(size, allRows);
        }

        Path csvPath = resolveCsvPath("Q4_MapBenchmark.csv");
        writeCsv(allRows, csvPath);
        System.out.println("\nSaved raw benchmark measurements to: " + csvPath.toAbsolutePath());
        System.out.println("Blackhole checksum: " + blackhole);
    }
}
