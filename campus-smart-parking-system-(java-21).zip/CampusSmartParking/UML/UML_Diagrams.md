# UML Diagrams – Campus Smart-Parking System

## 1. Core & Day-4 Extended Class Diagram (Mermaid)

```mermaid
classDiagram
    class Vehicle {
        <<abstract>>
        -int totalVehiclesCreated$
        -String registrationNumber
        -String ownerName
        -String contactNumber
        -VehicleType vehicleType
        +ratePerHour()* double
        +calculateFee(int hours) double
        +isValidRegistrationNumber(String)$ boolean
    }

    class TwoWheeler {
        -boolean hasHelmetStorage
        +ratePerHour() double
        +calculateFee(int hours) double
    }

    class EBike {
        -int batteryVoltage
        +ratePerHour() double
        +calculateFee(int hours) double
    }

    class Car {
        -int numberOfDoors
        +ratePerHour() double
        +calculateFee(int hours) double
    }

    class ElectricCar {
        -double batteryCapacityKwh
        -boolean chargingRequested
        +ratePerHour() double
        +chargingFee() double
        +calculateFee(int hours) double
    }

    class DeliveryVan {
        -double cargoCapacityKg
        +ratePerHour() double
        +ratePerHour(LocalTime) double
        +calculateFee(LocalDateTime, LocalDateTime) double
    }

    class Chargeable {
        <<interface>>
        +CHARGING_STANDARD$ String
        +chargingFee() double
        +isChargingRequested() boolean
        +setChargingRequested(boolean) void
        +supportsCharging(Vehicle)$ boolean
    }

    class ParkingPass {
        <<abstract>>
        -String passId
        -LocalDate issueDate
        -LocalDate expiryDate
        -boolean active
        +isValid() boolean
        +isValidOn(LocalDate) boolean
        +applyToParkingFee(double)* double
    }

    class MonthlyPass {
        -PassCategory category
        +renewForMonths(int) void
        +applyToParkingFee(double) double
    }

    class OneDayPass {
        +applyToParkingFee(double) double
    }

    class ParkingFacility {
        -int globalActiveOccupancy$
        -ParkingSlot[][] floorSlots
        +allocateFirstAvailableSlot(Vehicle, String) int[]
        +releaseSlot(int, int) Vehicle
    }

    class ParkingService {
        -ParkingFacility facility
        -TicketService ticketService
        -PassService passService
        -FeeCalculator feeCalculator
        -ReportService reportService
        +enterVehicle(Vehicle, LocalDateTime) ParkingTicket
        +exitVehicleByTicketId(String, LocalDateTime, String) ParkingTicket
    }

    Vehicle <|-- TwoWheeler
    TwoWheeler <|-- EBike
    Vehicle <|-- Car
    Car <|-- ElectricCar
    Car <|-- DeliveryVan
    Chargeable <|.. ElectricCar
    ParkingPass <|-- MonthlyPass
    ParkingPass <|-- OneDayPass
    ParkingService --> ParkingFacility
    ParkingService --> FeeCalculator
    ParkingService --> TicketService
    ParkingService --> PassService
```

## 2. Vehicle Entry & Exit Sequence Diagram

```mermaid
sequenceDiagram
    actor User
    participant Main
    participant ParkingService
    participant ParkingFacility
    participant TicketService
    participant FeeCalculator
    participant PassService

    User->>Main: Select 2 (Vehicle Entry)
    Main->>ParkingService: enterVehicle(vehicle, entryTime)
    ParkingService->>ParkingFacility: allocateFirstAvailableSlot(vehicle, "PENDING")
    ParkingFacility-->>ParkingService: [floorIdx, slotIdx]
    ParkingService->>TicketService: createTicket(vehicle, floorIdx, slotIdx, slotCode, entryTime)
    TicketService-->>ParkingService: ParkingTicket (TKT-1001)
    ParkingService-->>Main: ParkingTicket
    Main-->>User: Print Ticket Slip

    User->>Main: Select 9 (Vehicle Exit)
    Main->>ParkingService: exitVehicleByTicketId(ticketId, exitTime, passId)
    ParkingService->>PassService: validatePass(passId, regNo, exitDate)
    ParkingService->>FeeCalculator: calculateFeeBreakdown(vehicle, entry, exit, pass)
    FeeCalculator-->>ParkingService: FeeBreakdown
    ParkingService->>ParkingFacility: releaseSlot(floorIdx, slotIdx)
    ParkingService-->>Main: Settled Ticket
    Main-->>User: Print Exit & Fee Receipt
```

## 3. ASCII Overview Diagram (for Plain-Text / Console Reports)

```text
+-------------------------------------------------------------------------+
|                        parking.app.Main (Console)                       |
+-------------------------------------------------------------------------+
                                    |
                                    v
+-------------------------------------------------------------------------+
|                     parking.service.ParkingService                      |
+--------+------------------+-------------------+---------------+---------+
         |                  |                   |               |
         v                  v                   v               v
+----------------+  +---------------+  +---------------+  +---------------+
| ParkingFacility|  | TicketService |  |  PassService  |  | FeeCalculator |
| ParkingSlot[][]|  | HashMap/List  |  | Monthly/1-Day |  | PricingConfig |
+----------------+  +---------------+  +---------------+  +---------------+
         |                                      |
         v                                      v
+----------------+                      +---------------+
|    Vehicle     |                      |  ParkingPass  |
| - TwoWheeler   |                      | - MonthlyPass |
|   - EBike      |                      | - OneDayPass  |
| - Car          |                      +---------------+
|   - ElectricCar|..(implements Chargeable)
|   - DeliveryVan|
+----------------+
```
