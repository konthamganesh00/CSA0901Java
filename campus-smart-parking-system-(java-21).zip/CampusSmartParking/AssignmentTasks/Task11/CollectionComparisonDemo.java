import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Task 11 - Comparison of Fixed Array, ArrayList, and HashMap for Active Ticket Management.
 */
public class CollectionComparisonDemo {

    public static void main(String[] args) {
        // 1. Fixed Array (requires manual index tracking and linear search)
        String[] ticketArray = new String[5];
        ticketArray[0] = "TKT-1001:TN01A1";
        ticketArray[1] = "TKT-1002:TN02B2";

        // 2. ArrayList (dynamic sizing, preserves chronological order, O(n) search by ID)
        List<String> ticketList = new ArrayList<>();
        ticketList.add("TKT-1001:TN01A1");
        ticketList.add("TKT-1002:TN02B2");

        // 3. HashMap (O(1) average lookup and removal by Ticket ID or Registration Number)
        Map<String, String> activeTicketMap = new HashMap<>();
        activeTicketMap.put("TKT-1001", "TN01A1");
        activeTicketMap.put("TKT-1002", "TN02B2");

        System.out.println("Array[0]            : " + ticketArray[0]);
        System.out.println("ArrayList size      : " + ticketList.size());
        System.out.println("HashMap O(1) lookup : TKT-1002 -> " + activeTicketMap.get("TKT-1002"));
    }
}
