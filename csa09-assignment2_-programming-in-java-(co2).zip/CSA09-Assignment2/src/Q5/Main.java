package Q5;

import java.util.Comparator;
import java.util.List;

/**
 * Q5 - Main Demonstration Driver
 * Displays clear headings, inputs, executes LeaderboardDemo.main()
 * (expected primary output: [Eagles(9,6), Bisons(9,4), Panthers(9,4), Cobras(6,1)]),
 * and runs boundary and invalid-input tests.
 */
public class Main {

    private static void verify(boolean condition, String testName) {
        if (!condition) {
            throw new AssertionError("Test failed: " + testName);
        }
        System.out.println("[PASS] " + testName);
    }

    private static void runBoundaryAndErrorTests() {
        System.out.println("\n--- Q5 Normal, Boundary & Invalid Input Tests ---");

        Comparator<Team> cmp = Comparator
                .comparingInt(Team::getPoints)
                .thenComparingInt(Team::getGoalDifference)
                .reversed()
                .thenComparing(Team::getName);

        // 1. Boundary test: Empty leaderboard sort
        Leaderboard<Team> emptyBoard = new Leaderboard<>();
        emptyBoard.sortWith(cmp);
        verify(emptyBoard.getEntries().isEmpty(), "Empty leaderboard sorts safely without error");

        // 2. Boundary test: Negative goal difference and equal points
        Leaderboard<Team> negBoard = new Leaderboard<>();
        negBoard.addAll(List.of(
                new Team("Sharks", 3, -5),
                new Team("Alpha", 3, -2),
                new Team("Zebras", 3, -5)
        ));
        negBoard.sortWith(cmp);
        verify("[Alpha(3,-2), Sharks(3,-5), Zebras(3,-5)]".equals(negBoard.getEntries().toString()),
                "Negative goal difference and alphabetical tie-break verified");

        // 3. Invalid input tests: blank team name, null entry, null comparator
        try {
            new Team("  ", 5, 1);
            verify(false, "Blank team name should throw IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            System.out.println("[PASS] Blank team name caught cleanly: " + ex.getMessage());
        }

        try {
            emptyBoard.addEntry(null);
            verify(false, "Null entry should throw NullPointerException");
        } catch (NullPointerException ex) {
            System.out.println("[PASS] Null leaderboard entry caught cleanly: " + ex.getMessage());
        }

        try {
            emptyBoard.sortWith(null);
            verify(false, "Null comparator should throw NullPointerException");
        } catch (NullPointerException ex) {
            System.out.println("[PASS] Null comparator caught cleanly: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        System.out.println("==========================================================================");
        System.out.println("Q5 DEMONSTRATION: GENERICS, COMPARABLE AND COMPARATOR");
        System.out.println("Problem: Inter-College Sports Leaderboard");
        System.out.println("==========================================================================");

        System.out.println("Sample Inputs:");
        System.out.println("  [Cobras(6,1), Panthers(9,4), Eagles(9,6), Bisons(9,4)]");
        System.out.println("Expected Standings: [Eagles(9,6), Bisons(9,4), Panthers(9,4), Cobras(6,1)]");

        System.out.println("\n--- Executing LeaderboardDemo ---");
        LeaderboardDemo.main(args);

        runBoundaryAndErrorTests();
    }
}
