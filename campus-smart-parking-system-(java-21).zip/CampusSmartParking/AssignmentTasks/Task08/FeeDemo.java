/**
 * TASK 8 - Mandatory Polymorphism Program (FeeDemo).
 * Preserves main() method and demonstrates method overloading, method overriding,
 * upcasting, runtime dynamic method dispatch, Vehicle[] reference array, and Chargeable.
 *
 * Expected Exact Output:
 * TwoWheeler TN01A1 -> Rs 30.0
 * Car TN02B2 -> Rs 90.0
 * ElectricCar TN03C3 -> Rs 210.0
 * true
 */
public class FeeDemo {

    interface Chargeable {
        double chargingFee();
    }

    static abstract class Vehicle {
        private final String registrationNumber;

        protected Vehicle(String registrationNumber) {
            this.registrationNumber = registrationNumber;
        }

        public String getRegistrationNumber() {
            return registrationNumber;
        }

        public abstract double ratePerHour();

        // Method to be overridden (runtime polymorphism)
        public double calculateFee(int hours) {
            return hours * ratePerHour();
        }

        // Method overloading (compile-time polymorphism)
        public double calculateFee(int hours, double flatDiscount) {
            return Math.max(0.0, calculateFee(hours) - flatDiscount);
        }
    }

    static class TwoWheeler extends Vehicle {
        public TwoWheeler(String registrationNumber) {
            super(registrationNumber);
        }

        @Override
        public double ratePerHour() {
            return 10.0;
        }
    }

    static class Car extends Vehicle {
        public Car(String registrationNumber) {
            super(registrationNumber);
        }

        @Override
        public double ratePerHour() {
            return 30.0;
        }
    }

    static class ElectricCar extends Car implements Chargeable {
        public ElectricCar(String registrationNumber) {
            super(registrationNumber);
        }

        @Override
        public double ratePerHour() {
            return 40.0;
        }

        @Override
        public double chargingFee() {
            return 90.0;
        }

        @Override
        public double calculateFee(int hours) {
            return (hours * ratePerHour()) + chargingFee();
        }
    }

    public static void main(String[] args) {
        Vehicle[] vehicles = {
            new TwoWheeler("TN01A1"),
            new Car("TN02B2"),
            new ElectricCar("TN03C3")
        };

        int hours = 3;
        for (Vehicle v : vehicles) {
            System.out.println(v.getClass().getSimpleName() + " "
                    + v.getRegistrationNumber() + " -> Rs " + v.calculateFee(hours));
        }

        System.out.println(vehicles[2] instanceof Chargeable);
    }
}
