package parking.model;

/**
 * Represents one parking floor containing a configurable array of ParkingSlot objects.
 */
public class ParkingFloor {

    private final int floorNumber;
    private final ParkingSlot[] slots;

    public ParkingFloor(int floorNumber, int capacity) {
        if (floorNumber < 1) {
            throw new IllegalArgumentException("Floor number must be >= 1");
        }
        if (capacity < 1) {
            throw new IllegalArgumentException("Floor capacity must be >= 1");
        }
        this.floorNumber = floorNumber;
        this.slots = new ParkingSlot[capacity];
        for (int i = 0; i < capacity; i++) {
            this.slots[i] = new ParkingSlot(floorNumber, i + 1);
        }
    }

    public int getFloorNumber() {
        return floorNumber;
    }

    public int getCapacity() {
        return slots.length;
    }

    public ParkingSlot[] getSlots() {
        return slots;
    }

    public ParkingSlot getSlotByIndex(int index) {
        if (index < 0 || index >= slots.length) {
            return null;
        }
        return slots[index];
    }

    public int findFirstAvailableSlotIndex() {
        for (int i = 0; i < slots.length; i++) {
            if (!slots[i].isOccupied()) {
                return i;
            }
        }
        return -1;
    }

    public int getOccupiedCount() {
        int count = 0;
        for (ParkingSlot slot : slots) {
            if (slot.isOccupied()) {
                count++;
            }
        }
        return count;
    }

    public int getAvailableCount() {
        return slots.length - getOccupiedCount();
    }

    @Override
    public String toString() {
        return String.format("Floor %d [Capacity=%d, Occupied=%d, Available=%d]",
                floorNumber, slots.length, getOccupiedCount(), getAvailableCount());
    }
}
