# Q6 – `Queue` and `PriorityQueue` (Hospital Emergency Triage)

## Short Explanation
- **Normal `Queue` vs `PriorityQueue`:** A normal FIFO queue (`ArrayDeque` / `LinkedList`) serves patients strictly in arrival order, which would delay a critical `S1` patient behind an `S5` non-urgent patient. `PriorityQueue` uses a **binary min-heap** governed by a `Comparator` so the lowest severity number (`S1`) is always polled first.
- **Preserving Arrival Order on Ties:** A binary heap is *not* inherently stable across equal priorities. Adding a monotonically increasing `arrivalSeq` to each `Patient` and breaking ties with `.thenComparingLong(Patient::getArrivalSeq)` guarantees strict FIFO fairness within each severity level.
- **Starvation, Fairness & Priority Aging:** Under continuous high-priority (`S1`/`S2`) arrivals, low-priority (`S5`) patients can suffer **starvation**. **Priority aging** prevents indefinite waiting by promoting a patient's effective priority after a waiting threshold (e.g., reducing effective severity by 1 for every 20 minutes waited).
- **Suitability for 5,000 Patients/Day:** 5,000 patients/day averages ~3.5 arrivals per minute. Both `PriorityQueue` ($O(\log n)$) and 5 FIFO `ArrayDeque` buckets ($O(1)$) handle 50,000+ patients in milliseconds. For fixed discrete severities (`1..5`), **5 FIFO queues** offer $O(1)$ speed and zero heap reordering; for continuous urgency scores or **priority aging**, **`PriorityQueue`** is more flexible.

---

## Structure Comparison

| Implementation | Enqueue | Dequeue | Memory Overhead | Supports Arbitrary Priorities / Aging? |
|---|---|---|---|---|
| `PriorityQueue` (Binary Heap) | $O(\log n)$ | $O(\log n)$ | Low (backed by `Object[]`) | Yes |
| Sorted `LinkedList` | $O(n)$ (scan) | $O(1)$ | High (Node pointers) | Yes (but slow insert) |
| 5 FIFO Queues (`ArrayDeque[5]`) | $O(1)$ | $O(1)$ | Low (5 circular buffers) | Only fixed levels `1..5` |

---

## How to Run
- **Complete Demo + Tests + Benchmark:** Run `Q6.Main`
- **Triage Demo Only:** Run `Q6.Triage`
- **Triage Benchmark Only:** Run `Q6.TriageBenchmark`

---

## Sample Input & Expected Output

### Sample Input
- Arrival sequence: `Ravi(S3)`, `Asha(S5)`, `Meena(S1)`, `Lata(S2)`, `John(S3)`, `Kumar(S1)`

### Primary Expected Output (`Q6.Triage`)
```text
Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)
```

---

## Test Documentation
1. **Normal Tests:** Exact `Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)` output plus an 8-patient emergency ward scenario.
2. **Boundary Tests:** Empty queue (`removeNextPatient()` returns `null`) and all-equal priority (`S3`) FIFO preservation.
3. **Invalid Input Tests:** Severity `< 1` (`0`), severity `> 5` (`6`), and blank patient name rejected with `IllegalArgumentException`.
4. **Benchmark (`TriageBenchmark`):** Validates identical checksum across all 3 structures at `1,000`, `10,000`, and `50,000` patients and writes real results to `ExperimentalData/Q6_QueueBenchmark.csv`.
