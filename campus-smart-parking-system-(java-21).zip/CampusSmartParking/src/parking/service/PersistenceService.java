package parking.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import parking.exception.InvalidVehicleException;
import parking.model.Car;
import parking.model.DeliveryVan;
import parking.model.EBike;
import parking.model.ElectricCar;
import parking.model.ParkingUser;
import parking.model.TwoWheeler;
import parking.model.Vehicle;

/**
 * Pure Java 21 file-based persistence helper for saving and restoring registered vehicles
 * across console application restarts without requiring an external database.
 */
public class PersistenceService {

    private final Path storagePath;

    public PersistenceService(Path storagePath) {
        this.storagePath = storagePath;
    }

    public void saveRegisteredVehicles(ParkingService parkingService) throws IOException {
        List<String> lines = new ArrayList<>();
        for (Vehicle v : parkingService.getAllRegisteredVehicles()) {
            lines.add(String.join("|",
                    v.getRegistrationNumber(),
                    v.getVehicleType().name(),
                    v.getOwnerName().replace("|", " "),
                    v.getContactNumber().replace("|", " "),
                    v.getUserCategory().name()));
        }
        if (storagePath.getParent() != null) {
            Files.createDirectories(storagePath.getParent());
        }
        Files.write(storagePath, lines, StandardCharsets.UTF_8);
    }

    public int loadRegisteredVehicles(ParkingService parkingService) throws IOException {
        if (!Files.exists(storagePath)) {
            return 0;
        }
        List<String> lines = Files.readAllLines(storagePath, StandardCharsets.UTF_8);
        int loaded = 0;
        for (String line : lines) {
            if (line.isBlank()) {
                continue;
            }
            String[] parts = line.split("\\|", -1);
            if (parts.length < 5) {
                continue;
            }
            String regNo = parts[0];
            String typeName = parts[1];
            String owner = parts[2];
            String contact = parts[3];
            ParkingUser.UserRole role = ParkingUser.UserRole.valueOf(parts[4]);

            Vehicle vehicle = switch (typeName) {
                case "TWO_WHEELER" -> new TwoWheeler(regNo, owner, contact, false);
                case "ELECTRIC_CAR" -> new ElectricCar(regNo, owner, contact, 50.0, true);
                case "E_BIKE" -> new EBike(regNo, owner, contact, 48);
                case "DELIVERY_VAN" -> new DeliveryVan(regNo, owner, contact, 1200.0);
                default -> new Car(regNo, owner, contact, 4);
            };
            vehicle.setUserCategory(role);
            try {
                if (!parkingService.isVehicleRegistered(regNo)) {
                    parkingService.registerVehicle(vehicle);
                    loaded++;
                }
            } catch (InvalidVehicleException ignored) {
                // Skip malformed legacy rows
            }
        }
        return loaded;
    }
}
