
package task01;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Converter3 extends JFrame {

    JTextField amount = new JTextField(10);
    JComboBox<String> target =
        new JComboBox<>(new String[]{"USD", "EUR"});
    JButton convert = new JButton("Convert");
    JLabel result = new JLabel("Result: ");

    public Converter3() {
        setTitle("Currency Converter - Anonymous Class");
        setLayout(new FlowLayout());

        add(new JLabel("INR"));
        add(amount);
        add(target);
        add(convert);
        add(result);

        ActionListener handler = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calculate();
            }
        };

        convert.addActionListener(handler);
        amount.addActionListener(handler);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setSize(350, 180);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    void calculate() {
        try {
            double value = Double.parseDouble(amount.getText());
            double rate = target.getSelectedItem().equals("USD")
                    ? 0.012 : 0.011;

            double answer = value * rate;

            result.setText(String.format("Result: %.2f", answer));
            JOptionPane.showMessageDialog(this,
                    String.format("Converted Amount: %.2f", answer));

        } catch (NumberFormatException e) {
            result.setText("Invalid amount");
            JOptionPane.showMessageDialog(this, "Invalid amount");
        }
    }

    public static void main(String[] args) {
        new Converter3();
    }
}
