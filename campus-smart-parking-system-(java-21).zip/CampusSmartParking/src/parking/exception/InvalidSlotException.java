package parking.exception;

/**
 * Thrown when floor or slot coordinates are out of range or invalid for an operation.
 */
public class InvalidSlotException extends ParkingException {

    private static final long serialVersionUID = 1L;

    public InvalidSlotException(String message) {
        super(message);
    }
}
