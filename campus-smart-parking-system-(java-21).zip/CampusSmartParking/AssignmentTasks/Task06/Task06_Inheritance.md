# TASK 6 – Inheritance

## 1. Vehicle Inheritance Hierarchy
```text
               Vehicle (abstract)
              /                  \
        TwoWheeler               Car
            |                 /       \
          EBike       ElectricCar    DeliveryVan
```

- **Hierarchical Inheritance**: `TwoWheeler` and `Car` both extend `Vehicle`; `ElectricCar` and `DeliveryVan` both extend `Car`.
- **Multilevel Inheritance**: `Vehicle -> Car -> ElectricCar`, `Vehicle -> Car -> DeliveryVan`, and `Vehicle -> TwoWheeler -> EBike`.

## 2. UML Class Diagram (Textual)
```text
+-----------------------------------+
|      <<abstract>> Vehicle         |
+-----------------------------------+
| - registrationNumber : String     |
| - ownerName : String              |
| - contactNumber : String          |
| - vehicleType : VehicleType       |
+-----------------------------------+
| + ratePerHour()* : double         |
| + calculateFee(hours:int): double |
+-----------------------------------+
         ^                 ^
         |                 |
+-----------------+  +--------------------+
|   TwoWheeler    |  |        Car         |
+-----------------+  +--------------------+
| - helmetStorage |  | - numberOfDoors    |
+-----------------+  +--------------------+
         ^                 ^            ^
         |                 |            |
+-----------------+  +-------------+  +---------------+
|      EBike      |  | ElectricCar |  |  DeliveryVan  |
+-----------------+  +-------------+  +---------------+
| - batteryVolt   |  | - batteryKwh|  | - cargoKg     |
+-----------------+  +-------------+  +---------------+
```

## 3. `super` Keyword and Constructor Execution Trace
When `new ElectricCar("TN03C3", "Meera")` is instantiated:
1. `ElectricCar(...)` invokes `super(..., VehicleType.ELECTRIC_CAR)` on `Car`.
2. `Car(...)` invokes `super(..., VehicleType.ELECTRIC_CAR)` on `Vehicle`.
3. `Vehicle` initializes `registrationNumber`, `ownerName`, `contactNumber`, `vehicleType`, increments `totalVehiclesCreated`, and returns to `Car`.
4. `Car` initializes `numberOfDoors` and returns to `ElectricCar`.
5. `ElectricCar` initializes `batteryCapacityKwh` and `chargingRequested`.

`super` is also used in `DeliveryVan.ratePerHour(LocalTime)` (`super.ratePerHour()`) to reuse `Car`'s hourly rate before applying the 2x peak multiplier, and in `toString()` overrides (`super.toString()`).

## 4. Alternative Design: Composition (Strategy Pattern)
In `CompositionParkingDemo.java`, `ComposedVehicle` holds a `RateStrategy` field (**HAS-A** relationship) instead of subclassing (**IS-A**).

| Aspect | Inheritance (`Vehicle` hierarchy) | Composition (`RateStrategy`) |
|---|---|---|
| Extensibility | Clean class-per-vehicle model | Allows changing pricing behaviour dynamically at runtime |
| Object Count | 1 object per vehicle | 2 objects per vehicle (`ComposedVehicle` + `RateStrategy`) |
| Time Complexity | `O(1)` vtable virtual method dispatch | `O(1)` interface delegation |
| Space Complexity | `O(1)` per vehicle instance | Slightly higher (`+1` strategy reference per vehicle) |
| Choice for Assignment | Ideal for domain modeling (`TwoWheeler`, `Car`, `ElectricCar`, `EBike`, `DeliveryVan`) | Ideal when rate plans must switch dynamically mid-stay |
