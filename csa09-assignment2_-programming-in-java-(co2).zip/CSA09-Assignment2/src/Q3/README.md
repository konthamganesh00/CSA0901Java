# Q3 – `hashCode()` and `equals()` (College Event Attendance De-duplication)

## Short Explanation
`HashSet` uses a `HashMap` internally. When adding an element, Java first computes `hashCode()` to locate the bucket, and then calls `equals()` against elements in that bucket.

### The `equals()` and `hashCode()` Contract
1. **Reflexive:** `x.equals(x)` must be `true`.
2. **Symmetric:** `x.equals(y) == y.equals(x)`.
3. **Transitive:** If `x.equals(y)` and `y.equals(z)`, then `x.equals(z)`.
4. **Consistent:** Multiple calls return the same result unless fields used in `equals` change.
5. **Non-null:** `x.equals(null)` must return `false`.
6. **HashCode Consistency:** Whenever `a.equals(b)` is `true`, **`a.hashCode() == b.hashCode()` MUST also be `true`**. (Unequal objects *may* share a hash code due to collisions, though distinct hash codes improve bucket distribution.)

If `equals()` is overridden without `hashCode()`, `Object.hashCode()` uses distinct identity/memory hashes, placing logically equal `Student` objects into different buckets—breaking `HashSet` de-duplication.

### Mutable Field Warning
If a field used in `hashCode()` (such as `regNo`) is mutated *after* inserting the object into a `HashSet`, the object remains in its original bucket while future lookups compute the new hash bucket. Always keep identity keys immutable while stored in hash-based collections.

---

## Comparison: `HashSet` vs `TreeSet` vs `HashMap`

| Criterion | `HashSet<Student>` | `TreeSet<Student>` | `HashMap<String, Student>` |
|---|---|---|---|
| Average Lookup/Insert | $O(1)$ | $O(\log n)$ | $O(1)$ |
| De-duplication Mechanism | `hashCode()` + `equals()` | `Comparator` / `Comparable` (`== 0`) | Key's `hashCode()` + `equals()` |
| Output Order | Unordered | Sorted by `regNo` | Unordered |
| Extra Benefit | Simplest set semantics | Ready for sorted attendance roll | Stores check-in metadata (timestamp, hall, etc.) |

---

## How to Run
- **Complete Demo + Tests + Experiments:** Run `Q3.Main`
- **Supplied Program Only:** Run `Q3.Attendance`
- **HashSet Experiments Only:** Run `Q3.HashSetExperiment`

---

## Sample Input & Expected Output

### Sample Input
- `new Student("23BCE1001", "Aarav")`
- `new Student("23BCE1001", "Aarav")`
- `new Student("23BCE1002", "Diya")`

### Expected Output (`Q3.Attendance`)
```text
Unique students: 2
```

### Expected Highlights (`Q3.HashSetExperiment` & `Q3.Main`)
- Without `hashCode()`: `Broken HashSet size (expected 2, actual): 3`
- With `hashCode()`: `Unique students: 2`
- Mutable field test: `contains(mutableStudent)` returns `false` after `setRegNo("23BCE9999")`
- `TreeSet`: `TreeSet (sorted by regNo) unique count: 2`

---

## Test Documentation
1. **Normal Test:** `Attendance.main()` validates exact output `Unique students: 2`.
2. **Boundary Tests:** Empty `HashSet`, reflexivity, `equals(null) == false`, and null `regNo` safety.
3. **Invalid Input Tests:** `TreeSet.add(null)` throws `NullPointerException`; `Student.validated("   ", "Aarav")` throws `IllegalArgumentException`.
