package parking.app;

import java.io.IOException;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;
import parking.exception.InvalidPassException;
import parking.exception.InvalidSlotException;
import parking.exception.InvalidVehicleException;
import parking.exception.ParkingException;
import parking.model.Car;
import parking.model.Chargeable;
import parking.model.DeliveryVan;
import parking.model.EBike;
import parking.model.ElectricCar;
import parking.model.MonthlyPass;
import parking.model.OneDayPass;
import parking.model.ParkingPass;
import parking.model.ParkingSlot;
import parking.model.ParkingTicket;
import parking.model.PricingConfig;
import parking.model.TwoWheeler;
import parking.model.Vehicle;
import parking.service.FeeCalculator;
import parking.service.ParkingFacility;
import parking.service.ParkingService;
import parking.service.PersistenceService;

/**
 * Console-based entry point for the Campus Smart-Parking Management System (Java 21).
 */
public class Main {

    private static final DateTimeFormatter TIME_ONLY_FORMAT = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter DATE_ONLY_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter FULL_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private final Scanner scanner;
    private final ParkingService parkingService;
    private final PersistenceService persistenceService;

    public Main() {
        this.scanner = new Scanner(System.in);
        this.parkingService = new ParkingService();
        this.persistenceService = new PersistenceService(Paths.get("data", "registered_vehicles.txt"));
    }

    public static void main(String[] args) {
        Main app = new Main();
        app.run();
    }

    public void run() {
        System.out.println("Initialised Campus Smart-Parking Facility: 5 Floors (Capacities: 10, 15, 20, 25, 30 = 100 Slots)");
        try {
            int restored = persistenceService.loadRegisteredVehicles(parkingService);
            if (restored > 0) {
                System.out.println("Restored " + restored + " registered vehicle(s) from previous session.");
            }
        } catch (IOException ignored) {
            // Start cleanly if no saved vehicle file is present yet
        }
        boolean running = true;

        while (running) {
            printMainMenu();
            int choice = readInt("Enter your choice: ", 1, 17);
            System.out.println();

            switch (choice) {
                case 1 -> handleRegisterVehicle();
                case 2 -> handleVehicleEntry();
                case 3 -> handleAllocateSpecificSlot();
                case 4 -> handleGenerateOrPrintTicket();
                case 5 -> handleViewAvailableSlots();
                case 6 -> handleViewOccupiedSlots();
                case 7 -> handleViewParkedVehicles();
                case 8 -> handleSearchParkingTicket();
                case 9 -> handleVehicleExit();
                case 10 -> handleCalculateParkingFee();
                case 11 -> handleManageMonthlyPass();
                case 12 -> handleManageOneDayPass();
                case 13 -> handleElectricVehicleCharging();
                case 14 -> handleDailyCollectionReport();
                case 15 -> handleOccupancyReport();
                case 16 -> handleDisplayAndConfigureFloors();
                case 17 -> {
                    try {
                        persistenceService.saveRegisteredVehicles(parkingService);
                    } catch (IOException ignored) {
                        // Ignore non-fatal file save error on exit
                    }
                    System.out.println("Thank you for using Campus Smart-Parking System. Goodbye!");
                    running = false;
                }
                default -> System.out.println("Invalid choice. Please select 1 to 17.");
            }
            System.out.println();
        }
        scanner.close();
    }

    private void printMainMenu() {
        System.out.println("=============================================");
        System.out.println("       CAMPUS SMART-PARKING MANAGEMENT       ");
        System.out.println("=============================================");
        System.out.println("1.  Register Vehicle");
        System.out.println("2.  Vehicle Entry");
        System.out.println("3.  Allocate Parking Slot");
        System.out.println("4.  Generate Parking Ticket");
        System.out.println("5.  View Available Parking Slots");
        System.out.println("6.  View Occupied Parking Slots");
        System.out.println("7.  View Parked Vehicles");
        System.out.println("8.  Search Parking Ticket");
        System.out.println("9.  Vehicle Exit");
        System.out.println("10. Calculate Parking Fee");
        System.out.println("11. Manage Monthly Pass");
        System.out.println("12. Manage Visitor One-Day Pass");
        System.out.println("13. Electric Vehicle Charging");
        System.out.println("14. Daily Collection Report");
        System.out.println("15. Parking Occupancy Report");
        System.out.println("16. Display All Parking Floors");
        System.out.println("17. Exit");
        System.out.println("=============================================");
    }

    // 1. Register Vehicle
    private void handleRegisterVehicle() {
        System.out.println("--- Register Vehicle ---");
        try {
            Vehicle vehicle = promptNewVehicleDetails(null);
            parkingService.registerVehicle(vehicle);
            System.out.println("Vehicle registered successfully:");
            System.out.println("  " + vehicle);
        } catch (ParkingException e) {
            System.out.println("Registration failed: " + e.getMessage());
        }
    }

    // 2. Vehicle Entry (Auto Slot Allocation + Ticket Generation)
    private void handleVehicleEntry() {
        System.out.println("--- Vehicle Entry ---");
        try {
            String regNo = readNonEmptyString("Enter Vehicle Registration Number (e.g., TN01AB1234): ");
            if (!Vehicle.isValidRegistrationNumber(regNo)) {
                System.out.println("Error: Invalid registration number format. Use 4-15 alphanumeric characters.");
                return;
            }
            String normalizedReg = regNo.trim().toUpperCase().replaceAll("\\s+", "");
            Vehicle vehicle;
            if (parkingService.isVehicleRegistered(normalizedReg)) {
                vehicle = parkingService.getRegisteredVehicle(normalizedReg);
                System.out.println("Found registered vehicle: " + vehicle);
            } else {
                System.out.println("Vehicle not yet registered. Enter vehicle details:");
                vehicle = promptNewVehicleDetails(normalizedReg);
                parkingService.registerVehicle(vehicle);
            }

            LocalDateTime entryTime = promptEntryTimestamp();
            ParkingTicket ticket = parkingService.enterVehicle(vehicle, entryTime);
            System.out.println("\nVehicle entry successful! Slot automatically allocated.");
            printTicketSlip(ticket);
        } catch (ParkingException e) {
            System.out.println("Entry failed: " + e.getMessage());
        }
    }

    // 3. Allocate Parking Slot (Manual/Specific Slot Selection)
    private void handleAllocateSpecificSlot() {
        System.out.println("--- Allocate Specific Parking Slot ---");
        try {
            String regNo = readNonEmptyString("Enter Vehicle Registration Number: ");
            String normalizedReg = regNo.trim().toUpperCase().replaceAll("\\s+", "");
            Vehicle vehicle;
            if (parkingService.isVehicleRegistered(normalizedReg)) {
                vehicle = parkingService.getRegisteredVehicle(normalizedReg);
            } else {
                System.out.println("Vehicle not registered yet. Let's register it first:");
                vehicle = promptNewVehicleDetails(normalizedReg);
                parkingService.registerVehicle(vehicle);
            }

            ParkingFacility facility = parkingService.getFacility();
            int floorCount = facility.getFloorCount();
            int floorChoice = readInt("Enter Floor Number (1 to " + floorCount + "): ", 1, floorCount);
            int floorCapacity = facility.getFloorCapacity(floorChoice - 1);
            int slotChoice = readInt("Enter Slot Number on Floor " + floorChoice + " (1 to " + floorCapacity + "): ",
                    1, floorCapacity);

            LocalDateTime entryTime = promptEntryTimestamp();
            ParkingTicket ticket = parkingService.enterVehicleInSpecificSlot(
                    vehicle, floorChoice - 1, slotChoice - 1, entryTime);
            System.out.println("\nSlot F" + floorChoice + "-S" + String.format("%02d", slotChoice) + " allocated!");
            printTicketSlip(ticket);
        } catch (ParkingException e) {
            System.out.println("Allocation failed: " + e.getMessage());
        }
    }

    // 4. Generate Parking Ticket (Print/Reprint Ticket Slip or Issue Ticket)
    private void handleGenerateOrPrintTicket() {
        System.out.println("--- Generate / Print Parking Ticket ---");
        System.out.println("1. Generate/Reprint Ticket for Parked Vehicle (by Reg No or Ticket ID)");
        System.out.println("2. Park Registered Vehicle & Generate New Ticket");
        int option = readInt("Select option (1-2): ", 1, 2);

        try {
            if (option == 1) {
                String key = readNonEmptyString("Enter Ticket ID (e.g., TKT-1001) or Vehicle Reg No: ");
                ParkingTicket ticket;
                if (key.toUpperCase().startsWith("TKT-")) {
                    ticket = parkingService.getTicketService().findTicketById(key);
                } else {
                    ticket = parkingService.getTicketService().findActiveTicketByRegNo(key);
                }
                printTicketSlip(ticket);
            } else {
                handleVehicleEntry();
            }
        } catch (ParkingException e) {
            System.out.println("Ticket error: " + e.getMessage());
        }
    }

    // 5. View Available Parking Slots
    private void handleViewAvailableSlots() {
        List<ParkingSlot> available = parkingService.getAvailableSlots();
        ParkingFacility facility = parkingService.getFacility();
        System.out.println("--- Available Parking Slots (" + available.size() + " / "
                + facility.getTotalCapacity() + ") ---");
        if (available.isEmpty()) {
            System.out.println("No slots available. Facility is FULL.");
            return;
        }
        int col = 0;
        for (ParkingSlot slot : available) {
            System.out.printf("%-10s", slot.getSlotCode());
            col++;
            if (col % 8 == 0) {
                System.out.println();
            }
        }
        if (col % 8 != 0) {
            System.out.println();
        }
    }

    // 6. View Occupied Parking Slots
    private void handleViewOccupiedSlots() {
        List<ParkingSlot> occupied = parkingService.getOccupiedSlots();
        System.out.println("--- Occupied Parking Slots (" + occupied.size() + ") ---");
        if (occupied.isEmpty()) {
            System.out.println("All parking slots are currently empty.");
            return;
        }
        for (ParkingSlot slot : occupied) {
            System.out.println("  " + slot);
        }
    }

    // 7. View Parked Vehicles
    private void handleViewParkedVehicles() {
        List<ParkingTicket> activeTickets = parkingService.getParkedVehicleTickets();
        System.out.println(parkingService.getReportService().buildParkedVehiclesReport(activeTickets));
    }

    // 8. Search Parking Ticket
    private void handleSearchParkingTicket() {
        System.out.println("--- Search Parking Ticket ---");
        System.out.println("1. Search by Ticket ID");
        System.out.println("2. Search Active Ticket by Vehicle Registration Number");
        int option = readInt("Select option (1-2): ", 1, 2);

        try {
            ParkingTicket ticket;
            if (option == 1) {
                String ticketId = readNonEmptyString("Enter Ticket ID (e.g., TKT-1001): ");
                ticket = parkingService.getTicketService().findTicketById(ticketId);
            } else {
                String regNo = readNonEmptyString("Enter Vehicle Registration Number: ");
                ticket = parkingService.getTicketService().findActiveTicketByRegNo(regNo);
            }
            printTicketSlip(ticket);
        } catch (ParkingException e) {
            System.out.println("Search result: " + e.getMessage());
        }
    }

    // 9. Vehicle Exit
    private void handleVehicleExit() {
        System.out.println("--- Vehicle Exit ---");
        System.out.println("1. Exit by Ticket ID");
        System.out.println("2. Exit by Vehicle Registration Number");
        int mode = readInt("Select lookup mode (1-2): ", 1, 2);

        try {
            String key = readNonEmptyString(mode == 1 ? "Enter Ticket ID: " : "Enter Vehicle Registration Number: ");
            ParkingTicket activeTicket = (mode == 1)
                    ? parkingService.getTicketService().findTicketById(key)
                    : parkingService.getTicketService().findActiveTicketByRegNo(key);

            if (activeTicket.isSettled()) {
                System.out.println("Ticket " + activeTicket.getTicketId() + " has already been settled.");
                return;
            }

            LocalDateTime exitTime = promptExitTimestamp(activeTicket.getEntryTime());

            System.out.print("Enter Parking Pass ID if applicable (or press Enter to auto-check/skip): ");
            String passId = scanner.nextLine().trim();

            ParkingTicket settled = (mode == 1)
                    ? parkingService.exitVehicleByTicketId(key, exitTime, passId)
                    : parkingService.exitVehicleByRegNo(key, exitTime, passId);

            System.out.println("\nExit processed successfully! Slot " + settled.getSlotCode() + " released.");
            printExitReceipt(settled);
        } catch (ParkingException | IllegalArgumentException e) {
            System.out.println("Exit failed: " + e.getMessage());
        }
    }

    // 10. Calculate Parking Fee (Estimator Tool)
    private void handleCalculateParkingFee() {
        System.out.println("--- Parking Fee Calculator ---");
        Vehicle sampleVehicle = selectVehicleTypeForQuote();
        if (sampleVehicle == null) {
            return;
        }

        System.out.println("Duration Mode:");
        System.out.println("1. Enter Duration in Minutes");
        System.out.println("2. Enter Entry & Exit Clock Times (HH:mm)");
        int durMode = readInt("Select mode (1-2): ", 1, 2);

        LocalDateTime entryTime;
        LocalDateTime exitTime;
        if (durMode == 1) {
            int mins = readInt("Enter parking duration in minutes (1 to 1440): ", 1, 1440);
            entryTime = LocalDateTime.now().minusMinutes(mins);
            exitTime = LocalDateTime.now();
        } else {
            LocalTime start = readTime("Enter Entry Time (HH:mm, e.g., 09:30): ");
            LocalTime end = readTime("Enter Exit Time (HH:mm, e.g., 12:15): ");
            entryTime = LocalDateTime.of(LocalDate.now(), start);
            exitTime = LocalDateTime.of(LocalDate.now(), end);
            if (exitTime.isBefore(entryTime)) {
                exitTime = exitTime.plusDays(1);
            }
        }

        System.out.println("Pass Simulation:");
        System.out.println("1. None (Visitor Standard Rate)");
        System.out.println("2. Valid Student Monthly Pass");
        System.out.println("3. Valid Staff Monthly Pass");
        System.out.println("4. Valid Visitor One-Day Pass");
        int passChoice = readInt("Select pass option (1-4): ", 1, 4);

        ParkingPass simulatedPass = switch (passChoice) {
            case 2 -> new MonthlyPass(MonthlyPass.PassCategory.STUDENT, "STU-SIM", "Student",
                    sampleVehicle.getRegistrationNumber(), entryTime.toLocalDate(), entryTime.toLocalDate().plusMonths(1));
            case 3 -> new MonthlyPass(MonthlyPass.PassCategory.STAFF, "STF-SIM", "Staff",
                    sampleVehicle.getRegistrationNumber(), entryTime.toLocalDate(), entryTime.toLocalDate().plusMonths(1));
            case 4 -> new OneDayPass("VIS-SIM", "Visitor",
                    sampleVehicle.getRegistrationNumber(), entryTime.toLocalDate());
            default -> null;
        };

        FeeCalculator.FeeBreakdown breakdown = parkingService.getFeeCalculator()
                .calculateFeeBreakdown(sampleVehicle, entryTime, exitTime, simulatedPass);

        System.out.println("\n--- Estimated Fee Breakdown ---");
        System.out.println("Vehicle Type        : " + sampleVehicle.getVehicleType().getDisplayName());
        System.out.println("Billed Hours (ceil) : " + breakdown.billedHours() + " hr(s)");
        System.out.printf("Raw Parking Fee     : Rs %.2f%n", breakdown.rawParkingFee());
        System.out.printf("Adjusted Parking Fee: Rs %.2f%n", breakdown.adjustedParkingFee());
        System.out.printf("EV Charging Fee     : Rs %.2f%n", breakdown.chargingFee());
        System.out.println("Pass Rule Applied   : " + breakdown.passNote());
        System.out.printf("TOTAL PAYABLE       : Rs %.2f%n", breakdown.finalTotalFee());
    }

    // 11. Manage Monthly Pass
    private void handleManageMonthlyPass() {
        System.out.println("--- Manage Monthly Pass ---");
        System.out.println("1. Issue Student Monthly Pass (Rs " + PricingConfig.getStudentMonthlyPassPrice() + ")");
        System.out.println("2. Issue Staff Monthly Pass (Rs " + PricingConfig.getStaffMonthlyPassPrice() + ")");
        System.out.println("3. Validate Monthly Pass");
        System.out.println("4. Renew Monthly Pass");
        System.out.println("5. Revoke Monthly Pass");
        System.out.println("6. View All Monthly Passes");
        int choice = readInt("Select option (1-6): ", 1, 6);

        try {
            switch (choice) {
                case 1, 2 -> {
                    MonthlyPass.PassCategory cat = (choice == 1)
                            ? MonthlyPass.PassCategory.STUDENT
                            : MonthlyPass.PassCategory.STAFF;
                    String holderId = readNonEmptyString("Enter " + cat.name() + " ID: ");
                    String holderName = readNonEmptyString("Enter Holder Full Name: ");
                    String regNo = readNonEmptyString("Enter Vehicle Registration Number: ");
                    int months = readInt("Enter Validity Duration in Months (1-12): ", 1, 12);
                    MonthlyPass pass = parkingService.getPassService()
                            .issueMonthlyPass(cat, holderId, holderName, regNo, months);
                    System.out.println("Monthly pass issued: " + pass);
                }
                case 3 -> {
                    String passId = readNonEmptyString("Enter Pass ID: ");
                    String regNo = readNonEmptyString("Enter Vehicle Registration Number: ");
                    ParkingPass pass = parkingService.getPassService().validatePass(passId, regNo, LocalDate.now());
                    System.out.println("PASS VALID: " + pass);
                }
                case 4 -> {
                    String passId = readNonEmptyString("Enter Monthly Pass ID: ");
                    ParkingPass pass = parkingService.getPassService().getPassById(passId);
                    if (pass instanceof MonthlyPass mp) {
                        int extraMonths = readInt("Enter additional months (1-12): ", 1, 12);
                        mp.renewForMonths(extraMonths);
                        System.out.println("Renewed pass: " + mp);
                    } else {
                        System.out.println("Specified pass is not a Monthly Pass.");
                    }
                }
                case 5 -> {
                    String passId = readNonEmptyString("Enter Pass ID to revoke: ");
                    parkingService.getPassService().revokePass(passId);
                    System.out.println("Pass " + passId + " has been revoked.");
                }
                case 6 -> {
                    List<MonthlyPass> passes = parkingService.getPassService().getMonthlyPasses();
                    if (passes.isEmpty()) {
                        System.out.println("No monthly passes issued yet.");
                    } else {
                        passes.forEach(p -> System.out.println("  " + p));
                    }
                }
            }
        } catch (InvalidPassException e) {
            System.out.println("Pass error: " + e.getMessage());
        }
    }

    // 12. Manage Visitor One-Day Pass
    private void handleManageOneDayPass() {
        System.out.println("--- Manage Visitor One-Day Pass ---");
        System.out.printf("Configured One-Day Pass Fee: Rs %.2f%n", PricingConfig.getVisitorOneDayPassFee());
        System.out.println("1. Issue Visitor One-Day Pass (Valid Today)");
        System.out.println("2. Validate Visitor One-Day Pass");
        System.out.println("3. View All Visitor One-Day Passes");
        int choice = readInt("Select option (1-3): ", 1, 3);

        try {
            switch (choice) {
                case 1 -> {
                    String visitorId = readNonEmptyString("Enter Visitor ID / Govt ID Ref: ");
                    String visitorName = readNonEmptyString("Enter Visitor Name: ");
                    String regNo = readNonEmptyString("Enter Vehicle Registration Number: ");
                    OneDayPass pass = parkingService.getPassService()
                            .issueOneDayPass(visitorId, visitorName, regNo, LocalDate.now());
                    System.out.println("Visitor One-Day Pass issued: " + pass);
                }
                case 2 -> {
                    String passId = readNonEmptyString("Enter One-Day Pass ID: ");
                    String regNo = readNonEmptyString("Enter Vehicle Registration Number: ");
                    ParkingPass pass = parkingService.getPassService().validatePass(passId, regNo, LocalDate.now());
                    System.out.println("ONE-DAY PASS VALID: " + pass);
                }
                case 3 -> {
                    List<OneDayPass> passes = parkingService.getPassService().getOneDayPasses();
                    if (passes.isEmpty()) {
                        System.out.println("No visitor one-day passes issued yet.");
                    } else {
                        passes.forEach(p -> System.out.println("  " + p));
                    }
                }
            }
        } catch (InvalidPassException e) {
            System.out.println("One-Day Pass error: " + e.getMessage());
        }
    }

    // 13. Electric Vehicle Charging
    private void handleElectricVehicleCharging() {
        System.out.println("--- Electric Vehicle Charging Management ---");
        System.out.println("Charging Standard: " + Chargeable.CHARGING_STANDARD);
        System.out.printf("EV Charging Rate: Rs %.2f / kWh (Default %.1f kWh = Rs %.2f)%n",
                PricingConfig.getEvChargingRatePerKwh(),
                PricingConfig.getDefaultEvChargingKwh(),
                PricingConfig.getEvChargingSessionFee());
        System.out.println("1. Enable/Disable & Set kWh for a Parked Electric Car");
        System.out.println("2. View All Registered Electric Cars");
        int choice = readInt("Select option (1-2): ", 1, 2);

        if (choice == 1) {
            String regNo = readNonEmptyString("Enter Parked Electric Car Registration Number: ");
            System.out.println("1. Enable EV Charging");
            System.out.println("2. Disable EV Charging");
            int action = readInt("Select action (1-2): ", 1, 2);
            double kwh = (action == 1)
                    ? readDouble("Enter energy consumed in kWh (e.g., 7.5): ", 0.5, 200.0)
                    : 0.0;
            try {
                parkingService.updateEvChargingForParkedVehicle(regNo, action == 1, kwh);
                System.out.println("EV charging status updated to: "
                        + (action == 1 ? String.format("ENABLED (%.1f kWh @ Rs %.2f/kWh)",
                        kwh, PricingConfig.getEvChargingRatePerKwh()) : "DISABLED"));
            } catch (ParkingException e) {
                System.out.println("EV charging update failed: " + e.getMessage());
            }
        } else {
            boolean found = false;
            for (Vehicle v : parkingService.getAllRegisteredVehicles()) {
                if (Chargeable.supportsCharging(v)) {
                    System.out.println("  " + v);
                    found = true;
                }
            }
            if (!found) {
                System.out.println("No electric cars registered yet.");
            }
        }
    }

    // 14. Daily Collection Report
    private void handleDailyCollectionReport() {
        System.out.print("Enter date (yyyy-MM-dd) or press Enter for today (" + LocalDate.now() + "): ");
        String input = scanner.nextLine().trim();
        LocalDate date = LocalDate.now();
        if (!input.isEmpty()) {
            try {
                date = LocalDate.parse(input, DATE_ONLY_FORMAT);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Using today's date.");
            }
        }
        System.out.println(parkingService.getDailyCollectionReport(date));
    }

    // 15. Parking Occupancy Report
    private void handleOccupancyReport() {
        System.out.println(parkingService.getOccupancyReport());
    }

    // 16. Display All Parking Floors (+ Switch Preset Configuration if Lot is Empty)
    private void handleDisplayAndConfigureFloors() {
        System.out.println(parkingService.getAllFloorsDisplay());
        System.out.print("\nWould you like to change floor configuration? (y/n): ");
        String ans = scanner.nextLine().trim();
        if (!ans.equalsIgnoreCase("y")) {
            return;
        }
        System.out.println("Select Facility Configuration:");
        System.out.println("1. 1 Floor  x 20 Slots (20 total)");
        System.out.println("2. 3 Floors x 50 Slots (150 total)");
        System.out.println("3. 5 Floors x 100 Slots (500 total)");
        System.out.println("4. 5 Floors Jagged Default (10, 15, 20, 25, 30 = 100 total)");
        System.out.println("5. Custom Jagged Floor Capacities");
        int preset = readInt("Select preset (1-5): ", 1, 5);

        int[] newCaps = switch (preset) {
            case 1 -> new int[]{20};
            case 2 -> new int[]{50, 50, 50};
            case 3 -> new int[]{100, 100, 100, 100, 100};
            case 4 -> new int[]{10, 15, 20, 25, 30};
            default -> {
                int floors = readInt("Enter number of floors (1-10): ", 1, 10);
                int[] custom = new int[floors];
                for (int i = 0; i < floors; i++) {
                    custom[i] = readInt("Enter capacity for Floor " + (i + 1) + " (1-200): ", 1, 200);
                }
                yield custom;
            }
        };

        try {
            parkingService.reconfigureFacility(newCaps);
            System.out.println("Parking facility reconfigured successfully!");
            System.out.println(parkingService.getOccupancyReport());
        } catch (InvalidSlotException e) {
            System.out.println("Reconfiguration rejected: " + e.getMessage());
        }
    }

    // --- Helper Input & Display Methods ---

    private Vehicle promptNewVehicleDetails(String prefilledRegNo) throws InvalidVehicleException {
        String regNo = prefilledRegNo;
        if (regNo == null) {
            regNo = readNonEmptyString("Enter Registration Number (e.g., TN01AB1234): ");
        }
        if (!Vehicle.isValidRegistrationNumber(regNo)) {
            throw new InvalidVehicleException("Invalid registration number. Must be 4-15 alphanumeric characters.");
        }
        String ownerName = readNonEmptyString("Enter Owner Name: ");
        String contact = readNonEmptyString("Enter Contact Number: ");

        System.out.println("Select User Category:");
        System.out.println("1. Student");
        System.out.println("2. Staff");
        System.out.println("3. Visitor");
        int userChoice = readInt("Enter user category (1-3): ", 1, 3);
        parking.model.ParkingUser.UserRole role = switch (userChoice) {
            case 1 -> parking.model.ParkingUser.UserRole.STUDENT;
            case 2 -> parking.model.ParkingUser.UserRole.STAFF;
            default -> parking.model.ParkingUser.UserRole.VISITOR;
        };

        System.out.println("Select Vehicle Category:");
        System.out.println("1. Two-Wheeler (Rs " + PricingConfig.getTwoWheelerRatePerHour() + "/hr)");
        System.out.println("2. Car (Rs " + PricingConfig.getCarRatePerHour() + "/hr)");
        System.out.println("3. Electric Car (Rs " + PricingConfig.getElectricCarRatePerHour()
                + "/hr + Rs " + PricingConfig.getEvChargingRatePerKwh() + "/kWh charging)");
        System.out.println("4. E-Bike (Flat Rs " + PricingConfig.getEbikeFlatFee() + ")");
        System.out.println("5. Delivery Van (2x Car rate between 9 AM - 5 PM)");
        int type = readInt("Enter category (1-5): ", 1, 5);

        Vehicle created = switch (type) {
            case 1 -> {
                System.out.print("Has helmet storage? (y/n): ");
                boolean helmet = scanner.nextLine().trim().equalsIgnoreCase("y");
                yield new TwoWheeler(regNo, ownerName, contact, helmet);
            }
            case 2 -> {
                int doors = readInt("Enter number of doors (2-6): ", 2, 6);
                yield new Car(regNo, ownerName, contact, doors);
            }
            case 3 -> {
                double battery = readDouble("Enter battery capacity in kWh (e.g., 50): ", 10.0, 200.0);
                System.out.print("Enable EV charging during stay? (y/n): ");
                boolean charging = scanner.nextLine().trim().equalsIgnoreCase("y");
                double kwh = charging
                        ? readDouble("Enter estimated charging units in kWh (default 7.5): ", 0.5, 200.0)
                        : 0.0;
                yield new ElectricCar(regNo, ownerName, contact, battery, charging, kwh);
            }
            case 4 -> {
                int voltage = readInt("Enter E-Bike battery voltage (24/36/48/60): ", 12, 96);
                yield new EBike(regNo, ownerName, contact, voltage);
            }
            case 5 -> {
                double cargo = readDouble("Enter cargo capacity in kg (e.g., 1200): ", 100.0, 10000.0);
                yield new DeliveryVan(regNo, ownerName, contact, cargo);
            }
            default -> throw new InvalidVehicleException("Unsupported vehicle category.");
        };
        created.setUserCategory(role);
        return created;
    }

    private Vehicle selectVehicleTypeForQuote() {
        System.out.println("Select Vehicle Type:");
        System.out.println("1. Two-Wheeler");
        System.out.println("2. Car");
        System.out.println("3. Electric Car");
        System.out.println("4. E-Bike");
        System.out.println("5. Delivery Van");
        int choice = readInt("Enter choice (1-5): ", 1, 5);
        return switch (choice) {
            case 1 -> new TwoWheeler("QUOTE-2W", "Quote User");
            case 2 -> new Car("QUOTE-CAR", "Quote User");
            case 3 -> {
                System.out.print("Include EV Charging? (y/n): ");
                boolean charge = scanner.nextLine().trim().equalsIgnoreCase("y");
                yield new ElectricCar("QUOTE-EV", "Quote User", "N/A", 50.0, charge);
            }
            case 4 -> new EBike("QUOTE-EB", "Quote User");
            case 5 -> new DeliveryVan("QUOTE-DV", "Quote User");
            default -> null;
        };
    }

    private LocalDateTime promptEntryTimestamp() {
        System.out.print("Use current system time for entry? (y/n): ");
        String ans = scanner.nextLine().trim();
        if (ans.isEmpty() || ans.equalsIgnoreCase("y")) {
            return LocalDateTime.now();
        }
        LocalTime time = readTime("Enter custom Entry Time today (HH:mm, e.g., 09:30): ");
        return LocalDateTime.of(LocalDate.now(), time);
    }

    private LocalDateTime promptExitTimestamp(LocalDateTime entryTime) {
        System.out.println("Exit Timestamp Option:");
        System.out.println("1. Use Current System Time");
        System.out.println("2. Enter Parking Duration in Minutes (for testing/simulation)");
        System.out.println("3. Enter Custom Exit Clock Time (HH:mm)");
        int mode = readInt("Select option (1-3): ", 1, 3);

        if (mode == 1) {
            LocalDateTime now = LocalDateTime.now();
            return now.isBefore(entryTime) ? entryTime.plusMinutes(1) : now;
        } else if (mode == 2) {
            int mins = readInt("Enter duration in minutes (1 to 1440): ", 1, 1440);
            return entryTime.plusMinutes(mins);
        } else {
            LocalTime exitClock = readTime("Enter Exit Time (HH:mm): ");
            LocalDateTime candidate = LocalDateTime.of(entryTime.toLocalDate(), exitClock);
            if (candidate.isBefore(entryTime)) {
                candidate = candidate.plusDays(1);
            }
            return candidate;
        }
    }

    private void printTicketSlip(ParkingTicket ticket) {
        System.out.println("+--------------------------------------------------+");
        System.out.println("|          CAMPUS SMART-PARKING TICKET             |");
        System.out.println("+--------------------------------------------------+");
        System.out.printf("| Ticket ID   : %-34s |%n", ticket.getTicketId());
        System.out.printf("| Vehicle Reg : %-34s |%n", ticket.getVehicle().getRegistrationNumber());
        System.out.printf("| Category    : %-34s |%n", ticket.getVehicle().getVehicleType().getDisplayName());
        System.out.printf("| Owner       : %-34s |%n", ticket.getVehicle().getOwnerName());
        System.out.printf("| Slot Code   : %-34s |%n", ticket.getSlotCode());
        System.out.printf("| Entry Time  : %-34s |%n", ticket.getEntryTime().format(FULL_FORMAT));
        System.out.printf("| Status      : %-34s |%n", ticket.isSettled() ? "SETTLED" : "ACTIVE");
        System.out.println("+--------------------------------------------------+");
    }

    private void printExitReceipt(ParkingTicket ticket) {
        System.out.println("+--------------------------------------------------+");
        System.out.println("|            PARKING EXIT & FEE RECEIPT            |");
        System.out.println("+--------------------------------------------------+");
        System.out.printf("| Ticket ID     : %-32s |%n", ticket.getTicketId());
        System.out.printf("| Vehicle       : %-32s |%n", ticket.getVehicle().getRegistrationNumber()
                + " (" + ticket.getVehicle().getVehicleType().getDisplayName() + ")");
        System.out.printf("| Slot Released : %-32s |%n", ticket.getSlotCode());
        System.out.printf("| Entry Time    : %-32s |%n", ticket.getEntryTime().format(FULL_FORMAT));
        System.out.printf("| Exit Time     : %-32s |%n", ticket.getExitTime().format(FULL_FORMAT));
        System.out.printf("| Billed Hours  : %-32s |%n", ticket.getBilledHours() + " hr(s)");
        System.out.printf("| Pass Applied  : %-32s |%n", truncate(ticket.getPassAppliedDescription(), 32));
        System.out.printf("| Parking Fee   : Rs %-29.2f |%n", ticket.getBaseParkingFee());
        System.out.printf("| EV Charging   : Rs %-29.2f |%n", ticket.getChargingFee());
        System.out.printf("| TOTAL PAID    : Rs %-29.2f |%n", ticket.getTotalFee());
        System.out.println("+--------------------------------------------------+");
    }

    private String truncate(String text, int maxLen) {
        if (text == null) {
            return "";
        }
        return text.length() <= maxLen ? text : text.substring(0, maxLen - 3) + "...";
    }

    private int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                int val = Integer.parseInt(line);
                if (val >= min && val <= max) {
                    return val;
                }
                System.out.println("Please enter a number between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Invalid integer input. Please try again.");
            }
        }
    }

    private double readDouble(String prompt, double min, double max) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                double val = Double.parseDouble(line);
                if (val >= min && val <= max) {
                    return val;
                }
                System.out.printf("Please enter a value between %.1f and %.1f.%n", min, max);
            } catch (NumberFormatException e) {
                System.out.println("Invalid decimal input. Please try again.");
            }
        }
    }

    private String readNonEmptyString(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            if (!line.isEmpty()) {
                return line;
            }
            System.out.println("Input cannot be empty. Please try again.");
        }
    }

    private LocalTime readTime(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return LocalTime.parse(line, TIME_ONLY_FORMAT);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid time format. Use 24-hour HH:mm (e.g., 09:30 or 16:45).");
            }
        }
    }
}
