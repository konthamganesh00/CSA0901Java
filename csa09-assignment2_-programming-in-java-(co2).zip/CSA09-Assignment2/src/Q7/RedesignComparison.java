package Q7;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Q7 - Day-4 Design Challenge: RedesignComparison
 * Problem Selected: String (+) Concatenation Bottleneck from Q1 (Railway Ticket & Chart Generation)
 *
 * Compares:
 *   1. Original Design   : String concatenation using '+' inside loops (O(k^2) copying)
 *   2. Redesigned Design : Pre-sized StringBuilder (exact capacity estimation + single-pass append)
 *
 * Validates identical output on identical inputs, runs repeated System.nanoTime() trials,
 * calculates average execution time and speedup ratio, and exports raw measurements to:
 *   ExperimentalData/Q7_RedesignBenchmark.csv
 */
public class RedesignComparison {

    private static final int WARMUP_RUNS = 3;
    private static final int MEASURED_RUNS = 5;

    private static final String[] PASSENGERS = {
        "Aarav Sharma", "Diya Nair", "Rohan Verma", "Meera Krishnan", "Karthik Iyer"
    };
    private static final String[] COACHES = {"B1", "B2", "B4", "A1", "S5"};
    private static final String[] BERTHS = {"LB-12", "UB-24", "MB-19", "SL-07", "SU-32"};

    private static volatile long blackhole = 0;

    record BenchmarkRow(
            String workload,
            String implementation,
            int iteration,
            long elapsedNanos,
            double elapsedMillis,
            long approxMemoryBytes,
            long checksum
    ) {}

    @FunctionalInterface
    interface WorkloadRunner {
        String[] generateSampleAndChecksum(long[] outChecksum);
    }

    // -------------------------------------------------------------------------
    // Original Implementation: String '+' Concatenation in Loop
    // -------------------------------------------------------------------------

    public static String buildSingleTicketOriginal(int ticketIndex, int fieldCount) {
        if (ticketIndex < 0 || fieldCount < 1) {
            throw new IllegalArgumentException("ticketIndex must be >= 0 and fieldCount >= 1.");
        }
        String ticket = "PNR=" + (4100000000L + ticketIndex);
        for (int f = 1; f < fieldCount; f++) {
            ticket = ticket + ";F" + f + "=" + fieldValue(ticketIndex, f);
        }
        return ticket;
    }

    public static String buildChartOriginal(int entryCount) {
        if (entryCount < 0) {
            throw new IllegalArgumentException("entryCount cannot be negative: " + entryCount);
        }
        String chart = "=== RESERVATION CHART ===\n";
        for (int i = 0; i < entryCount; i++) {
            chart = chart + "PNR:" + (4500000000L + i)
                    + ",Name:" + PASSENGERS[i % PASSENGERS.length]
                    + ",Coach:" + COACHES[i % COACHES.length]
                    + ",Berth:" + BERTHS[i % BERTHS.length]
                    + ",Fare:1450.00\n";
        }
        return chart;
    }

    // -------------------------------------------------------------------------
    // Redesigned Implementation: Capacity-Tuned StringBuilder
    // -------------------------------------------------------------------------

    public static String buildSingleTicketRedesigned(int ticketIndex, int fieldCount) {
        if (ticketIndex < 0 || fieldCount < 1) {
            throw new IllegalArgumentException("ticketIndex must be >= 0 and fieldCount >= 1.");
        }
        // Estimate ~18 bytes per field to eliminate internal array resizing
        StringBuilder sb = new StringBuilder(fieldCount * 18);
        sb.append("PNR=").append(4100000000L + ticketIndex);
        for (int f = 1; f < fieldCount; f++) {
            sb.append(";F").append(f).append('=').append(fieldValue(ticketIndex, f));
        }
        return sb.toString();
    }

    public static String buildChartRedesigned(int entryCount) {
        if (entryCount < 0) {
            throw new IllegalArgumentException("entryCount cannot be negative: " + entryCount);
        }
        int estimatedCapacity = 32 + entryCount * 72;
        StringBuilder chart = new StringBuilder(estimatedCapacity);
        chart.append("=== RESERVATION CHART ===\n");
        for (int i = 0; i < entryCount; i++) {
            chart.append("PNR:").append(4500000000L + i)
                 .append(",Name:").append(PASSENGERS[i % PASSENGERS.length])
                 .append(",Coach:").append(COACHES[i % COACHES.length])
                 .append(",Berth:").append(BERTHS[i % BERTHS.length])
                 .append(",Fare:1450.00\n");
        }
        return chart.toString();
    }

    private static String fieldValue(int ticketIndex, int fieldIndex) {
        return switch (fieldIndex % 5) {
            case 0 -> PASSENGERS[ticketIndex % PASSENGERS.length];
            case 1 -> COACHES[ticketIndex % COACHES.length];
            case 2 -> BERTHS[ticketIndex % BERTHS.length];
            case 3 -> "MAS-SBC";
            default -> "1450.00";
        };
    }

    // -------------------------------------------------------------------------
    // Benchmark Harness
    // -------------------------------------------------------------------------

    private static long getUsedMemoryBytes() {
        Runtime rt = Runtime.getRuntime();
        return rt.totalMemory() - rt.freeMemory();
    }

    private static List<BenchmarkRow> runBenchmark(
            String workloadName,
            String implementationName,
            WorkloadRunner runner) {

        long[] sink = new long[1];
        for (int w = 0; w < WARMUP_RUNS; w++) {
            runner.generateSampleAndChecksum(sink);
            blackhole += sink[0];
        }

        List<BenchmarkRow> rows = new ArrayList<>();
        for (int iter = 1; iter <= MEASURED_RUNS; iter++) {
            System.gc();
            try {
                Thread.sleep(15);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }

            long memBefore = getUsedMemoryBytes();
            long start = System.nanoTime();
            runner.generateSampleAndChecksum(sink);
            long end = System.nanoTime();
            long memAfter = getUsedMemoryBytes();

            blackhole += sink[0];
            long nanos = end - start;
            rows.add(new BenchmarkRow(
                    workloadName,
                    implementationName,
                    iter,
                    nanos,
                    nanos / 1_000_000.0,
                    Math.max(0L, memAfter - memBefore),
                    sink[0]
            ));
        }
        return rows;
    }

    private static void verifyIdenticalOutputs() {
        String origTicket = buildSingleTicketOriginal(42, 50);
        String newTicket = buildSingleTicketRedesigned(42, 50);
        if (!origTicket.equals(newTicket)) {
            throw new IllegalStateException("Ticket mismatch between original and redesigned implementations!");
        }

        String origChart = buildChartOriginal(50);
        String newChart = buildChartRedesigned(50);
        if (!origChart.equals(newChart)) {
            throw new IllegalStateException("Chart mismatch between original and redesigned implementations!");
        }
        System.out.println("Output equivalence check passed: Original.equals(Redesigned) == true");
    }

    private static void printComparisonSummary(
            String workloadName,
            List<BenchmarkRow> origRows,
            List<BenchmarkRow> newRows) {

        double origAvgMs = origRows.stream().mapToDouble(BenchmarkRow::elapsedMillis).average().orElse(0.0);
        double newAvgMs = newRows.stream().mapToDouble(BenchmarkRow::elapsedMillis).average().orElse(0.0);
        double speedup = (newAvgMs > 0.0) ? (origAvgMs / newAvgMs) : 0.0;
        double reductionPct = (origAvgMs > 0.0) ? ((origAvgMs - newAvgMs) / origAvgMs) * 100.0 : 0.0;

        System.out.printf(Locale.US,
                "%-32s | %12.4f ms | %12.4f ms | %9.2fx | %7.2f%%%n",
                workloadName, origAvgMs, newAvgMs, speedup, reductionPct);
    }

    private static Path resolveCsvPath(String fileName) throws IOException {
        Path direct = Path.of("ExperimentalData");
        Path nested = Path.of("CSA09-Assignment2", "ExperimentalData");
        Path dir = Files.exists(direct) ? direct : (Files.exists(nested) ? nested : direct);
        Files.createDirectories(dir);
        return dir.resolve(fileName);
    }

    private static void writeCsv(List<BenchmarkRow> rows, Path csvPath) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(csvPath)) {
            writer.write("Workload,Implementation,Iteration,ElapsedNanos,ElapsedMillis,ApproxMemoryBytes,Checksum\n");
            for (BenchmarkRow r : rows) {
                writer.write(String.format(Locale.US, "%s,%s,%d,%d,%.4f,%d,%d%n",
                        r.workload(),
                        r.implementation(),
                        r.iteration(),
                        r.elapsedNanos(),
                        r.elapsedMillis(),
                        r.approxMemoryBytes(),
                        r.checksum()));
            }
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println("==========================================================================");
        System.out.println("Q7: Day-4 Design Challenge - Original String(+) vs Redesigned StringBuilder");
        System.out.println("==========================================================================");

        verifyIdenticalOutputs();

        System.out.println("\nRunning controlled A/B comparison (" + WARMUP_RUNS + " warmup, " + MEASURED_RUNS + " measured runs)...");
        System.out.printf("%-32s | %-15s | %-15s | %-10s | %-8s%n",
                "Workload", "Original (ms)", "Redesigned (ms)", "Speedup", "Saved %");
        System.out.println("-".repeat(92));

        List<BenchmarkRow> allRows = new ArrayList<>();

        // Workload 1: 1,000 tickets x 50 fields
        List<BenchmarkRow> w1Orig = runBenchmark("Batch_1000x50", "Original_StringPlus", out -> {
            long sum = 0;
            for (int i = 0; i < 1_000; i++) {
                sum += buildSingleTicketOriginal(i, 50).length();
            }
            out[0] = sum;
            return null;
        });
        List<BenchmarkRow> w1New = runBenchmark("Batch_1000x50", "Redesigned_PreSizedSB", out -> {
            long sum = 0;
            for (int i = 0; i < 1_000; i++) {
                sum += buildSingleTicketRedesigned(i, 50).length();
            }
            out[0] = sum;
            return null;
        });
        allRows.addAll(w1Orig);
        allRows.addAll(w1New);
        printComparisonSummary("Batch_1000x50", w1Orig, w1New);

        // Workload 2: 10,000 tickets x 50 fields
        List<BenchmarkRow> w2Orig = runBenchmark("Batch_10000x50", "Original_StringPlus", out -> {
            long sum = 0;
            for (int i = 0; i < 10_000; i++) {
                sum += buildSingleTicketOriginal(i, 50).length();
            }
            out[0] = sum;
            return null;
        });
        List<BenchmarkRow> w2New = runBenchmark("Batch_10000x50", "Redesigned_PreSizedSB", out -> {
            long sum = 0;
            for (int i = 0; i < 10_000; i++) {
                sum += buildSingleTicketRedesigned(i, 50).length();
            }
            out[0] = sum;
            return null;
        });
        allRows.addAll(w2Orig);
        allRows.addAll(w2New);
        printComparisonSummary("Batch_10000x50", w2Orig, w2New);

        // Workload 3: Consolidated Reservation Chart (3,000 entries)
        List<BenchmarkRow> w3Orig = runBenchmark("Chart_3000Entries", "Original_StringPlus", out -> {
            out[0] = buildChartOriginal(3_000).length();
            return null;
        });
        List<BenchmarkRow> w3New = runBenchmark("Chart_3000Entries", "Redesigned_PreSizedSB", out -> {
            out[0] = buildChartRedesigned(3_000).length();
            return null;
        });
        allRows.addAll(w3Orig);
        allRows.addAll(w3New);
        printComparisonSummary("Chart_3000Entries", w3Orig, w3New);

        Path csvPath = resolveCsvPath("Q7_RedesignBenchmark.csv");
        writeCsv(allRows, csvPath);
        System.out.println("\nSaved raw comparison measurements to: " + csvPath.toAbsolutePath());
        System.out.println("Blackhole checksum: " + blackhole);
    }
}
