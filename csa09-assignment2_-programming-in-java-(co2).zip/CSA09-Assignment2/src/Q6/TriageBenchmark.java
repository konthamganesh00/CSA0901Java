package Q6;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

/**
 * Q6 - TriageBenchmark
 * Compares three triage queue designs across 1,000, 10,000, and 50,000 patients:
 *   1. PriorityQueue (Binary Min-Heap: O(log n) enqueue, O(log n) dequeue)
 *   2. Sorted LinkedList (Insertion sort scan: O(n) enqueue, O(1) dequeue)
 *   3. Five FIFO Queues (5 ArrayDeque buckets for S1..S5: O(1) enqueue, O(1) dequeue)
 *
 * Writes raw per-iteration measurements to ExperimentalData/Q6_QueueBenchmark.csv.
 */
public class TriageBenchmark {

    private static final int[] QUEUE_SIZES = {1_000, 10_000, 50_000};
    private static final int WARMUP_RUNS = 1;
    private static final int MEASURED_RUNS = 3;

    private static volatile long blackhole = 0;

    record BenchmarkRow(
            int queueSize,
            String structure,
            int iteration,
            long enqueueNanos,
            long dequeueNanos,
            long totalNanos,
            double totalMillis,
            long checksum
    ) {}

    private static Patient[] generatePatients(int count) {
        Patient[] patients = new Patient[count];
        Random rng = new Random(2026L + count);
        for (int i = 0; i < count; i++) {
            int severity = 1 + rng.nextInt(5);
            patients[i] = new Patient("P" + i, severity, i + 1L);
        }
        return patients;
    }

    private static BenchmarkRow runPriorityQueue(int size, Patient[] patients, int iteration) {
        PriorityQueue<Patient> pq = new PriorityQueue<>(size, Triage.TRIAGE_COMPARATOR);

        long t0 = System.nanoTime();
        for (Patient p : patients) {
            pq.offer(p);
        }
        long t1 = System.nanoTime();

        long checksum = 0;
        while (!pq.isEmpty()) {
            Patient next = pq.poll();
            checksum += next.getSeverity() * 31L + next.getArrivalSeq();
        }
        long t2 = System.nanoTime();

        long enq = t1 - t0;
        long deq = t2 - t1;
        long tot = t2 - t0;
        return new BenchmarkRow(size, "PriorityQueue", iteration, enq, deq, tot, tot / 1_000_000.0, checksum);
    }

    private static BenchmarkRow runSortedLinkedList(int size, Patient[] patients, int iteration) {
        LinkedList<Patient> list = new LinkedList<>();

        long t0 = System.nanoTime();
        for (Patient p : patients) {
            ListIterator<Patient> it = list.listIterator();
            while (it.hasNext()) {
                if (Triage.TRIAGE_COMPARATOR.compare(p, it.next()) < 0) {
                    it.previous();
                    break;
                }
            }
            it.add(p);
        }
        long t1 = System.nanoTime();

        long checksum = 0;
        while (!list.isEmpty()) {
            Patient next = list.removeFirst();
            checksum += next.getSeverity() * 31L + next.getArrivalSeq();
        }
        long t2 = System.nanoTime();

        long enq = t1 - t0;
        long deq = t2 - t1;
        long tot = t2 - t0;
        return new BenchmarkRow(size, "SortedLinkedList", iteration, enq, deq, tot, tot / 1_000_000.0, checksum);
    }

    @SuppressWarnings("unchecked")
    private static BenchmarkRow runFiveFifoQueues(int size, Patient[] patients, int iteration) {
        Queue<Patient>[] buckets = new Queue[5];
        for (int s = 0; s < 5; s++) {
            buckets[s] = new ArrayDeque<>(size / 5 + 16);
        }

        long t0 = System.nanoTime();
        for (Patient p : patients) {
            buckets[p.getSeverity() - 1].offer(p);
        }
        long t1 = System.nanoTime();

        long checksum = 0;
        for (int s = 0; s < 5; s++) {
            Queue<Patient> q = buckets[s];
            while (!q.isEmpty()) {
                Patient next = q.poll();
                checksum += next.getSeverity() * 31L + next.getArrivalSeq();
            }
        }
        long t2 = System.nanoTime();

        long enq = t1 - t0;
        long deq = t2 - t1;
        long tot = t2 - t0;
        return new BenchmarkRow(size, "FiveFifoQueues", iteration, enq, deq, tot, tot / 1_000_000.0, checksum);
    }

    private static void printSummary(int size, List<BenchmarkRow> rows) {
        System.out.println("\n--- Queue Size N = " + size + " patients ---");
        System.out.printf("%-18s | %-13s | %-13s | %-13s%n",
                "Structure", "Avg Enq (ms)", "Avg Deq (ms)", "Avg Total(ms)");
        System.out.println("-".repeat(66));

        for (String structure : List.of("PriorityQueue", "SortedLinkedList", "FiveFifoQueues")) {
            List<BenchmarkRow> group = rows.stream()
                    .filter(r -> r.queueSize() == size && r.structure().equals(structure))
                    .toList();
            double avgEnq = group.stream().mapToLong(BenchmarkRow::enqueueNanos).average().orElse(0.0) / 1_000_000.0;
            double avgDeq = group.stream().mapToLong(BenchmarkRow::dequeueNanos).average().orElse(0.0) / 1_000_000.0;
            double avgTot = group.stream().mapToDouble(BenchmarkRow::totalMillis).average().orElse(0.0);

            System.out.printf(Locale.US, "%-18s | %13.4f | %13.4f | %13.4f%n",
                    structure, avgEnq, avgDeq, avgTot);
        }
    }

    private static Path resolveCsvPath(String fileName) throws IOException {
        Path direct = Path.of("ExperimentalData");
        Path nested = Path.of("CSA09-Assignment2", "ExperimentalData");
        Path dir = Files.exists(direct) ? direct : (Files.exists(nested) ? nested : direct);
        Files.createDirectories(dir);
        return dir.resolve(fileName);
    }

    private static void writeCsv(List<BenchmarkRow> rows, Path csvPath) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(csvPath)) {
            writer.write("QueueSize,Structure,Iteration,EnqueueNanos,DequeueNanos,TotalNanos,TotalMillis,Checksum\n");
            for (BenchmarkRow r : rows) {
                writer.write(String.format(Locale.US, "%d,%s,%d,%d,%d,%d,%.4f,%d%n",
                        r.queueSize(),
                        r.structure(),
                        r.iteration(),
                        r.enqueueNanos(),
                        r.dequeueNanos(),
                        r.totalNanos(),
                        r.totalMillis(),
                        r.checksum()));
            }
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println("==========================================================================");
        System.out.println("Q6: Emergency Triage Benchmark (PriorityQueue vs SortedLinkedList vs 5-FIFO)");
        System.out.println("==========================================================================");

        List<BenchmarkRow> allRows = new ArrayList<>();

        for (int size : QUEUE_SIZES) {
            Patient[] patients = generatePatients(size);

            for (int w = 0; w < WARMUP_RUNS; w++) {
                blackhole += runPriorityQueue(size, patients, 0).checksum();
                blackhole += runFiveFifoQueues(size, patients, 0).checksum();
                if (size <= 10_000) {
                    blackhole += runSortedLinkedList(size, patients, 0).checksum();
                }
            }

            for (int iter = 1; iter <= MEASURED_RUNS; iter++) {
                BenchmarkRow pqRow = runPriorityQueue(size, patients, iter);
                BenchmarkRow sllRow = runSortedLinkedList(size, patients, iter);
                BenchmarkRow fifoRow = runFiveFifoQueues(size, patients, iter);

                // Verify all 3 structures produce identical dequeue order checksum
                if (pqRow.checksum() != sllRow.checksum() || pqRow.checksum() != fifoRow.checksum()) {
                    throw new IllegalStateException("Checksum mismatch between triage structures!");
                }

                blackhole += pqRow.checksum();
                allRows.add(pqRow);
                allRows.add(sllRow);
                allRows.add(fifoRow);
            }

            printSummary(size, allRows);
        }

        Path csvPath = resolveCsvPath("Q6_QueueBenchmark.csv");
        writeCsv(allRows, csvPath);
        System.out.println("\nSaved raw benchmark measurements to: " + csvPath.toAbsolutePath());
        System.out.println("Blackhole checksum: " + blackhole);
    }
}
