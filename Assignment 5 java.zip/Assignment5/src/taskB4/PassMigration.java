
package taskB4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PassMigration {

    static String url = "jdbc:mysql://localhost:3306/assignment5";
    static String user = "root";
    static String password = "12345";

    // Read and validate records from the text file
    static List<String[]> readPasses(String fileName) {

        List<String[]> validPasses = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(
                new FileReader(fileName))) {

            String line;
            int lineNumber = 0;

            while ((line = br.readLine()) != null) {

                lineNumber++;

                if (line.trim().isEmpty()) {
                    System.out.println("Line " + lineNumber
                            + ": Empty line skipped");
                    continue;
                }

                String[] p = line.split(",", -1);

                if (p.length != 5) {
                    System.out.println("Line " + lineNumber
                            + ": Invalid field count - " + line);
                    continue;
                }

                try {
                    Integer.parseInt(p[3].trim());
                    Double.parseDouble(p[4].trim());

                    for (int i = 0; i < p.length; i++) {
                        p[i] = p[i].trim();
                    }

                    validPasses.add(p);

                } catch (NumberFormatException e) {

                    System.out.println("Line " + lineNumber
                            + ": Invalid numeric data - " + line);
                }
            }

        } catch (Exception e) {
            System.out.println("File Error: " + e.getMessage());
        }

        return validPasses;
    }

    // Load records into database in batches of 1000
    static int loadPasses(Connection con,
                           List<String[]> passes) throws SQLException {

        String sql = "INSERT INTO bus_pass "
                + "(pass_id, reg_no, name, route_no, amount) "
                + "VALUES (?, ?, ?, ?, ?)";

        boolean oldAutoCommit = con.getAutoCommit();

        con.setAutoCommit(false);

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            int count = 0;

            for (String[] p : passes) {

                ps.setString(1, p[0]);
                ps.setString(2, p[1]);
                ps.setString(3, p[2]);
                ps.setInt(4, Integer.parseInt(p[3]));
                ps.setDouble(5, Double.parseDouble(p[4]));

                ps.addBatch();
                count++;

                if (count % 1000 == 0) {
                    ps.executeBatch();
                    ps.clearBatch();
                }
            }

            ps.executeBatch();

            con.commit();

            return count;

        } catch (SQLException | RuntimeException e) {

            con.rollback();

            System.out.println("Migration failed. Transaction rolled back.");

            throw e;

        } finally {

            con.setAutoCommit(oldAutoCommit);
        }
    }

    // Display database information
    static void showDatabaseInfo(Connection con) throws SQLException {

        DatabaseMetaData md = con.getMetaData();

        System.out.println("\nDATABASE INFORMATION");

        System.out.println("Database Product: "
                + md.getDatabaseProductName());

        System.out.println("Database Version: "
                + md.getDatabaseProductVersion());

        System.out.println("JDBC Driver: "
                + md.getDriverName());

        System.out.println("Driver Version: "
                + md.getDriverVersion());

        System.out.println("\nTABLES:");

        try (ResultSet rs = md.getTables(
                con.getCatalog(), null, "%", new String[]{"TABLE"})) {

            while (rs.next()) {
                System.out.println(rs.getString("TABLE_NAME"));
            }
        }
    }

    public static void main(String[] args) {

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                    url, user, password);

            System.out.println("Database Connected Successfully!");

            showDatabaseInfo(con);

            List<String[]> passes = readPasses("passes.txt");

            System.out.println("\nValid records: " + passes.size());

            int loaded = loadPasses(con, passes);

            System.out.println("Records successfully loaded: " + loaded);

            con.close();

            System.out.println("\nMigration Completed!");

        } catch (Exception e) {

            System.out.println("Error: " + e.getMessage());
        }
    }
}
