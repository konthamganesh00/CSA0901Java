package Q2;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Q2 - Main Demonstration Driver
 * Demonstrates Music Playlist Editor operations across ArrayList, LinkedList,
 * and ArrayDeque, verifies normal/boundary/invalid-input cases, and runs PlaylistBenchmark.
 */
public class Main {

    private static void verify(boolean condition, String testName) {
        if (!condition) {
            throw new AssertionError("Test failed: " + testName);
        }
        System.out.println("[PASS] " + testName);
    }

    private static void runPlaylistTests() {
        System.out.println("\n--- Q2 Normal, Boundary & Invalid Input Tests ---");

        // 1. Normal test: ArrayList, LinkedList, ArrayDeque behavior
        List<String> arrayPlaylist = new ArrayList<>();
        arrayPlaylist.add("Track-A");
        arrayPlaylist.add("Track-C");
        arrayPlaylist.add(1, "Track-B"); // middle insert
        verify("[Track-A, Track-B, Track-C]".equals(arrayPlaylist.toString()),
                "ArrayList end + middle insert ordering");

        LinkedList<String> linkedPlaylist = new LinkedList<>(arrayPlaylist);
        linkedPlaylist.addFirst("Intro");
        linkedPlaylist.removeLast();
        verify("[Intro, Track-A, Track-B]".equals(linkedPlaylist.toString()),
                "LinkedList addFirst + removeLast ordering");

        Deque<String> upNext = new ArrayDeque<>(arrayPlaylist);
        upNext.addFirst("Priority-Track");
        verify("Priority-Track".equals(upNext.pollFirst()),
                "ArrayDeque Up Next queue priority front dequeue");

        // 2. Boundary test: Empty collections
        List<String> emptyList = new ArrayList<>();
        Deque<String> emptyDeque = new ArrayDeque<>();
        verify(emptyList.isEmpty() && emptyDeque.pollFirst() == null,
                "Boundary test: empty list check and safe pollFirst() returning null");

        try {
            emptyDeque.removeFirst();
            verify(false, "removeFirst() on empty ArrayDeque should throw NoSuchElementException");
        } catch (NoSuchElementException ex) {
            System.out.println("[PASS] Empty ArrayDeque removeFirst() caught cleanly: " + ex.getClass().getSimpleName());
        }

        // 3. Invalid index test
        try {
            arrayPlaylist.get(99);
            verify(false, "Out-of-bounds get(99) should throw IndexOutOfBoundsException");
        } catch (IndexOutOfBoundsException ex) {
            System.out.println("[PASS] Invalid playlist index caught cleanly: " + ex.getMessage());
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println("==========================================================================");
        System.out.println("Q2 DEMONSTRATION: ARRAYLIST, LINKEDLIST AND ARRAYDEQUE");
        System.out.println("Problem: Music Playlist Editor");
        System.out.println("==========================================================================");

        System.out.println("Sample Inputs:");
        System.out.println("  Initial Playlist: [Track-A, Track-C], Middle Insert: Track-B at index 1");
        System.out.println("  Benchmark Sizes : 1,000 | 10,000 | 50,000 songs");

        runPlaylistTests();

        System.out.println("\n--- Executing Full Q2 Benchmark & CSV Export ---");
        PlaylistBenchmark.main(args);
    }
}
