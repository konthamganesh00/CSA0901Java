# Programming in Java – Assignment 2 (CO2)

## Student Information
- **Student Name:** `[YOUR NAME HERE]`
- **Register Number:** `[YOUR REGISTER NUMBER HERE]`
- **Course / Subject:** CSA09 – Programming in Java (CO2)
- **Academic Year / Semester:** B.Tech II Year
- **Faculty Name:** `[FACULTY NAME HERE]`
- **GitHub Repository:** `[GITHUB REPOSITORY LINK HERE]`

---

## Requirements
- **Java Development Kit:** Java 21 (LTS)
- **IDE:** Eclipse IDE for Java Developers (or any Java 21 CLI)
- **Libraries:** Standard Java 21 JDK (`java.util`, `java.io`, `java.nio.file`) — zero external dependencies.

---

## Project Introduction
This project implements all seven questions (Q1–Q7) of **Programming in Java – Assignment 2 (CO2)**. Each question lives in its own Java package (`Q1`–`Q7`) with a user-friendly `Main.java` demonstration driver (including normal, boundary, and invalid-input tests), standalone assignment/benchmark classes, `README.md` documentation with sample I/O, and CSV export to `ExperimentalData/`.

---

## Question Summary (Q1–Q7)

| Question | Topic | Problem Domain | `Main` Driver | Additional Classes |
|---|---|---|---|---|
| **Q1** | `String`, `StringBuilder`, `StringBuffer` | Railway E-Ticket Generation | `Q1.Main` | `Q1.StringBenchmark` |
| **Q2** | `ArrayList`, `LinkedList`, `ArrayDeque` | Music Playlist Editor | `Q2.Main` | `Q2.PlaylistBenchmark` |
| **Q3** | `hashCode()` and `equals()` | College Event Attendance De-duplication | `Q3.Main` | `Q3.Student`, `Q3.Attendance`, `Q3.HashSetExperiment` |
| **Q4** | `HashMap`, `TreeMap`, `LinkedHashMap` | Hospital Pharmacy Inventory | `Q4.Main` | `Q4.Medicine`, `Q4.PharmacyInventory`, `Q4.MapBenchmark` |
| **Q5** | Generics, `Comparable`, `Comparator` | Inter-College Sports Leaderboard | `Q5.Main` | `Q5.Team`, `Q5.Leaderboard`, `Q5.LeaderboardDemo` |
| **Q6** | `Queue` and `PriorityQueue` | Hospital Emergency Triage | `Q6.Main` | `Q6.Patient`, `Q6.Triage`, `Q6.TriageBenchmark` |
| **Q7** | Day-4 Design Challenge | Redesigning Q1 Quadratic Concatenation | `Q7.Main` | `Q7.RedesignComparison`, `Q7/DesignChallenge.md` |

---

## Project Folder Structure

```text
CSA09-Assignment2/
|-- .project
|-- .classpath
|-- .settings/
|   |-- org.eclipse.jdt.core.prefs
|-- src/
|   |-- Q1/ (Main.java, StringBenchmark.java, README.md)
|   |-- Q2/ (Main.java, PlaylistBenchmark.java, README.md)
|   |-- Q3/ (Main.java, Student.java, Attendance.java, HashSetExperiment.java, README.md)
|   |-- Q4/ (Main.java, Medicine.java, PharmacyInventory.java, MapBenchmark.java, README.md)
|   |-- Q5/ (Main.java, Team.java, Leaderboard.java, LeaderboardDemo.java, README.md)
|   |-- Q6/ (Main.java, Patient.java, Triage.java, TriageBenchmark.java, README.md)
|   |-- Q7/ (Main.java, RedesignComparison.java, DesignChallenge.md, README.md)
|-- ExperimentalData/
|   |-- Q1_StringBenchmark.csv
|   |-- Q2_ListBenchmark.csv
|   |-- Q4_MapBenchmark.csv
|   |-- Q6_QueueBenchmark.csv
|   |-- Q7_RedesignBenchmark.csv
|-- Screenshots/
|   |-- README.md
|-- UML/
|   |-- ClassDiagrams.md
|-- README.md
|-- AssignmentReport.md
```

---

## How to Import into Eclipse
1. Open **Eclipse IDE**.
2. Go to **File → Import… → General → Existing Projects into Workspace**.
3. Click **Browse…** and select the `CSA09-Assignment2` directory.
4. Ensure `CSA09-Assignment2` is checked and click **Finish**.
5. Verify in **Project → Properties → Java Compiler** that compliance level is **21** (pre-configured via `.settings/org.eclipse.jdt.core.prefs`).
6. Right-click `Main.java` inside any package (`Q1`–`Q7`) → **Run As → Java Application**.

---

## Command-Line Compilation & Execution (Java 21)

From inside the `CSA09-Assignment2/` directory:

### Compile All Sources
```bash
mkdir -p bin
javac --release 21 -Xlint:all -d bin src/Q1/*.java src/Q2/*.java src/Q3/*.java src/Q4/*.java src/Q5/*.java src/Q6/*.java src/Q7/*.java
```

### Run Unified `Main` Driver for Every Question
```bash
java -cp bin Q1.Main
java -cp bin Q2.Main
java -cp bin Q3.Main
java -cp bin Q4.Main
java -cp bin Q5.Main
java -cp bin Q6.Main
java -cp bin Q7.Main
```

### Or Run Individual Standalone Classes
```bash
java -cp bin Q1.StringBenchmark
java -cp bin Q2.PlaylistBenchmark
java -cp bin Q3.Attendance
java -cp bin Q3.HashSetExperiment
java -cp bin Q4.PharmacyInventory
java -cp bin Q4.MapBenchmark
java -cp bin Q5.LeaderboardDemo
java -cp bin Q6.Triage
java -cp bin Q6.TriageBenchmark
java -cp bin Q7.RedesignComparison
```

---

## Expected Outputs for Deterministic Programs
- **`Q3.Attendance`**:
  ```text
  Unique students: 2
  ```
- **`Q5.LeaderboardDemo` (first line)**:
  ```text
  [Eagles(9,6), Bisons(9,4), Panthers(9,4), Cobras(6,1)]
  ```
- **`Q6.Triage` (first line)**:
  ```text
  Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)
  ```

---

## Benchmark Execution & Experimental Data
Running `Q1`, `Q2`, `Q4`, `Q6`, and `Q7` executes JIT warmup runs followed by repeated timed iterations using `System.nanoTime()`. Raw per-iteration measurements are automatically exported to:
- `ExperimentalData/Q1_StringBenchmark.csv`
- `ExperimentalData/Q2_ListBenchmark.csv`
- `ExperimentalData/Q4_MapBenchmark.csv`
- `ExperimentalData/Q6_QueueBenchmark.csv`
- `ExperimentalData/Q7_RedesignBenchmark.csv`

No synthetic or fabricated measurements are pre-populated. Sample expected outputs and actual measured results are kept strictly separate in `AssignmentReport.md`.
