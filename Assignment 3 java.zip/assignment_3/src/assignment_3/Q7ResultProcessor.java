package assignment_3;


import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public class Q7ResultProcessor {

    static class Result {
        int studentId;
        boolean success;
        String message;

        Result(int studentId, boolean success, String message) {
            this.studentId = studentId;
            this.success = success;
            this.message = message;
        }
    }

    // Create 10,000 student result files
    static void createFiles(Path folder) throws IOException {

        for (int i = 1; i <= 10000; i++) {

            Path file = folder.resolve("student" + i + ".txt");

            // Simulate missing files
            if (i % 100 == 0) {
                continue;
            }

            // Simulate corrupt files
            if (i % 100 == 1) {
                Files.writeString(file, "Invalid Marks");
            } else {
                Files.writeString(file, String.valueOf(i * 10));
            }
        }
    }

    // Process one student file
    static Result processFile(
            int id,
            Path file,
            ConcurrentHashMap<Integer, String> results) {

        try {
            String data = Files.readString(file);
            int marks = Integer.parseInt(data.trim());

            if (marks < 0 || marks > 100000) {
                throw new IllegalArgumentException("Invalid marks");
            }

            results.put(id, "SUCCESS");

            return new Result(id, true, "Processed");

        } catch (IOException | IllegalArgumentException e) {

            results.put(id, "FAILED");

            return new Result(id, false, e.getMessage());
        }
    }

    // Process files using a thread pool
    static void processFiles(Path folder, int poolSize)
            throws InterruptedException, ExecutionException {

        ExecutorService executor =
                Executors.newFixedThreadPool(poolSize);

        ConcurrentHashMap<Integer, String> results =
                new ConcurrentHashMap<>();

        List<Future<Result>> futures = new ArrayList<>();

        long start = System.currentTimeMillis();

        for (int i = 1; i <= 10000; i++) {

            final int id = i;

            Path file = folder.resolve("student" + id + ".txt");

            Callable<Result> task = () ->
                    processFile(id, file, results);

            futures.add(executor.submit(task));
        }

        int success = 0;
        int failure = 0;

        for (Future<Result> future : futures) {

            Result result = future.get();

            if (result.success) {
                success++;
            } else {
                failure++;
            }
        }

        executor.shutdown();

        long end = System.currentTimeMillis();

        System.out.println("\nThread Pool Size: " + poolSize);
        System.out.println("Successful Files: " + success);
        System.out.println("Failed Files: " + failure);
        System.out.println("Total Files: " + (success + failure));
        System.out.println("Execution Time: " + (end - start) + " ms");
        System.out.println("Concurrent Results: " + results.size());
    }

    public static void main(String[] args) {

        try {
            Path folder =
                    Files.createTempDirectory("StudentResults");

            createFiles(folder);

            int[] poolSizes = {1, 2, 4, 8};

            for (int size : poolSizes) {
                processFiles(folder, size);
            }

            System.out.println("\nAll result processing completed.");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
