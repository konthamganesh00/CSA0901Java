package parking.model;

import java.time.LocalTime;

/**
 * Centralised, configurable pricing configuration for the Campus Smart-Parking System.
 *
 * <p>Reasonable assumptions are documented here where the assignment brief leaves exact
 * rupee amounts open. Rates are calibrated so that:
 * <ul>
 *   <li>TwoWheeler (3 hours) = Rs 10.0 x 3 = Rs 30.0</li>
 *   <li>Car (3 hours) = Rs 30.0 x 3 = Rs 90.0</li>
 *   <li>ElectricCar (3 hours + 7.5 kWh EV charging @ Rs 12/kWh) = (Rs 40.0 x 3) + (7.5 x Rs 12.0) = Rs 210.0</li>
 *   <li>EBike = Flat Rs 15.0 per visit</li>
 *   <li>DeliveryVan = Double Car rate (Rs 60.0/hr) between 09:00 and 17:00; Rs 30.0/hr otherwise</li>
 * </ul>
 */
public final class PricingConfig {

    private static double twoWheelerRatePerHour = 10.0;
    private static double carRatePerHour = 30.0;
    private static double electricCarRatePerHour = 40.0;
    private static double evChargingRatePerKwh = 12.0;
    private static double defaultEvChargingKwh = 7.5;
    private static double ebikeFlatFee = 15.0;

    private static double deliveryVanPeakMultiplier = 2.0;
    private static LocalTime deliveryVanPeakStart = LocalTime.of(9, 0);
    private static LocalTime deliveryVanPeakEnd = LocalTime.of(17, 0);

    private static double visitorOneDayPassFee = 50.0;
    private static double studentMonthlyPassPrice = 200.0;
    private static double staffMonthlyPassPrice = 300.0;

    private static double dailyMaxFeeCap = 500.0;
    private static boolean dailyMaxCapEnabled = true;

    private PricingConfig() {
        // Utility configuration class; prevent instantiation.
    }

    public static double getTwoWheelerRatePerHour() {
        return twoWheelerRatePerHour;
    }

    public static void setTwoWheelerRatePerHour(double rate) {
        if (rate >= 0) {
            twoWheelerRatePerHour = rate;
        }
    }

    public static double getCarRatePerHour() {
        return carRatePerHour;
    }

    public static void setCarRatePerHour(double rate) {
        if (rate >= 0) {
            carRatePerHour = rate;
        }
    }

    public static double getElectricCarRatePerHour() {
        return electricCarRatePerHour;
    }

    public static void setElectricCarRatePerHour(double rate) {
        if (rate >= 0) {
            electricCarRatePerHour = rate;
        }
    }

    public static double getEvChargingRatePerKwh() {
        return evChargingRatePerKwh;
    }

    public static void setEvChargingRatePerKwh(double ratePerKwh) {
        if (ratePerKwh >= 0) {
            evChargingRatePerKwh = ratePerKwh;
        }
    }

    public static double getDefaultEvChargingKwh() {
        return defaultEvChargingKwh;
    }

    public static void setDefaultEvChargingKwh(double kwh) {
        if (kwh >= 0) {
            defaultEvChargingKwh = kwh;
        }
    }

    public static double getEvChargingSessionFee() {
        return defaultEvChargingKwh * evChargingRatePerKwh;
    }

    public static void setEvChargingSessionFee(double fee) {
        if (fee >= 0 && evChargingRatePerKwh > 0) {
            defaultEvChargingKwh = fee / evChargingRatePerKwh;
        }
    }

    public static double getEbikeFlatFee() {
        return ebikeFlatFee;
    }

    public static void setEbikeFlatFee(double fee) {
        if (fee >= 0) {
            ebikeFlatFee = fee;
        }
    }

    public static double getDeliveryVanPeakMultiplier() {
        return deliveryVanPeakMultiplier;
    }

    public static void setDeliveryVanPeakMultiplier(double multiplier) {
        if (multiplier >= 1.0) {
            deliveryVanPeakMultiplier = multiplier;
        }
    }

    public static LocalTime getDeliveryVanPeakStart() {
        return deliveryVanPeakStart;
    }

    public static LocalTime getDeliveryVanPeakEnd() {
        return deliveryVanPeakEnd;
    }

    public static boolean isWithinDeliveryVanPeakHours(LocalTime time) {
        if (time == null) {
            return false;
        }
        return !time.isBefore(deliveryVanPeakStart) && time.isBefore(deliveryVanPeakEnd);
    }

    public static double getVisitorOneDayPassFee() {
        return visitorOneDayPassFee;
    }

    public static void setVisitorOneDayPassFee(double fee) {
        if (fee >= 0) {
            visitorOneDayPassFee = fee;
        }
    }

    public static double getStudentMonthlyPassPrice() {
        return studentMonthlyPassPrice;
    }

    public static void setStudentMonthlyPassPrice(double price) {
        if (price >= 0) {
            studentMonthlyPassPrice = price;
        }
    }

    public static double getStaffMonthlyPassPrice() {
        return staffMonthlyPassPrice;
    }

    public static void setStaffMonthlyPassPrice(double price) {
        if (price >= 0) {
            staffMonthlyPassPrice = price;
        }
    }

    public static double getDailyMaxFeeCap() {
        return dailyMaxFeeCap;
    }

    public static void setDailyMaxFeeCap(double cap) {
        if (cap > 0) {
            dailyMaxFeeCap = cap;
        }
    }

    public static boolean isDailyMaxCapEnabled() {
        return dailyMaxCapEnabled;
    }

    public static void setDailyMaxCapEnabled(boolean enabled) {
        dailyMaxCapEnabled = enabled;
    }

    public static void resetDefaults() {
        twoWheelerRatePerHour = 10.0;
        carRatePerHour = 30.0;
        electricCarRatePerHour = 40.0;
        evChargingRatePerKwh = 12.0;
        defaultEvChargingKwh = 7.5;
        ebikeFlatFee = 15.0;
        deliveryVanPeakMultiplier = 2.0;
        deliveryVanPeakStart = LocalTime.of(9, 0);
        deliveryVanPeakEnd = LocalTime.of(17, 0);
        visitorOneDayPassFee = 50.0;
        studentMonthlyPassPrice = 200.0;
        staffMonthlyPassPrice = 300.0;
        dailyMaxFeeCap = 500.0;
        dailyMaxCapEnabled = true;
    }
}
