package assignment_2;


import java.util.*;

public class Q3HashSetDemo {

    static class Student {
        String regNo;
        String name;

        Student(String regNo, String name) {
            this.regNo = regNo;
            this.name = name;
        }

        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof Student))
                return false;

            Student s = (Student) obj;
            return regNo.equals(s.regNo);
        }

        // Correct hashCode implementation
        @Override
        public int hashCode() {
            return Objects.hash(regNo);
        }

        public String toString() {
            return regNo + " " + name;
        }
    }

    public static void main(String[] args) {

        Set<Student> students = new HashSet<>();

        students.add(new Student("192311001", "Arun"));
        students.add(new Student("192311002", "Divya"));
        students.add(new Student("192311001", "Arun"));

        System.out.println("Unique students: " + students.size());

        System.out.println("\nStudent Attendance:");

        for (Student s : students) {
            System.out.println(s);
        }

        System.out.println("\nTesting another duplicate:");

        students.add(new Student("192311002", "Divya"));

        System.out.println("Final attendance count: " + students.size());
    }
}
