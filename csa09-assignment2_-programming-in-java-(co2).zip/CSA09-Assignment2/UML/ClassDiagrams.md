# UML Class Diagrams – CSA09 Assignment 2 (CO2)

## 1. Q3 – Attendance De-duplication (`Student` & `HashSetExperiment`)

```mermaid
classDiagram
    class Student {
        -String regNo
        -String name
        +Student(String regNo, String name)
        +getRegNo() String
        +setRegNo(String regNo) void
        +getName() String
        +setName(String name) void
        +equals(Object obj) boolean
        +hashCode() int
        +toString() String
    }

    class Attendance {
        +main(String[] args)$ void
    }

    class HashSetExperiment {
        +main(String[] args)$ void
    }

    Attendance ..> Student : stores in HashSet
    HashSetExperiment ..> Student : tests hashCode/TreeSet/HashMap
```

---

## 2. Q4 – Hospital Pharmacy Inventory (`Medicine` & `PharmacyInventory`)

```mermaid
classDiagram
    class Medicine {
        -String code
        -String name
        -int quantity
        -double price
        +Medicine(String code, String name, int quantity, double price)
        +getCode() String
        +getName() String
        +getQuantity() int
        +setQuantity(int quantity) void
        +getPrice() double
        +setPrice(double price) void
        +toString() String
    }

    class PharmacyInventory {
        -Map~String, Medicine~ hashInventory
        -Map~String, Medicine~ treeInventory
        -Map~String, Medicine~ linkedInventory
        +addMedicine(Medicine med) void
        +searchByCode(String code) Medicine
        +updateQuantity(String code, int newQuantity) boolean
        +deleteMedicine(String code) boolean
        +displayInCodeOrder() void
        +displayInInsertionOrder() void
        +main(String[] args)$ void
    }

    PharmacyInventory "1" o-- "*" Medicine : indexes by code
```

---

## 3. Q5 – Inter-College Sports Leaderboard (`Team`, `Leaderboard<T>`, `LeaderboardDemo`)

```mermaid
classDiagram
    class Comparable~Team~ {
        <<interface>>
        +compareTo(Team other) int
    }

    class Team {
        -String name
        -int points
        -int goalDifference
        +Team(String name, int points, int goalDifference)
        +getName() String
        +getPoints() int
        +getGoalDifference() int
        +compareTo(Team other) int
        +equals(Object obj) boolean
        +hashCode() int
        +toString() String
    }

    class Leaderboard~T~ {
        -List~T~ entries
        +addEntry(T entry) void
        +addAll(List~? extends T~ newEntries) void
        +sortWith(Comparator~? super T~ comparator) void
        +copyStandingsTo(List~? super T~ destination) void
        +getEntries() List~T~
        +sortNaturally(List~U~ items)$ List~U~
    }

    class LeaderboardDemo {
        +main(String[] args)$ void
    }

    Comparable~Team~ <|.. Team
    Leaderboard~T~ o-- "*" Team : manages T = Team
    LeaderboardDemo ..> Leaderboard~T~ : configures & sorts
```

---

## 4. Q6 – Hospital Emergency Triage (`Patient` & `Triage`)

```mermaid
classDiagram
    class Patient {
        -String name
        -int severity
        -long arrivalSeq
        +Patient(String name, int severity, long arrivalSeq)
        +getName() String
        +getSeverity() int
        +getArrivalSeq() long
        +toString() String
    }

    class Triage {
        +TRIAGE_COMPARATOR$ Comparator~Patient~
        -PriorityQueue~Patient~ queue
        -long nextArrivalSeq
        +admitPatient(String name, int severity) Patient
        +removeNextPatient() Patient
        +formatTreatmentOrder() String
        +displayTreatmentOrder() void
        +main(String[] args)$ void
    }

    Triage "1" o-- "*" Patient : prioritizes via Min-Heap
```

---

## 5. Q7 – Day-4 Design Challenge (`RedesignComparison`)

```mermaid
classDiagram
    class RedesignComparison {
        -int WARMUP_RUNS$
        -int MEASURED_RUNS$
        -buildSingleTicketOriginal(int, int)$ String
        -buildSingleTicketRedesigned(int, int)$ String
        -buildChartOriginal(int)$ String
        -buildChartRedesigned(int)$ String
        -verifyIdenticalOutputs()$ void
        -runBenchmark(String, String, WorkloadRunner)$ List~BenchmarkRow~
        -writeCsv(List~BenchmarkRow~, Path)$ void
        +main(String[] args)$ void
    }
```
