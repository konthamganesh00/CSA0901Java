
package task01;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class DrawPad extends Frame {

    ArrayList<Point> points = new ArrayList<>();
    Label status = new Label("Clicks: 0");

    public DrawPad() {

        super("Draw Pad");

        add(status, BorderLayout.SOUTH);

        addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {

                points.add(e.getPoint());

                status.setText("Clicks: " + points.size());

                repaint();
            }
        });

        addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setSize(400, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void paint(Graphics g) {

        super.paint(g);

        for (Point p : points) {
            g.fillOval(p.x - 3, p.y - 3, 6, 6);
        }
    }

    public static void main(String[] args) {
        new DrawPad();
    }
}
