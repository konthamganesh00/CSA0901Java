
package task01;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Converter4 extends JFrame {

    JTextField amount = new JTextField(10);

    JComboBox<String> target =
        new JComboBox<>(new String[]{"USD", "EUR"});

    JLabel result = new JLabel("Result: ");

    public Converter4() {

        setTitle("Currency Converter - Lambda");
        setLayout(new FlowLayout());

        JButton convertButton = new JButton("Convert");

        add(new JLabel("INR"));
        add(amount);
        add(target);
        add(convertButton);
        add(result);

        ActionListener action = e -> convert();

        convertButton.addActionListener(action);
        amount.addActionListener(action);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setSize(350, 180);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void convert() {

        try {
            double value = Double.parseDouble(amount.getText().trim());

            if (value < 0) {
                throw new NumberFormatException();
            }

            double rate = target.getSelectedItem().equals("USD")
                    ? 0.012 : 0.011;

            double converted = value * rate;

            result.setText(String.format("Result: %.2f", converted));

            JOptionPane.showMessageDialog(this,
                    String.format("Converted Amount: %.2f", converted));

        } catch (NumberFormatException e) {
            result.setText("Invalid amount");

            JOptionPane.showMessageDialog(this,
                    "Invalid amount",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Converter4().setVisible(true));
    }
}
