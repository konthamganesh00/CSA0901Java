
package task01;

import java.awt.*;
import java.awt.event.*;

public class FeeWindow extends Frame {

    TextField regNo = new TextField(15);
    TextField amount = new TextField(15);

    Button pay = new Button("Pay");
    Button clear = new Button("Clear");
    Button receipt = new Button("Receipt");

    String lastReceipt = "No payment completed";

    public FeeWindow() {

        setTitle("Student Fee Payment");
        setLayout(new FlowLayout());

        add(new Label("Register Number:"));
        add(regNo);

        add(new Label("Amount:"));
        add(amount);

        add(pay);
        add(clear);
        add(receipt);

        pay.addActionListener(e -> {
            String r = regNo.getText().trim();
            String a = amount.getText().trim();

            if (r.isEmpty() || a.isEmpty()) {
                showMessage("Please fill all fields");
                return;
            }

            try {
                double fee = Double.parseDouble(a);

                if (fee <= 0) {
                    showMessage("Enter a valid amount");
                    return;
                }

                lastReceipt = "Register Number: " + r
                        + "\nAmount: " + fee
                        + "\nPayment Status: Successful";

                showMessage("Payment Successful");

            } catch (NumberFormatException ex) {
                showMessage("Invalid amount");
            }
        });

        clear.addActionListener(e -> {
            regNo.setText("");
            amount.setText("");
        });

        receipt.addActionListener(e -> {
            showMessage(lastReceipt);
        });

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setSize(400, 250);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    void showMessage(String message) {
        Dialog d = new Dialog(this, "Message", true);
        d.setLayout(new FlowLayout());
        d.add(new Label(message));

        Button ok = new Button("OK");
        ok.addActionListener(e -> d.dispose());

        d.add(ok);
        d.setSize(280, 120);
        d.setLocationRelativeTo(this);
        d.setVisible(true);
    }

    public static void main(String[] args) {
        new FeeWindow();
    }
}
