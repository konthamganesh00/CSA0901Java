# TASK 12 – DAY-4 DESIGN CHALLENGE

## 1. Changed Requirements Summary
1. Add `EBike` with a configurable flat parking fee (`Rs 15.0`).
2. Add `DeliveryVan` charged at double the `Car` rate (`Rs 60.0/hr`) between 09:00 AM and 05:00 PM (17:00), and standard `Car` rate (`Rs 30.0/hr`) outside that window.
3. Add Visitor `OneDayPass` with configured flat one-day pricing (`Rs 50.0`).
4. Extend parking facility from 1–3 floors to **5 floors**.
5. Support **different slot capacities on each floor** (default `{10, 15, 20, 25, 30}` = 100 slots).

## 2. Impact Analysis

| Existing Component | Impact Level | Nature of Change |
|---|---|---|
| `Vehicle`, `TwoWheeler`, `Car` | Zero modification | Abstract hierarchy already supports new subclasses cleanly |
| `EBike`, `DeliveryVan` | **New Subclasses** | Added `EBike extends TwoWheeler` and `DeliveryVan extends Car` |
| `ParkingPass`, `MonthlyPass` | Zero modification | Abstract `ParkingPass` already models date-bounded `applyToParkingFee()` |
| `OneDayPass` | **New Subclass** | Added `OneDayPass extends ParkingPass` with 1-day validity window |
| `PricingConfig` | **Extended** | Added `ebikeFlatFee`, `deliveryVanPeakMultiplier`, peak window, `visitorOneDayPassFee` |
| `FeeCalculator` | **Modified (Localized)** | Added `DeliveryVan` timestamp-aware check and `OneDayPass` branch |
| `ParkingFacility` | **Zero Structural Rewrite** | Already backed by jagged `ParkingSlot[][]`; only default constructor changed to `new int[]{10, 15, 20, 25, 30}` |
| `Main` | **Extended** | Added menu options for `EBike`, `DeliveryVan`, `OneDayPass`, and 5-floor display/presets |

## 3. Original Design Evaluation & Verdict: **RETAINED & EXTENDED**
**Decision**: The original architecture is **RETAINED and EXTENDED** (with localized modifications to `PricingConfig`, `FeeCalculator`, and `Main`), rather than redesigned from scratch.

### Evidence-Based Defence of the Final Design
1. **Open/Closed Principle (OCP) Proven in Practice**: Because `Vehicle` and `ParkingPass` were designed as abstractions and `ParkingFacility` used a jagged 2D array (`ParkingSlot[][]`) from Day 1, supporting 5 floors with unequal capacities (`{10, 15, 20, 25, 30}`) required **zero** algorithmic changes to `allocateFirstAvailableSlot()` or `releaseSlot()`.
2. **Polymorphic Vehicle Extension**: Adding `EBike` and `DeliveryVan` did not break `TwoWheeler`, `Car`, or `ElectricCar`. Every existing service (`TicketService`, `ReportService`, `ParkingSlot`) operates on the `Vehicle` abstraction and worked immediately with the new types.
3. **Why Not a Full Redesign?**: A full rewrite (e.g., switching to a relational database or a Strategy-based composition graph) would add unnecessary complexity and break existing assignment contracts (`FeeDemo`, `ParkingFacility`) without adding functional value for a 5-floor campus console system.
4. **Controlled Modification**: Centralising pricing inside `PricingConfig` and time-window logic inside `DeliveryVan` + `FeeCalculator` avoided scattering magic numbers (`2 * 30`, `15`, `50`) across UI or slot classes.

## 4. Updated UML Class Structure (Day-4)
```text
                   <<abstract>> Vehicle
                  /                    \
            TwoWheeler                 Car
                |                   /       \
              EBike         ElectricCar    DeliveryVan
                                |
                          <<implements>>
                            Chargeable

                   <<abstract>> ParkingPass
                  /                        \
            MonthlyPass                 OneDayPass
        (Student / Staff)            (Visitor One-Day)

       ParkingFacility  --->  ParkingSlot[5][] (Jagged: 10, 15, 20, 25, 30)
```
