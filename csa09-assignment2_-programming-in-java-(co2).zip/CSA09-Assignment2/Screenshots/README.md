# Screenshots Directory

Place genuine execution screenshots captured from your Eclipse Console (or terminal) in this folder before final submission.

## Recommended Screenshot Checklist

1. `Q1_StringBenchmark_Console.png` — Console output showing short ticket comparison, 10,000 tickets (50 fields each), consolidated chart workload, and `Q1_StringBenchmark.csv` generation.
2. `Q2_PlaylistBenchmark_Console.png` — Console output comparing `ArrayList`, `LinkedList`, and `ArrayDeque` across 1,000 / 10,000 / 50,000 songs.
3. `Q3_Attendance_Console.png` — Console output of `Attendance.java` showing `Unique students: 2` and `HashSetExperiment.java`.
4. `Q4_PharmacyInventory_Console.png` — Console output of `PharmacyInventory.java` (code order & insertion order) and `MapBenchmark.java`.
5. `Q5_LeaderboardDemo_Console.png` — Console output of `LeaderboardDemo.java` showing `[Eagles(9,6), Bisons(9,4), Panthers(9,4), Cobras(6,1)]` and extended tie tests.
6. `Q6_Triage_Console.png` — Console output of `Triage.java` showing `Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)` and `TriageBenchmark.java`.
7. `Q7_RedesignComparison_Console.png` — Console output of `RedesignComparison.java` showing speedup and CSV generation.
8. `Eclipse_Project_Explorer.png` — Eclipse Package Explorer showing all `Q1`–`Q7` packages compiling cleanly with zero errors.
