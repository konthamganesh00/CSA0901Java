
package taskB3;

import java.sql.*;

public class BatchTest {

    static String url = "jdbc:mysql://localhost:3306/assignment5";
    static String user = "root";
    static String password = "12345";

    static Connection con;

    // Clear table before each test
    static void clearTable() throws SQLException {
        Statement st = con.createStatement();
        st.executeUpdate("DELETE FROM bus_pass");
        st.close();
    }

    // Generate and insert using Statement
    static long testStatement(int size) throws SQLException {

        clearTable();

        long start = System.nanoTime();

        Statement st = con.createStatement();

        for (int i = 1; i <= size; i++) {

            String sql = "INSERT INTO bus_pass VALUES (" +
                    "'P" + i + "'," +
                    "'REG" + i + "'," +
                    "'Student" + i + "'," +
                    (i % 10 + 1) + "," +
                    (3000 + i) + ")";

            st.executeUpdate(sql);
        }

        st.close();

        return (System.nanoTime() - start) / 1000000;
    }

    // Insert using PreparedStatement
    static long testPrepared(int size) throws SQLException {

        clearTable();

        long start = System.nanoTime();

        String sql = "INSERT INTO bus_pass VALUES (?, ?, ?, ?, ?)";

        PreparedStatement ps = con.prepareStatement(sql);

        for (int i = 1; i <= size; i++) {

            ps.setString(1, "P" + i);
            ps.setString(2, "REG" + i);
            ps.setString(3, "Student" + i);
            ps.setInt(4, i % 10 + 1);
            ps.setDouble(5, 3000 + i);

            ps.executeUpdate();
        }

        ps.close();

        return (System.nanoTime() - start) / 1000000;
    }

    // Insert using Batch
    static long testBatch(int size) throws SQLException {

        clearTable();

        long start = System.nanoTime();

        String sql = "INSERT INTO bus_pass VALUES (?, ?, ?, ?, ?)";

        con.setAutoCommit(false);

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            for (int i = 1; i <= size; i++) {

                ps.setString(1, "P" + i);
                ps.setString(2, "REG" + i);
                ps.setString(3, "Student" + i);
                ps.setInt(4, i % 10 + 1);
                ps.setDouble(5, 3000 + i);

                ps.addBatch();

                if (i % 1000 == 0) {
                    ps.executeBatch();
                    ps.clearBatch();
                }
            }

            ps.executeBatch();
            con.commit();

        } catch (SQLException e) {

            con.rollback();
            throw e;

        } finally {

            con.setAutoCommit(true);
        }

        return (System.nanoTime() - start) / 1000000;
    }

    // Verify table using ResultSetMetaData
    static void showMetadata() throws SQLException {

        Statement st = con.createStatement();

        ResultSet rs = st.executeQuery("SELECT * FROM bus_pass");

        ResultSetMetaData md = rs.getMetaData();

        System.out.println("\nTable Column Information:");

        for (int i = 1; i <= md.getColumnCount(); i++) {

            System.out.println(
                    md.getColumnName(i) + " : "
                    + md.getColumnTypeName(i));
        }

        rs.close();
        st.close();
    }

    public static void main(String[] args) {

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(url, user, password);

            System.out.println("Database Connected Successfully!");

            showMetadata();

            int[] sizes = {10, 1000, 10000, 100000};

            for (int size : sizes) {

                System.out.println("\nRecords: " + size);

                long t1 = testStatement(size);
                System.out.println("Statement: " + t1 + " ms");

                long t2 = testPrepared(size);
                System.out.println("PreparedStatement: " + t2 + " ms");

                long t3 = testBatch(size);
                System.out.println("Batch: " + t3 + " ms");

            }

            con.close();

            System.out.println("\nB3 Testing Completed!");

        } catch (Exception e) {

            System.out.println("Database Error: " + e.getMessage());
        }
    }
}

