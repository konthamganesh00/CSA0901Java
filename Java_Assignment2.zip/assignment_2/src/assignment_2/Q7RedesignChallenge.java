package assignment_2;


import java.util.*;

public class Q7RedesignChallenge {

    static void compare(int size) {

        ArrayList<Integer> original = new ArrayList<>();
        ArrayDeque<Integer> redesigned = new ArrayDeque<>();

        for (int i = 0; i < size; i++) {
            original.add(i);
            redesigned.addLast(i);
        }

        long start = System.nanoTime();

        long sum1 = 0;

        while (!original.isEmpty()) {
            sum1 += original.remove(0);
        }

        long end = System.nanoTime();

        double arrayListTime = (end - start) / 1000000.0;

        start = System.nanoTime();

        long sum2 = 0;

        while (!redesigned.isEmpty()) {
            sum2 += redesigned.removeFirst();
        }

        end = System.nanoTime();

        double dequeTime = (end - start) / 1000000.0;

        System.out.println("\nPlaylist Size: " + size);

        System.out.println("ArrayList Time: "
                + arrayListTime + " ms");

        System.out.println("ArrayDeque Time: "
                + dequeTime + " ms");

        System.out.println("ArrayList Result: " + sum1);
        System.out.println("ArrayDeque Result: " + sum2);
    }

    public static void main(String[] args) {

        System.out.println("REDESIGN PERFORMANCE COMPARISON");

        compare(10000);
        compare(50000);
        compare(100000);
    }
}
