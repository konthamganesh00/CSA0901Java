
package taskA5;

import java.sql.*;

public class TransactionDemo {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/assignment5";
        String user = "root";
        String password = "12345";

        try {

            // Load MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to MySQL
            Connection con = DriverManager.getConnection(
                    url, user, password);

            System.out.println("Database Connected Successfully!");

            // Start transaction
            con.setAutoCommit(false);

            try {

                // Deduct Rs.500 from hostel wallet
                String sql1 =
                    "UPDATE wallet SET balance = balance - 500 WHERE id = 1";

                PreparedStatement ps1 = con.prepareStatement(sql1);

                int result1 = ps1.executeUpdate();

                // Add Rs.500 to canteen wallet
                String sql2 =
                    "UPDATE wallet SET balance = balance + 500 WHERE id = 2";

                PreparedStatement ps2 = con.prepareStatement(sql2);

                int result2 = ps2.executeUpdate();

                if (result1 != 1 || result2 != 1) {
                    throw new SQLException("Wallet record not found");
                }

                // Commit transaction
                con.commit();

                System.out.println("Transaction Successful!");
                System.out.println("Rs.500 transferred successfully.");

                ps1.close();
                ps2.close();

            } catch (SQLException e) {

                // Rollback transaction
                con.rollback();

                System.out.println("Transaction Failed!");
                System.out.println("Changes rolled back.");
                System.out.println(e.getMessage());
            }

            con.close();

        } catch (Exception e) {

            System.out.println("Database Error: " + e.getMessage());
        }
    }
}
