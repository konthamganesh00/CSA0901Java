package Q4;

import java.io.IOException;

/**
 * Q4 - Main Demonstration Driver
 * Demonstrates Hospital Pharmacy Inventory CRUD across HashMap, TreeMap, and LinkedHashMap,
 * verifies normal/boundary/invalid-input cases, and runs MapBenchmark.
 */
public class Main {

    private static void verify(boolean condition, String testName) {
        if (!condition) {
            throw new AssertionError("Test failed: " + testName);
        }
        System.out.println("[PASS] " + testName);
    }

    private static void runInventoryTests() {
        System.out.println("\n--- Q4 Normal, Boundary & Invalid Input Tests ---");

        PharmacyInventory emptyInv = new PharmacyInventory();
        // 1. Boundary test: empty inventory and missing keys
        verify(emptyInv.size() == 0, "Empty inventory starts at size 0");
        verify(emptyInv.searchByCode("MED999") == null, "Search missing key returns null");
        verify(!emptyInv.updateQuantity("MED999", 10), "Update missing key returns false");
        verify(!emptyInv.deleteMedicine("MED999"), "Delete missing key returns false");

        // 2. Boundary test: zero stock quantity and duplicate medicine code replacement
        emptyInv.addMedicine(new Medicine("MED101", "Paracetamol 500mg", 0, 18.00));
        verify(emptyInv.searchByCode("MED101").getQuantity() == 0, "Zero-stock boundary allowed");
        emptyInv.addMedicine(new Medicine("MED101", "Paracetamol 500mg", 250, 18.00));
        verify(emptyInv.size() == 1 && emptyInv.searchByCode("MED101").getQuantity() == 250,
                "Duplicate code overwrites existing entry without increasing size");

        // 3. Invalid input tests
        try {
            new Medicine("MED000", "Invalid", -5, 10.0);
            verify(false, "Negative quantity should throw IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            System.out.println("[PASS] Negative quantity rejected cleanly: " + ex.getMessage());
        }

        try {
            emptyInv.addMedicine(null);
            verify(false, "Null medicine should throw IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            System.out.println("[PASS] Null medicine rejected cleanly: " + ex.getMessage());
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println("==========================================================================");
        System.out.println("Q4 DEMONSTRATION: HASHMAP, TREEMAP AND LINKEDHASHMAP");
        System.out.println("Problem: Hospital Pharmacy Inventory");
        System.out.println("==========================================================================");

        System.out.println("Sample Inputs:");
        System.out.println("  MED305 (Amoxicillin), MED101 (Paracetamol), MED412 (Insulin), MED204 (Cetirizine), MED150 (Azithromycin)");

        PharmacyInventory.main(args);
        runInventoryTests();

        System.out.println("\n--- Executing Full Q4 Benchmark & CSV Export ---");
        MapBenchmark.main(args);
    }
}
