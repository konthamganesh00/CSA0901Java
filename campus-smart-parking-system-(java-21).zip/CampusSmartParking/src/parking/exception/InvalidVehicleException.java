package parking.exception;

/**
 * Thrown when vehicle registration details or vehicle state fail validation.
 */
public class InvalidVehicleException extends ParkingException {

    private static final long serialVersionUID = 1L;

    public InvalidVehicleException(String message) {
        super(message);
    }
}
