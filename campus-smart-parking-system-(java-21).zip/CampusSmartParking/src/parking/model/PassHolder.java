package parking.model;

/**
 * Contract for campus users eligible to hold a parking pass.
 */
public interface PassHolder {

    String getUserId();

    String getName();

    ParkingPass getParkingPass();

    void assignParkingPass(ParkingPass pass);

    default boolean hasValidPass() {
        ParkingPass pass = getParkingPass();
        return pass != null && pass.isValid();
    }
}
