package parking.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Represents a campus parking user (Student, Staff, or Visitor) implementing PassHolder.
 */
public class ParkingUser implements PassHolder {

    public enum UserRole {
        STUDENT,
        STAFF,
        VISITOR
    }

    private final String userId;
    private String name;
    private String phone;
    private UserRole role;
    private final List<Vehicle> registeredVehicles;
    private ParkingPass parkingPass;

    public ParkingUser(String userId, String name, String phone, UserRole role) {
        this.userId = (userId == null || userId.isBlank()) ? "USR-000" : userId.trim().toUpperCase();
        this.name = (name == null || name.isBlank()) ? "Campus User" : name.trim();
        this.phone = (phone == null || phone.isBlank()) ? "N/A" : phone.trim();
        this.role = (role == null) ? UserRole.VISITOR : role;
        this.registeredVehicles = new ArrayList<>();
    }

    @Override
    public String getUserId() {
        return userId;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null && !name.isBlank()) {
            this.name = name.trim();
        }
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        if (phone != null && !phone.isBlank()) {
            this.phone = phone.trim();
        }
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        if (role != null) {
            this.role = role;
        }
    }

    public void addVehicle(Vehicle vehicle) {
        if (vehicle != null && !registeredVehicles.contains(vehicle)) {
            registeredVehicles.add(vehicle);
        }
    }

    public List<Vehicle> getRegisteredVehicles() {
        return Collections.unmodifiableList(registeredVehicles);
    }

    @Override
    public ParkingPass getParkingPass() {
        return parkingPass;
    }

    @Override
    public void assignParkingPass(ParkingPass pass) {
        this.parkingPass = pass;
    }

    @Override
    public String toString() {
        return String.format("ParkingUser [ID=%s, Name=%s, Role=%s, Vehicles=%d, ActivePass=%s]",
                userId, name, role, registeredVehicles.size(), hasValidPass() ? parkingPass.getPassId() : "None");
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ParkingUser other)) {
            return false;
        }
        return Objects.equals(userId, other.userId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId);
    }
}
