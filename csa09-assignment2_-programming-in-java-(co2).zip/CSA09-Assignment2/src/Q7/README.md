# Q7 – Day-4 Design Challenge (Performance Redesign)

## Short Explanation
This folder addresses the quadratic `String (+)` concatenation bottleneck observed in Q1 and redesigns ticket/chart generation using a **capacity-tuned `StringBuilder`**.

See **`DesignChallenge.md`** in this folder for the complete six-part engineering analysis (Sections A through F).

---

## How to Run
- **Complete Demo + Tests + A/B Comparison:** Run `Q7.Main`
- **A/B Comparison Benchmark Only:** Run `Q7.RedesignComparison`

---

## Sample Input & Expected Output

### Sample Input
- `Batch_1000x50` (1,000 tickets × 50 fields)
- `Batch_10000x50` (10,000 tickets × 50 fields)
- `Chart_3000Entries` (3,000-entry consolidated reservation chart)

### Expected Output Format
```text
[PASS] Original and redesigned 50-field ticket outputs match
[PASS] Boundary test: 1-field ticket matches
[PASS] Boundary test: 0-entry reservation chart matches header-only output
[PASS] Invalid fieldCount caught cleanly: ticketIndex must be >= 0 and fieldCount >= 1.
[PASS] Negative entryCount caught cleanly: entryCount cannot be negative: -1
Output equivalence check passed: Original.equals(Redesigned) == true
...
Saved raw comparison measurements to: .../ExperimentalData/Q7_RedesignBenchmark.csv
```

---

## Test Documentation
1. **Equivalence Assertion:** Verifies `Original.equals(Redesigned) == true` on tickets and charts.
2. **Boundary Tests:** 1-field minimal ticket (`PNR=4100000000`) and 0-entry empty chart.
3. **Invalid Input Tests:** `fieldCount == 0` and `entryCount == -1` throw `IllegalArgumentException`.
4. **A/B Benchmark:** 3 warmup + 5 measured runs per workload using `System.nanoTime()`, writing real results to `ExperimentalData/Q7_RedesignBenchmark.csv`.
