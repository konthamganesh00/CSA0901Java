package assignment_2;


import java.util.*;

class Team {

    String name;
    int points;
    int goalDiff;

    Team(String name, int points, int goalDiff) {
        this.name = name;
        this.points = points;
        this.goalDiff = goalDiff;
    }

    public String toString() {
        return name + "(" + points + "," + goalDiff + ")";
    }
}

class Leaderboard<T> {

    private List<T> items = new ArrayList<>();
    private Comparator<? super T> order;

    Leaderboard(Comparator<? super T> order) {
        this.order = order;
    }

    void add(T item) {
        items.add(item);
    }

    List<T> ranking() {
        List<T> result = new ArrayList<>(items);
        result.sort(order);
        return result;
    }
}

public class Q5LeaderboardDemo {

    public static void main(String[] args) {

        Comparator<Team> byRank =
            Comparator.comparingInt((Team t) -> t.points)
            .reversed()
            .thenComparing(
                Comparator.comparingInt((Team t) -> t.goalDiff)
                .reversed()
            )
            .thenComparing(t -> t.name);

        Leaderboard<Team> board =
            new Leaderboard<>(byRank);

        board.add(new Team("Panthers", 9, 4));
        board.add(new Team("Eagles", 9, 6));
        board.add(new Team("Cobras", 6, 1));
        board.add(new Team("Bisons", 9, 4));

        System.out.println("SPORTS LEADERBOARD");

        for (Team t : board.ranking()) {
            System.out.println(t);
        }
    }
}
