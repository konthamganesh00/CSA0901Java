
package task01;

import java.awt.*;
import javax.swing.*;

public class LibrarySearch extends JFrame {

    JTextField searchField = new JTextField(15);

    JComboBox<String> category = new JComboBox<>(
        new String[]{"All", "Books", "Authors", "Subjects"}
    );

    JTextArea results = new JTextArea();

    JLabel status = new JLabel("Ready");

    JButton search = new JButton("Search");
    JButton prev = new JButton("Prev");
    JButton next = new JButton("Next");
    JButton reserve = new JButton("Reserve");

    public LibrarySearch() {

        setTitle("Campus Library Search");
        setLayout(new BorderLayout(10, 10));

        JPanel top = new JPanel(new BorderLayout());

        JLabel title = new JLabel(
            "CAMPUS LIBRARY SEARCH", JLabel.CENTER);

        title.setFont(new Font("Arial", Font.BOLD, 20));

        top.add(title, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new FlowLayout());

        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(category);
        searchPanel.add(search);

        top.add(searchPanel, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);

        results.setText("Search results will appear here.");
        results.setEditable(false);

        add(new JScrollPane(results), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout());

        JPanel buttons = new JPanel(new FlowLayout());

        buttons.add(prev);
        buttons.add(next);
        buttons.add(reserve);

        bottom.add(buttons, BorderLayout.CENTER);
        bottom.add(status, BorderLayout.SOUTH);

        add(bottom, BorderLayout.SOUTH);

        search.addActionListener(e -> {

            String text = searchField.getText().trim();

            if (text.isEmpty()) {
                status.setText("Enter a search keyword");
            } else {
                results.setText(
                    "Search Results:\n\n" +
                    "1. Java Programming\n" +
                    "2. Data Structures\n" +
                    "3. Database Management Systems"
                );

                status.setText("Search completed");
            }
        });

        prev.addActionListener(e ->
            status.setText("Previous page selected"));

        next.addActionListener(e ->
            status.setText("Next page selected"));

        reserve.addActionListener(e ->
            status.setText("Book reserved successfully"));

        setSize(650, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LibrarySearch());
    }
}
