package parking.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/**
 * Represents a unique parking ticket issued upon vehicle entry and settled on exit.
 * Demonstrates static counter, static initializer block, and static utility methods.
 */
public class ParkingTicket {

    private static int ticketCounter;
    private static final String TICKET_PREFIX;
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    static {
        ticketCounter = 1000;
        TICKET_PREFIX = "TKT";
    }

    private final String ticketId;
    private final Vehicle vehicle;
    private final int floorIndex; // 0-based index
    private final int slotIndex;  // 0-based index
    private final String slotCode;
    private final LocalDateTime entryTime;

    private LocalDateTime exitTime;
    private int billedHours;
    private double baseParkingFee;
    private double chargingFee;
    private double totalFee;
    private String passAppliedDescription;
    private boolean settled;

    public ParkingTicket(Vehicle vehicle, int floorIndex, int slotIndex, String slotCode) {
        this(vehicle, floorIndex, slotIndex, slotCode, LocalDateTime.now());
    }

    public ParkingTicket(Vehicle vehicle, int floorIndex, int slotIndex, String slotCode, LocalDateTime entryTime) {
        this.ticketId = generateNextTicketId();
        this.vehicle = vehicle;
        this.floorIndex = floorIndex;
        this.slotIndex = slotIndex;
        this.slotCode = slotCode;
        this.entryTime = (entryTime == null) ? LocalDateTime.now() : entryTime;
        this.passAppliedDescription = "None";
        this.settled = false;
    }

    public static synchronized String generateNextTicketId() {
        ticketCounter++;
        return TICKET_PREFIX + "-" + ticketCounter;
    }

    public static int getTotalTicketsIssued() {
        return ticketCounter - 1000;
    }

    public static void resetCounterForTesting() {
        ticketCounter = 1000;
    }

    public void settleTicket(LocalDateTime exitTime, int billedHours, double baseParkingFee,
                             double chargingFee, double totalFee, String passAppliedDescription) {
        this.exitTime = exitTime;
        this.billedHours = billedHours;
        this.baseParkingFee = baseParkingFee;
        this.chargingFee = chargingFee;
        this.totalFee = totalFee;
        this.passAppliedDescription = (passAppliedDescription == null) ? "None" : passAppliedDescription;
        this.settled = true;
    }

    public String getTicketId() {
        return ticketId;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public int getFloorIndex() {
        return floorIndex;
    }

    public int getSlotIndex() {
        return slotIndex;
    }

    public String getSlotCode() {
        return slotCode;
    }

    public LocalDateTime getEntryTime() {
        return entryTime;
    }

    public LocalDateTime getExitTime() {
        return exitTime;
    }

    public int getBilledHours() {
        return billedHours;
    }

    public double getBaseParkingFee() {
        return baseParkingFee;
    }

    public double getChargingFee() {
        return chargingFee;
    }

    public double getTotalFee() {
        return totalFee;
    }

    public String getPassAppliedDescription() {
        return passAppliedDescription;
    }

    public boolean isSettled() {
        return settled;
    }

    @Override
    public String toString() {
        String entryStr = entryTime.format(TIME_FORMATTER);
        if (!settled) {
            return String.format("Ticket [%s | Vehicle=%s (%s) | Slot=%s | Entry=%s | Status=ACTIVE]",
                    ticketId, vehicle.getRegistrationNumber(),
                    vehicle.getVehicleType().getDisplayName(), slotCode, entryStr);
        }
        String exitStr = exitTime != null ? exitTime.format(TIME_FORMATTER) : "N/A";
        return String.format(
                "Ticket [%s | Vehicle=%s (%s) | Slot=%s | Entry=%s | Exit=%s | Hours=%d | ParkFee=Rs %.2f | ChargeFee=Rs %.2f | Total=Rs %.2f | Pass=%s | Status=SETTLED]",
                ticketId, vehicle.getRegistrationNumber(), vehicle.getVehicleType().getDisplayName(),
                slotCode, entryStr, exitStr, billedHours, baseParkingFee, chargingFee, totalFee, passAppliedDescription);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ParkingTicket other)) {
            return false;
        }
        return Objects.equals(ticketId, other.ticketId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ticketId);
    }
}
