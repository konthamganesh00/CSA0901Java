package parking.exception;

/**
 * Thrown when a parking pass is expired, revoked, mismatched, or invalid.
 */
public class InvalidPassException extends ParkingException {

    private static final long serialVersionUID = 1L;

    public InvalidPassException(String message) {
        super(message);
    }
}
