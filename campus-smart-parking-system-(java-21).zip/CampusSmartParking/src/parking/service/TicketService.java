package parking.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import parking.exception.TicketNotFoundException;
import parking.model.ParkingTicket;
import parking.model.Vehicle;

/**
 * Manages parking ticket generation, active ticket lookup via HashMap (O(1)),
 * and chronological ticket history via ArrayList.
 */
public class TicketService {

    private final Map<String, ParkingTicket> allTicketsById = new HashMap<>();
    private final Map<String, ParkingTicket> activeTicketsByRegNo = new HashMap<>();
    private final List<ParkingTicket> ticketHistory = new ArrayList<>();

    public ParkingTicket createTicket(Vehicle vehicle, int floorIndex, int slotIndex,
                                      String slotCode, LocalDateTime entryTime) {
        ParkingTicket ticket = new ParkingTicket(vehicle, floorIndex, slotIndex, slotCode, entryTime);
        allTicketsById.put(ticket.getTicketId().toUpperCase(), ticket);
        activeTicketsByRegNo.put(vehicle.getRegistrationNumber().toUpperCase(), ticket);
        ticketHistory.add(ticket);
        return ticket;
    }

    public ParkingTicket findTicketById(String ticketId) throws TicketNotFoundException {
        if (ticketId == null || ticketId.isBlank()) {
            throw new TicketNotFoundException("Ticket ID cannot be empty.");
        }
        ParkingTicket ticket = allTicketsById.get(ticketId.trim().toUpperCase());
        if (ticket == null) {
            throw new TicketNotFoundException("No ticket found with ID: " + ticketId);
        }
        return ticket;
    }

    public ParkingTicket findActiveTicketByRegNo(String regNo) throws TicketNotFoundException {
        if (regNo == null || regNo.isBlank()) {
            throw new TicketNotFoundException("Registration number cannot be empty.");
        }
        String normalized = regNo.trim().toUpperCase().replaceAll("\\s+", "");
        ParkingTicket ticket = activeTicketsByRegNo.get(normalized);
        if (ticket == null) {
            throw new TicketNotFoundException("No active parking ticket found for vehicle: " + normalized);
        }
        return ticket;
    }

    public boolean hasActiveTicket(String regNo) {
        if (regNo == null) {
            return false;
        }
        String normalized = regNo.trim().toUpperCase().replaceAll("\\s+", "");
        return activeTicketsByRegNo.containsKey(normalized);
    }

    public void markTicketSettled(ParkingTicket ticket) {
        if (ticket != null) {
            activeTicketsByRegNo.remove(ticket.getVehicle().getRegistrationNumber().toUpperCase());
        }
    }

    public List<ParkingTicket> getActiveTickets() {
        return new ArrayList<>(activeTicketsByRegNo.values());
    }

    public List<ParkingTicket> getSettledTickets() {
        List<ParkingTicket> settled = new ArrayList<>();
        for (ParkingTicket ticket : ticketHistory) {
            if (ticket.isSettled()) {
                settled.add(ticket);
            }
        }
        return settled;
    }

    public List<ParkingTicket> getAllTickets() {
        return Collections.unmodifiableList(ticketHistory);
    }
}
