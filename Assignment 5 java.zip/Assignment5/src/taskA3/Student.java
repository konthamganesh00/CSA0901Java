
package taskA3;

public class Student {

    int id;
    String name;
    String course;
    double marks;

    public Student(int id, String name, String course, double marks) {
        this.id = id;
        this.name = name;
        this.course = course;
        this.marks = marks;
    }

    public int getId() {
        return id;
    }

    public String toString() {
        return "ID: " + id
                + ", Name: " + name
                + ", Course: " + course
                + ", Marks: " + marks;
    }
}
