package assignment_2;


public class Q1StringBenchmark {

    static String usingString(int tickets, int fields) {
        String result = "";

        for (int i = 0; i < tickets; i++) {
            String ticket = "";
            for (int j = 0; j < fields; j++) {
                ticket = ticket + "Field" + j + " ";
            }
            result = ticket;
        }
        return result;
    }

    static String usingStringBuilder(int tickets, int fields) {
        String result = "";

        for (int i = 0; i < tickets; i++) {
            StringBuilder sb = new StringBuilder();

            for (int j = 0; j < fields; j++) {
                sb.append("Field").append(j).append(" ");
            }
            result = sb.toString();
        }
        return result;
    }

    static String usingStringBuffer(int tickets, int fields) {
        String result = "";

        for (int i = 0; i < tickets; i++) {
            StringBuffer sb = new StringBuffer();

            for (int j = 0; j < fields; j++) {
                sb.append("Field").append(j).append(" ");
            }
            result = sb.toString();
        }
        return result;
    }

    static void test(String name, Runnable task) {
        long start = System.nanoTime();
        task.run();
        long end = System.nanoTime();

        System.out.println(name + " : "
                + (end - start) / 1000000.0 + " ms");
    }

    public static void main(String[] args) {

        int tickets = 10000;
        int fields = 50;

        System.out.println("RAILWAY TICKET BENCHMARK");
        System.out.println("Tickets: " + tickets);
        System.out.println("Fields: " + fields);

        test("String", () -> usingString(tickets, fields));
        test("StringBuilder", () -> usingStringBuilder(tickets, fields));
        test("StringBuffer", () -> usingStringBuffer(tickets, fields));
    }
}
