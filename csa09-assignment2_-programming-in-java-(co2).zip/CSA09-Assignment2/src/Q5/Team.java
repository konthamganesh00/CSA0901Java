package Q5;

import java.util.Objects;

/**
 * Q5 - Team Model for Inter-College Sports Leaderboard.
 * Implements Comparable<Team> for natural ranking order:
 *   1. Higher points first
 *   2. Higher goal difference first
 *   3. Alphabetical team name order
 */
public class Team implements Comparable<Team> {

    private final String name;
    private final int points;
    private final int goalDifference;

    public Team(String name, int points, int goalDifference) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Team name cannot be null or blank.");
        }
        this.name = name;
        this.points = points;
        this.goalDifference = goalDifference;
    }

    public String getName() {
        return name;
    }

    public int getPoints() {
        return points;
    }

    public int getGoalDifference() {
        return goalDifference;
    }

    @Override
    public int compareTo(Team other) {
        int cmp = Integer.compare(other.points, this.points);
        if (cmp != 0) {
            return cmp;
        }
        cmp = Integer.compare(other.goalDifference, this.goalDifference);
        if (cmp != 0) {
            return cmp;
        }
        return this.name.compareTo(other.name);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Team other)) return false;
        return points == other.points
                && goalDifference == other.goalDifference
                && Objects.equals(name, other.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, points, goalDifference);
    }

    @Override
    public String toString() {
        return name + "(" + points + "," + goalDifference + ")";
    }
}
