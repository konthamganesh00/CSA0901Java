# Q1 – String, StringBuilder, and StringBuffer (Railway E-Ticket Generation)

## Short Explanation
In Java, `String` is **immutable**: its internal byte array (`private final byte[] value` in Java 9+ Compact Strings) cannot be modified after creation. Every `+` concatenation inside a loop creates a new intermediate `String` object and copies all characters accumulated so far, leading to **$O(k^2)$** time complexity and **$O(k^2)$** total temporary allocation for $k$ loop appends.

- **`StringBuilder`** uses a resizable mutable `byte[]` buffer with amortized **$O(1)$** per `append()` and **$O(k)$** total time/space. It is **not synchronized**, making it the fastest choice for single-threaded ticket generation.
- **`StringBuffer`** provides the same mutable API, but its methods are `synchronized`, making it **thread-safe** for shared logs or multi-threaded append scenarios at a slight synchronization cost.
- **`String.join()`**, **`StringJoiner`**, and **`String.format()`** are readable high-level alternatives for delimited records and formatted output (`StringJoiner` internally uses `StringBuilder`).

### Recommendation
- **Individual E-Tickets (single-threaded / per-request):** Use `StringBuilder` (or `String.join()` / `StringJoiner` for delimited fields).
- **Shared Reservation Logs (concurrent threads writing to the same buffer):** Use `StringBuffer` (or thread-local `StringBuilder` / concurrent logging queues).

---

## Complexity Summary

| Approach | Loop Append ($k$ appends) Time | Final Space | Temp Intermediate Allocations | Thread-Safe |
|---|---|---|---|---|
| `String (+)` | $O(k^2)$ | $O(n)$ | $O(k^2)$ chars across $k$ objects | Yes (immutable) |
| `StringBuilder` | $O(k)$ amortized | $O(n)$ | $O(n)$ (occasional array doubling) | No |
| `StringBuffer` | $O(k)$ amortized | $O(n)$ | $O(n)$ (occasional array doubling) | Yes (`synchronized`) |

---

## How to Run
- **User-Friendly Demo + Tests + Benchmark:** Run `Q1.Main`
- **Benchmark Only:** Run `Q1.StringBenchmark`

---

## Sample Input & Expected Output

### Sample Input
- Short Ticket: `PNR=4123456789`, `Name=Aarav Sharma`, `Coach=B2`, `Berth=LB-12`, `Fare=1450.00`, `Train=12609`, `Route=MAS-SBC`, `Date=2026-11-20`
- Heavy Batch: `10,000` tickets × `50` fields each
- Additional Workload: `3,000`-entry Consolidated Reservation Chart

### Expected Output Format
```text
[PASS] Normal ticket equivalence across String, StringBuilder, StringBuffer
[PASS] Boundary test with zero fare and empty coach/berth
[PASS] Invalid input caught cleanly: PNR must not be null or blank.
Sample Short Ticket: PNR:4123456789|Passenger:Aarav Sharma|Train:12609|Route:MAS-SBC|Date:2026-11-20|Coach:B2|Berth:LB-12|Fare:INR 1450.00
All 3 implementations produce identical output: true
...
Saved raw benchmark measurements to: .../ExperimentalData/Q1_StringBenchmark.csv
```

---

## Test Documentation
- **Normal Test:** Verified `t1.equals(t2) && t2.equals(t3)` across `String (+)`, `StringBuilder`, and `StringBuffer`.
- **Boundary Test:** Verified zero fare (`0.00`) and empty coach/berth strings build cleanly.
- **Invalid Input Test:** Verified `validateTicketInputs(null, "Aarav", -100.0)` throws `IllegalArgumentException`.
- **Benchmark Protocol:** 3 warmup iterations + 5 measured iterations per workload using `System.nanoTime()`, writing real results to `ExperimentalData/Q1_StringBenchmark.csv`.
