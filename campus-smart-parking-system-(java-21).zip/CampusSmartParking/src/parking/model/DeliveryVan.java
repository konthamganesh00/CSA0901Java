package parking.model;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * Day-4 Challenge Addition: DeliveryVan extending Car.
 * Charged at double the Car hourly rate between 09:00 AM and 05:00 PM (17:00).
 */
public class DeliveryVan extends Car {

    private double cargoCapacityKg;

    public DeliveryVan() {
        this("UNREGISTERED", "Logistics Partner", "0000000000", 1200.0);
    }

    public DeliveryVan(String registrationNumber, String ownerName) {
        this(registrationNumber, ownerName, "N/A", 1200.0);
    }

    public DeliveryVan(String registrationNumber, String ownerName, String contactNumber, double cargoCapacityKg) {
        super(registrationNumber, ownerName, contactNumber, 2, VehicleType.DELIVERY_VAN);
        this.cargoCapacityKg = Math.max(100.0, cargoCapacityKg);
    }

    public double getCargoCapacityKg() {
        return cargoCapacityKg;
    }

    public void setCargoCapacityKg(double cargoCapacityKg) {
        if (cargoCapacityKg > 0) {
            this.cargoCapacityKg = cargoCapacityKg;
        }
    }

    @Override
    public double ratePerHour() {
        // Base hourly rate matches Car; peak hours (9 AM - 5 PM) double this rate.
        return super.ratePerHour();
    }

    /**
     * Overloaded rate method returning double the car rate during 09:00 - 17:00 peak window.
     *
     * @param time time of parking
     * @return applicable hourly rate
     */
    public double ratePerHour(LocalTime time) {
        double baseCarRate = super.ratePerHour();
        if (PricingConfig.isWithinDeliveryVanPeakHours(time)) {
            return baseCarRate * PricingConfig.getDeliveryVanPeakMultiplier();
        }
        return baseCarRate;
    }

    @Override
    public double calculateFee(int hours) {
        return calculateFee(hours, PricingConfig.isWithinDeliveryVanPeakHours(LocalTime.now()));
    }

    /**
     * Overloaded fee calculation explicitly specifying whether peak-hour pricing applies.
     *
     * @param hours       billed hours
     * @param isPeakHours true if within 9 AM - 5 PM peak window
     * @return parking fee in Rupees
     */
    public double calculateFee(int hours, boolean isPeakHours) {
        if (hours <= 0) {
            return 0.0;
        }
        double rate = isPeakHours
                ? super.ratePerHour() * PricingConfig.getDeliveryVanPeakMultiplier()
                : super.ratePerHour();
        return hours * rate;
    }

    /**
     * Evaluates each started hour between entryTime and exitTime so that hours
     * falling inside [09:00, 17:00) are billed at 2x Car rate and off-peak hours at 1x Car rate.
     *
     * @param entryTime timestamp when van entered
     * @param exitTime  timestamp when van exited
     * @return total parking fee across all started hours
     */
    public double calculateFee(LocalDateTime entryTime, LocalDateTime exitTime) {
        if (entryTime == null || exitTime == null || exitTime.isBefore(entryTime)) {
            return 0.0;
        }
        long minutes = Duration.between(entryTime, exitTime).toMinutes();
        if (minutes <= 0) {
            minutes = 1;
        }
        int billedHours = (int) ((minutes + 59) / 60);
        double total = 0.0;
        for (int i = 0; i < billedHours; i++) {
            LocalTime hourStart = entryTime.plusHours(i).toLocalTime();
            total += ratePerHour(hourStart);
        }
        return total;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" [CargoCapacity=%.1f kg, PeakRate(9-5)=Rs %.2f/hr]",
                cargoCapacityKg, super.ratePerHour() * PricingConfig.getDeliveryVanPeakMultiplier());
    }
}
