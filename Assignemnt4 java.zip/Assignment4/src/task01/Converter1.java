
package task01;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Converter1 extends JFrame implements ActionListener {

    JTextField amount = new JTextField(10);
    JComboBox<String> target =
        new JComboBox<>(new String[]{"USD", "EUR"});
    JButton convert = new JButton("Convert");
    JLabel result = new JLabel("Result: ");

    public Converter1() {
        setTitle("Currency Converter - ActionListener");
        setLayout(new FlowLayout());

        add(new JLabel("INR"));
        add(amount);
        add(target);
        add(convert);
        add(result);

        convert.addActionListener(this);
        amount.addActionListener(this);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setSize(350, 180);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        calculate();
    }

    void calculate() {
        try {
            double value = Double.parseDouble(amount.getText());
            double rate = target.getSelectedItem().equals("USD")
                    ? 0.012 : 0.011;

            double answer = value * rate;

            result.setText(String.format("Result: %.2f", answer));

            JOptionPane.showMessageDialog(this,
                    String.format("Converted Amount: %.2f", answer));

        } catch (NumberFormatException e) {
            result.setText("Invalid amount");
            JOptionPane.showMessageDialog(this, "Invalid amount");
        }
    }

    public static void main(String[] args) {
        new Converter1();
    }
}
