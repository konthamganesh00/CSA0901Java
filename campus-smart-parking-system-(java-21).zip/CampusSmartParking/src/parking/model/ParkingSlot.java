package parking.model;

import java.util.Objects;

/**
 * Represents a single physical parking bay on a specific floor.
 */
public class ParkingSlot {

    private final int floorNumber; // 1-based display floor
    private final int slotNumber;  // 1-based display slot
    private final String slotCode;
    private boolean occupied;
    private Vehicle parkedVehicle;
    private String currentTicketId;

    public ParkingSlot(int floorNumber, int slotNumber) {
        this.floorNumber = floorNumber;
        this.slotNumber = slotNumber;
        this.slotCode = String.format("F%d-S%02d", floorNumber, slotNumber);
        this.occupied = false;
    }

    public synchronized boolean occupy(Vehicle vehicle, String ticketId) {
        if (occupied || vehicle == null) {
            return false;
        }
        this.occupied = true;
        this.parkedVehicle = vehicle;
        this.currentTicketId = ticketId;
        return true;
    }

    public synchronized Vehicle vacate() {
        if (!occupied) {
            return null;
        }
        Vehicle removed = this.parkedVehicle;
        this.occupied = false;
        this.parkedVehicle = null;
        this.currentTicketId = null;
        return removed;
    }

    public int getFloorNumber() {
        return floorNumber;
    }

    public int getSlotNumber() {
        return slotNumber;
    }

    public String getSlotCode() {
        return slotCode;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public Vehicle getParkedVehicle() {
        return parkedVehicle;
    }

    public String getCurrentTicketId() {
        return currentTicketId;
    }

    @Override
    public String toString() {
        if (occupied && parkedVehicle != null) {
            return String.format("%s [OCCUPIED by %s (%s) | Ticket=%s]",
                    slotCode, parkedVehicle.getRegistrationNumber(),
                    parkedVehicle.getVehicleType().getDisplayName(), currentTicketId);
        }
        return String.format("%s [AVAILABLE]", slotCode);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ParkingSlot other)) {
            return false;
        }
        return floorNumber == other.floorNumber && slotNumber == other.slotNumber;
    }

    @Override
    public int hashCode() {
        return Objects.hash(floorNumber, slotNumber);
    }
}
