package parking.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import parking.exception.InvalidPassException;
import parking.exception.InvalidSlotException;
import parking.exception.InvalidVehicleException;
import parking.exception.ParkingFullException;
import parking.exception.TicketNotFoundException;
import parking.model.Chargeable;
import parking.model.ParkingPass;
import parking.model.ParkingSlot;
import parking.model.ParkingTicket;
import parking.model.ParkingUser;
import parking.model.Vehicle;

/**
 * Facade service orchestrating vehicle registration, slot allocation, ticket issuance,
 * EV charging, vehicle exit settlement, pass management, and reporting.
 */
public class ParkingService {

    private ParkingFacility facility;
    private final TicketService ticketService;
    private final PassService passService;
    private final FeeCalculator feeCalculator;
    private final ReportService reportService;
    private final Map<String, Vehicle> registeredVehicles;
    private final Map<String, ParkingUser> registeredUsers;

    public ParkingService() {
        this(new ParkingFacility());
    }

    public ParkingService(ParkingFacility facility) {
        this.facility = facility;
        this.ticketService = new TicketService();
        this.passService = new PassService();
        this.feeCalculator = new FeeCalculator();
        this.reportService = new ReportService();
        this.registeredVehicles = new HashMap<>();
        this.registeredUsers = new HashMap<>();
    }

    /**
     * Reconfigures the parking facility layout (only permitted when no vehicles are parked).
     */
    public void reconfigureFacility(int[] newFloorCapacities) throws InvalidSlotException {
        if (facility.getCurrentOccupancy() > 0) {
            throw new InvalidSlotException(
                    "Cannot reconfigure floors while " + facility.getCurrentOccupancy() + " vehicle(s) are parked.");
        }
        this.facility = new ParkingFacility(newFloorCapacities);
    }

    public void registerVehicle(Vehicle vehicle) throws InvalidVehicleException {
        if (vehicle == null) {
            throw new InvalidVehicleException("Vehicle cannot be null.");
        }
        String regNo = vehicle.getRegistrationNumber();
        if (!Vehicle.isValidRegistrationNumber(regNo)) {
            throw new InvalidVehicleException(
                    "Invalid registration number '" + regNo + "'. Use 4-15 alphanumeric/hyphen characters.");
        }
        String normalized = regNo.trim().toUpperCase().replaceAll("\\s+", "");
        if (registeredVehicles.containsKey(normalized)) {
            throw new InvalidVehicleException(
                    "Duplicate registration number: " + normalized + " is already registered.");
        }
        registeredVehicles.put(normalized, vehicle);
    }

    public Vehicle getRegisteredVehicle(String regNo) throws InvalidVehicleException {
        if (regNo == null || regNo.isBlank()) {
            throw new InvalidVehicleException("Registration number cannot be empty.");
        }
        String normalized = regNo.trim().toUpperCase().replaceAll("\\s+", "");
        Vehicle v = registeredVehicles.get(normalized);
        if (v == null) {
            throw new InvalidVehicleException("Vehicle " + normalized + " is not registered.");
        }
        return v;
    }

    public boolean isVehicleRegistered(String regNo) {
        if (regNo == null || regNo.isBlank()) {
            return false;
        }
        String normalized = regNo.trim().toUpperCase().replaceAll("\\s+", "");
        return registeredVehicles.containsKey(normalized);
    }

    public Collection<Vehicle> getAllRegisteredVehicles() {
        return registeredVehicles.values();
    }

    public void registerUser(ParkingUser user) {
        if (user != null) {
            registeredUsers.put(user.getUserId().toUpperCase(), user);
        }
    }

    public ParkingUser getUser(String userId) {
        if (userId == null) {
            return null;
        }
        return registeredUsers.get(userId.trim().toUpperCase());
    }

    /**
     * Processes complete vehicle entry: registers if needed, checks duplicate parking,
     * automatically allocates the first available slot, and generates a unique ticket.
     */
    public ParkingTicket enterVehicle(Vehicle vehicle, LocalDateTime entryTime)
            throws InvalidVehicleException, ParkingFullException {
        if (vehicle == null) {
            throw new InvalidVehicleException("Vehicle cannot be null.");
        }
        String regNo = vehicle.getRegistrationNumber();
        if (!Vehicle.isValidRegistrationNumber(regNo)) {
            throw new InvalidVehicleException("Invalid vehicle registration number: " + regNo);
        }
        if (ticketService.hasActiveTicket(regNo)) {
            throw new InvalidVehicleException("Vehicle " + regNo + " is already parked inside the campus.");
        }
        if (facility.isFull()) {
            throw new ParkingFullException("Parking facility is full. No slots available.");
        }

        registeredVehicles.putIfAbsent(regNo.toUpperCase(), vehicle);

        LocalDateTime effectiveEntry = (entryTime == null) ? LocalDateTime.now() : entryTime;
        // Allocate slot first, then create ticket and link ticket ID onto the slot
        int[] coords = facility.allocateFirstAvailableSlot(vehicle, "PENDING");
        String slotCode = String.format("F%d-S%02d", coords[0] + 1, coords[1] + 1);
        ParkingTicket ticket = ticketService.createTicket(vehicle, coords[0], coords[1], slotCode, effectiveEntry);
        try {
            ParkingSlot slot = facility.getSlot(coords[0], coords[1]);
            slot.vacate();
            slot.occupy(vehicle, ticket.getTicketId());
        } catch (InvalidSlotException ignored) {
            // Coordinates came directly from allocateFirstAvailableSlot
        }
        return ticket;
    }

    /**
     * Allocates a specific floor and slot (0-based indices) for a vehicle and issues a ticket.
     */
    public ParkingTicket enterVehicleInSpecificSlot(Vehicle vehicle, int floorIndex, int slotIndex,
                                                    LocalDateTime entryTime)
            throws InvalidVehicleException, InvalidSlotException {
        if (vehicle == null) {
            throw new InvalidVehicleException("Vehicle cannot be null.");
        }
        String regNo = vehicle.getRegistrationNumber();
        if (!Vehicle.isValidRegistrationNumber(regNo)) {
            throw new InvalidVehicleException("Invalid vehicle registration number: " + regNo);
        }
        if (ticketService.hasActiveTicket(regNo)) {
            throw new InvalidVehicleException("Vehicle " + regNo + " is already parked.");
        }
        registeredVehicles.putIfAbsent(regNo.toUpperCase(), vehicle);
        LocalDateTime effectiveEntry = (entryTime == null) ? LocalDateTime.now() : entryTime;

        ParkingSlot slot = facility.allocateSpecificSlot(floorIndex, slotIndex, vehicle, "PENDING");
        ParkingTicket ticket = ticketService.createTicket(
                vehicle, floorIndex, slotIndex, slot.getSlotCode(), effectiveEntry);
        slot.vacate();
        slot.occupy(vehicle, ticket.getTicketId());
        return ticket;
    }

    /**
     * Processes vehicle exit: validates ticket and optional pass, computes fees,
     * settles the ticket, and releases the parking slot.
     */
    public ParkingTicket exitVehicleByTicketId(String ticketId, LocalDateTime exitTime, String optionalPassId)
            throws TicketNotFoundException, InvalidSlotException, InvalidPassException {
        ParkingTicket ticket = ticketService.findTicketById(ticketId);
        if (ticket.isSettled()) {
            throw new TicketNotFoundException("Ticket " + ticket.getTicketId() + " is already settled.");
        }
        return settleAndRelease(ticket, exitTime, optionalPassId);
    }

    public ParkingTicket exitVehicleByRegNo(String regNo, LocalDateTime exitTime, String optionalPassId)
            throws TicketNotFoundException, InvalidSlotException, InvalidPassException {
        ParkingTicket ticket = ticketService.findActiveTicketByRegNo(regNo);
        return settleAndRelease(ticket, exitTime, optionalPassId);
    }

    private ParkingTicket settleAndRelease(ParkingTicket ticket, LocalDateTime exitTime, String optionalPassId)
            throws InvalidSlotException, InvalidPassException {
        LocalDateTime effectiveExit = (exitTime == null) ? LocalDateTime.now() : exitTime;
        if (effectiveExit.isBefore(ticket.getEntryTime())) {
            throw new IllegalArgumentException("Exit time cannot be earlier than entry time.");
        }

        ParkingPass passToApply = null;
        if (optionalPassId != null && !optionalPassId.isBlank()) {
            passToApply = passService.validatePass(
                    optionalPassId,
                    ticket.getVehicle().getRegistrationNumber(),
                    effectiveExit.toLocalDate());
        } else {
            ParkingPass autoPass = passService.findPassForVehicle(ticket.getVehicle().getRegistrationNumber());
            if (autoPass != null && autoPass.isValidOn(effectiveExit.toLocalDate())) {
                passToApply = autoPass;
            }
        }

        FeeCalculator.FeeBreakdown breakdown = feeCalculator.calculateFeeBreakdown(
                ticket.getVehicle(), ticket.getEntryTime(), effectiveExit, passToApply);

        ticket.settleTicket(
                effectiveExit,
                breakdown.billedHours(),
                breakdown.adjustedParkingFee(),
                breakdown.chargingFee(),
                breakdown.finalTotalFee(),
                breakdown.passNote()
        );
        ticketService.markTicketSettled(ticket);
        facility.releaseSlot(ticket.getFloorIndex(), ticket.getSlotIndex());
        return ticket;
    }

    public boolean toggleEvChargingForParkedVehicle(String regNo, boolean enableCharging)
            throws TicketNotFoundException, InvalidVehicleException {
        return updateEvChargingForParkedVehicle(regNo, enableCharging, -1.0);
    }

    public boolean updateEvChargingForParkedVehicle(String regNo, boolean enableCharging, double kwh)
            throws TicketNotFoundException, InvalidVehicleException {
        ParkingTicket ticket = ticketService.findActiveTicketByRegNo(regNo);
        Vehicle vehicle = ticket.getVehicle();
        if (vehicle instanceof Chargeable chargeable) {
            chargeable.setChargingRequested(enableCharging);
            if (kwh >= 0) {
                chargeable.setChargingUnitsKwh(kwh);
            }
            return true;
        }
        throw new InvalidVehicleException(
                "Vehicle " + regNo + " (" + vehicle.getVehicleType().getDisplayName() + ") does not support EV charging.");
    }

    public ParkingFacility getFacility() {
        return facility;
    }

    public TicketService getTicketService() {
        return ticketService;
    }

    public PassService getPassService() {
        return passService;
    }

    public FeeCalculator getFeeCalculator() {
        return feeCalculator;
    }

    public ReportService getReportService() {
        return reportService;
    }

    public List<ParkingSlot> getAvailableSlots() {
        return facility.getAvailableSlots();
    }

    public List<ParkingSlot> getOccupiedSlots() {
        return facility.getOccupiedSlots();
    }

    public List<ParkingTicket> getParkedVehicleTickets() {
        return ticketService.getActiveTickets();
    }

    public String getDailyCollectionReport(LocalDate date) {
        return reportService.buildDailyCollectionReport(date, ticketService, passService);
    }

    public String getOccupancyReport() {
        return reportService.buildOccupancyReport(facility);
    }

    public String getAllFloorsDisplay() {
        return reportService.buildFloorVisualMap(facility);
    }
}
