/**
 * Task 09 - Abstraction: Abstract Vehicle Class, abstract ratePerHour(),
 * Chargeable & Identifiable Interfaces, default and static interface methods.
 */
public class AbstractionDemo {

    interface Identifiable {
        String getRegistryCode();

        default String formatBadge() {
            return "[ID: " + getRegistryCode() + "]";
        }
    }

    interface Chargeable {
        String STANDARD = "CCS2 Fast Charger (22 kW)";

        double chargingFee();

        default String getChargingDetails() {
            return STANDARD + " | Fee: Rs " + chargingFee();
        }

        static boolean isChargeable(Object obj) {
            return obj instanceof Chargeable;
        }
    }

    static abstract class AbstractVehicle implements Identifiable {
        protected final String regNo;

        protected AbstractVehicle(String regNo) {
            this.regNo = regNo;
        }

        public abstract double ratePerHour();

        @Override
        public String getRegistryCode() {
            return regNo;
        }
    }

    // Implements multiple interfaces: Identifiable (via AbstractVehicle) + Chargeable
    static class SmartElectricCar extends AbstractVehicle implements Chargeable {
        SmartElectricCar(String regNo) {
            super(regNo);
        }

        @Override
        public double ratePerHour() {
            return 40.0;
        }

        @Override
        public double chargingFee() {
            return 90.0;
        }
    }

    public static void main(String[] args) {
        SmartElectricCar ev = new SmartElectricCar("TN09EV99");
        System.out.println("Badge    : " + ev.formatBadge());
        System.out.println("Rate/hr  : Rs " + ev.ratePerHour());
        System.out.println("Charging : " + ev.getChargingDetails());
        System.out.println("Eligible : " + Chargeable.isChargeable(ev));
    }
}
