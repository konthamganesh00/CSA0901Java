package assignment_2;


import java.util.*;

public class Q2ListComparison {

    static void test(int size) {

        ArrayList<Integer> arrayList = new ArrayList<>();
        LinkedList<Integer> linkedList = new LinkedList<>();
        ArrayDeque<Integer> deque = new ArrayDeque<>();

        for (int i = 0; i < size; i++) {
            arrayList.add(i);
            linkedList.add(i);
            deque.add(i);
        }

        System.out.println("\nPlaylist Size: " + size);

        long start, end;

        start = System.nanoTime();
        arrayList.add(999);
        end = System.nanoTime();
        System.out.println("ArrayList Add: " + (end - start) + " ns");

        start = System.nanoTime();
        linkedList.add(999);
        end = System.nanoTime();
        System.out.println("LinkedList Add: " + (end - start) + " ns");

        start = System.nanoTime();
        deque.addLast(999);
        end = System.nanoTime();
        System.out.println("ArrayDeque Add: " + (end - start) + " ns");

        start = System.nanoTime();
        arrayList.add(0, 100);
        end = System.nanoTime();
        System.out.println("ArrayList Front Insert: " + (end - start) + " ns");

        start = System.nanoTime();
        linkedList.addFirst(100);
        end = System.nanoTime();
        System.out.println("LinkedList Front Insert: " + (end - start) + " ns");

        start = System.nanoTime();
        deque.addFirst(100);
        end = System.nanoTime();
        System.out.println("ArrayDeque Front Insert: " + (end - start) + " ns");

        start = System.nanoTime();
        arrayList.get(size / 2);
        end = System.nanoTime();
        System.out.println("ArrayList Middle Access: " + (end - start) + " ns");

        start = System.nanoTime();
        linkedList.get(size / 2);
        end = System.nanoTime();
        System.out.println("LinkedList Middle Access: " + (end - start) + " ns");

        start = System.nanoTime();
        arrayList.remove(0);
        end = System.nanoTime();
        System.out.println("ArrayList Front Remove: " + (end - start) + " ns");

        start = System.nanoTime();
        linkedList.removeFirst();
        end = System.nanoTime();
        System.out.println("LinkedList Front Remove: " + (end - start) + " ns");

        start = System.nanoTime();
        deque.removeFirst();
        end = System.nanoTime();
        System.out.println("ArrayDeque Front Remove: " + (end - start) + " ns");

        start = System.nanoTime();
        long sum = 0;
        for (int x : arrayList) sum += x;
        end = System.nanoTime();
        System.out.println("ArrayList Iteration: " + (end - start) + " ns");

        start = System.nanoTime();
        sum = 0;
        for (int x : linkedList) sum += x;
        end = System.nanoTime();
        System.out.println("LinkedList Iteration: " + (end - start) + " ns");

        start = System.nanoTime();
        sum = 0;
        for (int x : deque) sum += x;
        end = System.nanoTime();
        System.out.println("ArrayDeque Iteration: " + (end - start) + " ns");
    }

    public static void main(String[] args) {

        test(1000);
        test(10000);
        test(50000);

    }
}
