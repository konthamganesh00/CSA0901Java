
package taskA3;

import java.util.ArrayList;
import java.util.List;

public class StudentDao implements Dao<Student, Integer> {

    ArrayList<Student> students = new ArrayList<>();

    @Override
    public void insert(Student s) {
        students.add(s);
        System.out.println("Student inserted successfully");
    }

    @Override
    public Student findById(Integer id) {
        for (Student s : students) {
            if (s.getId() == id) {
                return s;
            }
        }
        return null;
    }

    @Override
    public List<Student> findAll() {
        return students;
    }

    @Override
    public void update(Student updated) {
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getId() == updated.getId()) {
                students.set(i, updated);
                System.out.println("Student updated successfully");
                return;
            }
        }
        System.out.println("Student not found");
    }

    @Override
    public void delete(Integer id) {
        students.removeIf(s -> s.getId() == id);
        System.out.println("Student deleted successfully");
    }

    public static void main(String[] args) {

        StudentDao dao = new StudentDao();

        dao.insert(new Student(101, "Arun", "Java", 85));
        dao.insert(new Student(102, "Divya", "Python", 90));

        System.out.println("\nAll Students:");
        for (Student s : dao.findAll()) {
            System.out.println(s);
        }

        System.out.println("\nSearch Student:");
        System.out.println(dao.findById(101));

        dao.update(new Student(101, "Arun", "Java", 95));

        System.out.println("\nAfter Update:");
        System.out.println(dao.findById(101));

        dao.delete(102);

        System.out.println("\nFinal Student List:");
        for (Student s : dao.findAll()) {
            System.out.println(s);
        }
    }
}
