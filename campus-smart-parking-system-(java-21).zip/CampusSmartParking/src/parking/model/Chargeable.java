package parking.model;

/**
 * Contract for electric vehicles that support campus EV charging.
 * Demonstrates interface constants, abstract methods, default methods, and static methods.
 */
public interface Chargeable {

    String CHARGING_STANDARD = "Campus Type-2 / CCS2 Smart Charger (7.4 kW - 22 kW)";

    /**
     * Returns the charging fee applicable for this vehicle's charging session.
     *
     * @return charging fee in Rupees
     */
    double chargingFee();

    /**
     * Indicates whether charging is currently active for this vehicle.
     *
     * @return true if EV charging is enabled
     */
    boolean isChargingRequested();

    /**
     * Sets whether EV charging is requested during parking.
     *
     * @param chargingRequested true to enable charging
     */
    void setChargingRequested(boolean chargingRequested);

    default double getChargingUnitsKwh() {
        return PricingConfig.getDefaultEvChargingKwh();
    }

    default void setChargingUnitsKwh(double kwh) {
        // Implemented by EV subclasses tracking kWh consumption
    }

    /**
     * Default helper method describing the charging connector standard.
     *
     * @return charging standard description
     */
    default String getChargingStandardInfo() {
        return CHARGING_STANDARD;
    }

    /**
     * Static utility method checking whether a given Vehicle supports charging.
     *
     * @param vehicle vehicle instance to inspect
     * @return true if vehicle implements Chargeable
     */
    static boolean supportsCharging(Vehicle vehicle) {
        return vehicle instanceof Chargeable;
    }
}
