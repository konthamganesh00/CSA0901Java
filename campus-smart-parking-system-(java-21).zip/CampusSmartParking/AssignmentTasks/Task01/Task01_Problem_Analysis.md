# TASK 1 – Problem Analysis and Objects

## 1. Problem Statement
Universities and large academic campuses experience daily parking congestion across multiple lots and floors, involving diverse user categories (students, faculty/staff, delivery partners, and visitors) and varied vehicle types (two-wheelers, cars, electric cars, e-bikes, and delivery vans). Manual register-based parking management causes slow gate queues, inaccurate fee calculation, untracked pass validity, and poor visibility into floor occupancy.

The **Campus Smart-Parking System** solves this problem via a Java 21 object-oriented console application that automates vehicle registration, first-available jagged floor/slot allocation, timestamped ticket generation, centralised ceiling-based fee computation, EV charging billing, pass validation (student monthly, staff monthly, visitor one-day), and daily collection/occupancy reporting.

## 2. Inputs and Outputs

### Inputs
- Vehicle details: registration number, owner name, contact number, vehicle category (`TwoWheeler`, `Car`, `ElectricCar`, `EBike`, `DeliveryVan`), and category attributes (helmet storage, doors, battery kWh, voltage, cargo kg).
- Entry/exit events: vehicle registration number or ticket ID, entry/exit timestamps, optional specific floor/slot coordinates, and EV charging toggle.
- Pass management inputs: user/holder ID, holder name, pass category (`STUDENT` / `STAFF` monthly or `VISITOR` one-day), validity duration, and pass ID.
- Facility configuration: floor count and slot capacities per floor.

### Outputs
- Generated unique parking ticket (`TKT-1001`, etc.) with assigned slot code (`F1-S01`) and entry timestamp.
- Available slots list, occupied slots list, and full jagged floor-slot visual grid.
- Itemised exit receipt showing billed hours, applied pass rule, parking fee, EV charging fee, and total payable amount.
- Daily Collection Report (by category and pass revenue) and Parking Occupancy Report.

## 3. Candidate Classes and Responsibilities

| Class / Interface | Package | Primary Responsibility |
|---|---|---|
| `Vehicle` (abstract) | `parking.model` | Base state (regNo, owner, contact), abstract `ratePerHour()`, `equals`/`hashCode` |
| `TwoWheeler`, `Car`, `ElectricCar`, `EBike`, `DeliveryVan` | `parking.model` | Specialised hourly/flat/peak-hour rates and vehicle-specific attributes |
| `Chargeable` (interface) | `parking.model` | EV charging contract (`chargingFee()`, `isChargingRequested()`, default/static helpers) |
| `PassHolder` (interface) | `parking.model` | Contract for users holding a `ParkingPass` |
| `ParkingSlot` | `parking.model` | Represents one bay (`F1-S01`), occupancy state, prevents double occupancy |
| `ParkingFloor` | `parking.model` | Represents one floor containing an array of `ParkingSlot` objects |
| `ParkingTicket` | `parking.model` | Unique static-sequenced ticket recording entry, exit, billed hours, and fees |
| `ParkingPass`, `MonthlyPass`, `OneDayPass` | `parking.model` | Pass validity rules (Student/Staff free parking, Visitor One-Day flat rate) |
| `ParkingUser` | `parking.model` | Represents Student, Staff, or Visitor holding vehicles and passes |
| `PricingConfig` | `parking.model` | Centralised configurable fee rates and peak window constants |
| `ParkingFacility` | `parking.service` | Jagged 2D `ParkingSlot[][]` floor-slot allocation, release, and occupancy tracking |
| `FeeCalculator` | `parking.service` | Centralised ceiling-hour arithmetic, peak rules, EV fees, and pass exemptions |
| `TicketService` | `parking.service` | O(1) `HashMap` ticket lookup and `ArrayList` chronological history |
| `PassService` | `parking.service` | Issuance, lookup, renewal, revocation, and validation of passes |
| `ReportService` | `parking.service` | Daily collection, occupancy, and visual floor map generation |
| `ParkingService` | `parking.service` | Facade orchestrating end-to-end campus parking workflows |
| `Main` | `parking.app` | Interactive 17-option `Scanner`-driven console menu |
| `ParkingException` & subclasses | `parking.exception` | Domain error handling (`ParkingFullException`, `InvalidPassException`, etc.) |

## 4. Business Rules
1. Every started hour is charged in full (`ceil(minutes / 60.0)` using `(minutes + 59) / 60`).
2. Two vehicles cannot occupy the same parking slot simultaneously, nor can the same vehicle hold two active tickets simultaneously.
3. Valid Student and Staff Monthly Passes grant free parking (`Rs 0.0` parking fee); EV charging fee still applies if EV charging is used.
4. Valid Visitor One-Day Passes apply the configured one-day pass flat rate (`Rs 50.0`) covering parking for that day.
5. Expired, revoked, or vehicle-mismatched passes are rejected, and standard visitor rates apply.
6. Delivery vans are charged at 2x Car rate (`Rs 60.0/hr`) between 09:00 AM and 05:00 PM, and 1x Car rate (`Rs 30.0/hr`) outside that window.
7. E-Bikes pay a flat parking fee (`Rs 15.0`) regardless of duration.

## 5. Assumptions (Where Exact Rates Are Not Specified in Brief)
- TwoWheeler rate: `Rs 10.0/hr` (consistent with Task 8 `3 hrs = Rs 30.0`).
- Car rate: `Rs 30.0/hr` (consistent with Task 8 `3 hrs = Rs 90.0`).
- ElectricCar rate: `Rs 40.0/hr` + `Rs 90.0` EV charging session fee (consistent with Task 8 `3 hrs = 120 + 90 = Rs 210.0`).
- EBike flat fee: `Rs 15.0` per visit.
- Visitor One-Day Pass fee: `Rs 50.0`; Student Monthly Pass: `Rs 200.0`; Staff Monthly Pass: `Rs 300.0`.
- Daily Maximum Fee Cap: `Rs 500.0` (configurable in `PricingConfig`).

## 6. Alternative Design: Parallel String Arrays
In a procedural alternative (`ParallelArrayParkingDemo.java`), each attribute is stored in a separate 1D array (`String[] regNumbers`, `String[] vehicleTypes`, `boolean[] occupied`) synchronized by index `i`.
- **Drawbacks**: Fragile synchronization across multiple arrays, no compile-time type safety, impossible to polymorphically dispatch `calculateFee()`, and hard to extend when adding `EBike` or `DeliveryVan`.

## 7. Time and Space Complexity Comparison

| Operation | Parallel Arrays (`N` slots) | OOP + Jagged Array + HashMap (`N` slots, `T` tickets) |
|---|---|---|
| Slot Allocation | `O(N)` linear scan | `O(F * S_f) = O(N)` linear scan over free slots |
| Slot Release (by coordinates) | `O(N)` search by regNo | `O(1)` direct array indexing `floorSlots[f][s]` |
| Ticket / Vehicle Lookup | `O(N)` linear scan | `O(1)` average via `HashMap<String, ParkingTicket>` |
| Space Complexity | `O(k * N)` across `k` parallel arrays | `O(N)` for `ParkingSlot[][]` + `O(T)` for ticket records |
