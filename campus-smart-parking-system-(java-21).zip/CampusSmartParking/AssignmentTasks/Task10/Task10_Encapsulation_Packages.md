# TASK 10 – Encapsulation and Packages

## 1. Package Structure
- `parking.model` — Domain entities (`Vehicle`, `TwoWheeler`, `Car`, `ElectricCar`, `EBike`, `DeliveryVan`, `ParkingSlot`, `ParkingFloor`, `ParkingTicket`, `ParkingPass`, `MonthlyPass`, `OneDayPass`, `ParkingUser`, `PricingConfig`, `Chargeable`, `PassHolder`, `VehicleType`).
- `parking.service` — Business logic (`ParkingFacility`, `FeeCalculator`, `TicketService`, `PassService`, `ReportService`, `ParkingService`).
- `parking.app` — Console interface (`Main`).
- `parking.exception` — Custom checked exception hierarchy (`ParkingException`, `ParkingFullException`, `InvalidVehicleException`, `InvalidSlotException`, `InvalidPassException`, `TicketNotFoundException`).

## 2. Encapsulation & Domain Validations Implemented
- All model fields are `private` with controlled public getters and validated setters.
- **Registration Numbers**: `Vehicle.isValidRegistrationNumber(...)` enforces `^[A-Z0-9-]{4,15}$` and normalizes whitespace/case.
- **Parking Slot Numbers**: `ParkingFacility.isValidCoordinate(floor, slot)` rejects negative or out-of-bounds coordinates with `InvalidSlotException`.
- **Parking Duration**: `FeeCalculator.calculateBilledHours(...)` rejects `null` timestamps and `exitTime < entryTime`.
- **Parking Fees**: `PricingConfig` setters guard against negative rates (`rate >= 0`).
- **Pass Validity**: `PassService.validatePass(...)` verifies active status, date window (`!date.isBefore(issueDate) && !date.isAfter(expiryDate)`), and vehicle registration match, throwing `InvalidPassException` otherwise.

## 3. Java Access Modifiers Explained

| Modifier | Same Class | Same Package | Subclass (Other Package) | World (Other Package) | Usage in Project |
|---|---|---|---|---|---|
| `private` | Yes | No | No | No | Encapsulated fields (`registrationNumber`, `occupied`, `ticketCounter`) |
| `default` (package-private) | Yes | Yes | No | No | Internal helpers within the same package |
| `protected` | Yes | Yes | Yes | No | Superclass constructors/helpers in `Vehicle` and `ParkingPass` |
| `public` | Yes | Yes | Yes | Yes | Service APIs, `Main`, `Chargeable`, `PassHolder`, getters |
