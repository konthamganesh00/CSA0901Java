package parking.model;

import java.util.Objects;

/**
 * Abstract base class representing any vehicle entering the campus smart-parking facility.
 *
 * <p>Demonstrates abstraction, encapsulation, static tracking, constructor overloading,
 * constructor chaining via {@code this(...)}, and consistent {@code toString}, {@code equals},
 * and {@code hashCode} implementations.
 */
public abstract class Vehicle {

    private static int totalVehiclesCreated = 0;

    private String registrationNumber;
    private String ownerName;
    private String contactNumber;
    private final VehicleType vehicleType;
    private ParkingUser.UserRole userCategory = ParkingUser.UserRole.VISITOR;

    /**
     * Default constructor chaining to the full parameterised constructor.
     */
    protected Vehicle() {
        this("UNREGISTERED", "Campus Guest", "0000000000", VehicleType.CAR);
    }

    /**
     * Two-argument convenience constructor using constructor chaining.
     *
     * @param registrationNumber vehicle license plate
     * @param ownerName          owner's full name
     */
    protected Vehicle(String registrationNumber, String ownerName) {
        this(registrationNumber, ownerName, "N/A", VehicleType.CAR);
    }

    /**
     * Three-argument constructor with explicit vehicle type.
     *
     * @param registrationNumber vehicle license plate
     * @param ownerName          owner's full name
     * @param vehicleType        category of the vehicle
     */
    protected Vehicle(String registrationNumber, String ownerName, VehicleType vehicleType) {
        this(registrationNumber, ownerName, "N/A", vehicleType);
    }

    /**
     * Master parameterised constructor validating and initializing all core vehicle attributes.
     *
     * @param registrationNumber vehicle license plate
     * @param ownerName          owner's full name
     * @param contactNumber      owner's contact phone
     * @param vehicleType        category of the vehicle
     */
    protected Vehicle(String registrationNumber, String ownerName, String contactNumber, VehicleType vehicleType) {
        this.registrationNumber = normalizeAndValidateRegNo(registrationNumber);
        this.ownerName = (ownerName == null || ownerName.isBlank()) ? "Unknown Owner" : ownerName.trim();
        this.contactNumber = (contactNumber == null || contactNumber.isBlank()) ? "N/A" : contactNumber.trim();
        this.vehicleType = (vehicleType == null) ? VehicleType.CAR : vehicleType;
        totalVehiclesCreated++;
    }

    /**
     * Validates that a registration number conforms to basic alphanumeric campus standards.
     *
     * @param regNo raw registration string
     * @return true if valid
     */
    public static boolean isValidRegistrationNumber(String regNo) {
        if (regNo == null) {
            return false;
        }
        String cleaned = regNo.trim().toUpperCase().replaceAll("\\s+", "");
        return cleaned.matches("^[A-Z0-9-]{4,15}$");
    }

    private static String normalizeAndValidateRegNo(String regNo) {
        if (regNo == null || regNo.isBlank()) {
            return "UNREGISTERED";
        }
        return regNo.trim().toUpperCase().replaceAll("\\s+", "");
    }

    public static int getTotalVehiclesCreated() {
        return totalVehiclesCreated;
    }

    /**
     * Abstract hourly parking rate implemented by concrete vehicle subclasses.
     *
     * @return base parking rate per started hour in Rupees
     */
    public abstract double ratePerHour();

    /**
     * Calculates the parking fee for the specified number of billed hours.
     * Subclasses override this method to provide specialised fee rules.
     *
     * @param hours number of started hours
     * @return parking fee in Rupees
     */
    public double calculateFee(int hours) {
        if (hours <= 0) {
            return 0.0;
        }
        return hours * ratePerHour();
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        if (isValidRegistrationNumber(registrationNumber)) {
            this.registrationNumber = normalizeAndValidateRegNo(registrationNumber);
        }
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        if (ownerName != null && !ownerName.isBlank()) {
            this.ownerName = ownerName.trim();
        }
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        if (contactNumber != null && !contactNumber.isBlank()) {
            this.contactNumber = contactNumber.trim();
        }
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public ParkingUser.UserRole getUserCategory() {
        return userCategory;
    }

    public void setUserCategory(ParkingUser.UserRole userCategory) {
        if (userCategory != null) {
            this.userCategory = userCategory;
        }
    }

    @Override
    public String toString() {
        return String.format("%s [RegNo=%s, Owner=%s, User=%s, Contact=%s, Rate=Rs %.2f/hr]",
                vehicleType.getDisplayName(), registrationNumber, ownerName,
                userCategory, contactNumber, ratePerHour());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Vehicle other)) {
            return false;
        }
        return Objects.equals(this.registrationNumber, other.registrationNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(registrationNumber);
    }
}
