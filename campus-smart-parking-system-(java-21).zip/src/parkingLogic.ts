export type VehicleCategory = 'TwoWheeler' | 'Car' | 'ElectricCar' | 'EBike' | 'DeliveryVan';
export type UserCategory = 'Student' | 'Staff' | 'Visitor';
export type PassCategory = 'None' | 'StudentMonthly' | 'StaffMonthly' | 'VisitorOneDay';

export interface PricingRates {
  twoWheelerPerHour: number;
  carPerHour: number;
  electricCarPerHour: number;
  evChargingPerKwh: number;
  defaultEvKwh: number;
  ebikeFlatFee: number;
  deliveryVanPeakMultiplier: number;
  visitorOneDayPassFee: number;
  studentMonthlyPassFee: number;
  staffMonthlyPassFee: number;
  dailyMaxCap: number;
}

export interface RegisteredVehicle {
  regNo: string;
  ownerName: string;
  vehicleCategory: VehicleCategory;
  userCategory: UserCategory;
  registeredAtIso: string;
}

export interface ParkedVehicleInfo {
  ticketId: string;
  regNo: string;
  ownerName: string;
  category: VehicleCategory;
  userCategory: UserCategory;
  entryTimeIso: string;
  passId: string | null;
  passType: PassCategory;
  chargingRequested: boolean;
  chargingKwh: number;
}

export interface ParkingSlot {
  id: string;
  floor: number;
  slotNumber: number;
  occupied: boolean;
  vehicle: ParkedVehicleInfo | null;
}

export interface PassRecord {
  passId: string;
  category: Exclude<PassCategory, 'None'>;
  holderName: string;
  holderId: string;
  regNo: string;
  validUntil: string;
  active: boolean;
  purchasePrice: number;
  issuedAtDate: string;
}

export interface SettledTransaction {
  ticketId: string;
  regNo: string;
  ownerName: string;
  category: VehicleCategory;
  userCategory: UserCategory;
  slotId: string;
  entryTimeIso: string;
  exitTimeIso: string;
  billedHours: number;
  parkingFee: number;
  chargingKwh: number;
  chargingFee: number;
  totalFee: number;
  passNote: string;
  settledAt: string;
}

export interface PersistedParkingState {
  floorCapacities: number[];
  slots: ParkingSlot[];
  registeredVehicles: RegisteredVehicle[];
  passes: PassRecord[];
  transactions: SettledTransaction[];
  rates: PricingRates;
  ticketSeq: number;
  passSeq: number;
}

export const STORAGE_KEY = 'campus_smart_parking_state_v2';

export const DEFAULT_RATES: PricingRates = {
  twoWheelerPerHour: 10,
  carPerHour: 30,
  electricCarPerHour: 40,
  evChargingPerKwh: 12,
  defaultEvKwh: 7.5,
  ebikeFlatFee: 15,
  deliveryVanPeakMultiplier: 2,
  visitorOneDayPassFee: 50,
  studentMonthlyPassFee: 200,
  staffMonthlyPassFee: 300,
  dailyMaxCap: 500,
};

export const RATE_ASSUMPTIONS: Array<{ item: string; value: string; source: string }> = [
  { item: 'TwoWheeler Hourly Rate', value: 'Rs 10 / hr', source: 'Assumed (matches Task 8: 3h = Rs 30)' },
  { item: 'Car Hourly Rate', value: 'Rs 30 / hr', source: 'Assumed (matches Task 8: 3h = Rs 90)' },
  { item: 'ElectricCar Hourly Rate', value: 'Rs 40 / hr', source: 'Assumed (matches Task 8: 3h base = Rs 120)' },
  { item: 'EV Charging Rate', value: 'Rs 12 / kWh', source: 'Specified in requirements' },
  { item: 'E-Bike Flat Fee', value: 'Rs 15 / visit', source: 'Assumed flat fee' },
  { item: 'DeliveryVan Peak (9 AM - 5 PM)', value: '2x Car rate (Rs 60 / hr)', source: 'Specified rule' },
  { item: 'Student / Staff Monthly Pass', value: 'Rs 200 / Rs 300 (Free exit)', source: 'Assumed pass fees' },
  { item: 'Visitor One-Day Pass', value: 'Rs 50 / day', source: 'Assumed one-day pass fee' },
  { item: 'Daily Max Parking Cap', value: 'Rs 500 / visit', source: 'Assumed cap' },
];

export const DEFAULT_FLOOR_CAPACITIES = [10, 15, 20, 25, 30];

export function normalizeRegNo(regNo: string): string {
  return regNo.trim().toUpperCase().replace(/\s+/g, '');
}

export function isValidRegNo(regNo: string): boolean {
  return /^[A-Z0-9-]{4,15}$/.test(normalizeRegNo(regNo));
}

export function todayDateString(now: Date = new Date()): string {
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

export function buildJaggedFacility(capacities: number[]): ParkingSlot[] {
  const slots: ParkingSlot[] = [];
  capacities.forEach((cap, floorIdx) => {
    const floor = floorIdx + 1;
    for (let s = 1; s <= cap; s++) {
      slots.push({
        id: `F${floor}-S${String(s).padStart(2, '0')}`,
        floor,
        slotNumber: s,
        occupied: false,
        vehicle: null,
      });
    }
  });
  return slots;
}

export function createInitialParkingState(): PersistedParkingState {
  const slots = buildJaggedFacility(DEFAULT_FLOOR_CAPACITIES);
  const now = Date.now();
  const today = todayDateString(new Date(now));

  const initialPasses: PassRecord[] = [
    {
      passId: 'MP-STU-501',
      category: 'StudentMonthly',
      holderName: 'Aarav Sharma',
      holderId: 'STU-2026-041',
      regNo: 'TN01AB1024',
      validUntil: '2026-12-16',
      active: true,
      purchasePrice: DEFAULT_RATES.studentMonthlyPassFee,
      issuedAtDate: today,
    },
    {
      passId: 'MP-STF-502',
      category: 'StaffMonthly',
      holderName: 'Dr. Ramesh Kumar',
      holderId: 'FAC-118',
      regNo: 'TN09ST5151',
      validUntil: '2026-12-16',
      active: true,
      purchasePrice: DEFAULT_RATES.staffMonthlyPassFee,
      issuedAtDate: today,
    },
    {
      passId: 'ODP-503',
      category: 'VisitorOneDay',
      holderName: 'Rohan Verma',
      holderId: 'VIS-882',
      regNo: 'TN04VS3312',
      validUntil: today,
      active: true,
      purchasePrice: DEFAULT_RATES.visitorOneDayPassFee,
      issuedAtDate: today,
    },
  ];

  const seededEntries: Array<{ idx: number; info: ParkedVehicleInfo }> = [
    {
      idx: 0,
      info: {
        ticketId: 'TKT-1001',
        regNo: 'TN01AB1024',
        ownerName: 'Aarav Sharma',
        category: 'TwoWheeler',
        userCategory: 'Student',
        entryTimeIso: new Date(now - 135 * 60 * 1000).toISOString(),
        passId: 'MP-STU-501',
        passType: 'StudentMonthly',
        chargingRequested: false,
        chargingKwh: 0,
      },
    },
    {
      idx: 1,
      info: {
        ticketId: 'TKT-1002',
        regNo: 'TN02CD4480',
        ownerName: 'Priya Nair',
        category: 'Car',
        userCategory: 'Visitor',
        entryTimeIso: new Date(now - 95 * 60 * 1000).toISOString(),
        passId: null,
        passType: 'None',
        chargingRequested: false,
        chargingKwh: 0,
      },
    },
    {
      idx: 2,
      info: {
        ticketId: 'TKT-1003',
        regNo: 'TN03EV9090',
        ownerName: 'Karthik Rao',
        category: 'ElectricCar',
        userCategory: 'Staff',
        entryTimeIso: new Date(now - 170 * 60 * 1000).toISOString(),
        passId: null,
        passType: 'None',
        chargingRequested: true,
        chargingKwh: 7.5,
      },
    },
    {
      idx: 10,
      info: {
        ticketId: 'TKT-1004',
        regNo: 'TN05EB2040',
        ownerName: 'Meera Iyer',
        category: 'EBike',
        userCategory: 'Student',
        entryTimeIso: new Date(now - 210 * 60 * 1000).toISOString(),
        passId: null,
        passType: 'None',
        chargingRequested: false,
        chargingKwh: 0,
      },
    },
    {
      idx: 12,
      info: {
        ticketId: 'TKT-1005',
        regNo: 'TN07DV7788',
        ownerName: 'Campus Logistics',
        category: 'DeliveryVan',
        userCategory: 'Visitor',
        entryTimeIso: new Date(now - 75 * 60 * 1000).toISOString(),
        passId: null,
        passType: 'None',
        chargingRequested: false,
        chargingKwh: 0,
      },
    },
    {
      idx: 25,
      info: {
        ticketId: 'TKT-1006',
        regNo: 'TN09ST5151',
        ownerName: 'Dr. Ramesh Kumar',
        category: 'Car',
        userCategory: 'Staff',
        entryTimeIso: new Date(now - 190 * 60 * 1000).toISOString(),
        passId: 'MP-STF-502',
        passType: 'StaffMonthly',
        chargingRequested: false,
        chargingKwh: 0,
      },
    },
  ];

  const registeredVehicles: RegisteredVehicle[] = [];
  for (const item of seededEntries) {
    if (slots[item.idx]) {
      slots[item.idx] = { ...slots[item.idx], occupied: true, vehicle: item.info };
      registeredVehicles.push({
        regNo: item.info.regNo,
        ownerName: item.info.ownerName,
        vehicleCategory: item.info.category,
        userCategory: item.info.userCategory,
        registeredAtIso: item.info.entryTimeIso,
      });
    }
  }

  return {
    floorCapacities: [...DEFAULT_FLOOR_CAPACITIES],
    slots,
    registeredVehicles,
    passes: initialPasses,
    transactions: [],
    rates: { ...DEFAULT_RATES },
    ticketSeq: 1007,
    passSeq: 504,
  };
}

export function registerVehicleInRegistry(
  registry: RegisteredVehicle[],
  regNoRaw: string,
  ownerNameRaw: string,
  vehicleCategory: VehicleCategory,
  userCategory: UserCategory
): { ok: true; record: RegisteredVehicle; nextRegistry: RegisteredVehicle[] } | { ok: false; error: string } {
  const regNo = normalizeRegNo(regNoRaw);
  if (!isValidRegNo(regNo)) {
    return {
      ok: false,
      error: 'Enter a valid registration number (4-15 alphanumeric/hyphen characters).',
    };
  }
  const ownerName = ownerNameRaw.trim();
  if (!ownerName) {
    return { ok: false, error: 'Owner name is required.' };
  }
  if (registry.some((v) => v.regNo === regNo)) {
    return { ok: false, error: `Duplicate registration number: ${regNo} is already registered.` };
  }
  const record: RegisteredVehicle = {
    regNo,
    ownerName,
    vehicleCategory,
    userCategory,
    registeredAtIso: new Date().toISOString(),
  };
  return { ok: true, record, nextRegistry: [record, ...registry] };
}

export function validatePassEligibility(
  pass: PassRecord | null | undefined,
  regNoRaw: string,
  userCategory: UserCategory,
  checkDateStr: string = todayDateString()
): { valid: true; pass: PassRecord } | { valid: false; reason: string } {
  if (!pass) {
    return { valid: false, reason: 'Pass ID not found.' };
  }
  if (!pass.active) {
    return { valid: false, reason: `Pass ${pass.passId} has been revoked.` };
  }
  if (checkDateStr > pass.validUntil) {
    return {
      valid: false,
      reason: `Pass ${pass.passId} expired on ${pass.validUntil}.`,
    };
  }
  const normalizedReg = normalizeRegNo(regNoRaw);
  if (pass.regNo && pass.regNo !== normalizedReg) {
    return {
      valid: false,
      reason: `Pass ${pass.passId} is registered to ${pass.regNo}, not ${normalizedReg}.`,
    };
  }
  if (pass.category === 'StudentMonthly' && userCategory !== 'Student') {
    return {
      valid: false,
      reason: `Student Monthly Pass ${pass.passId} requires Student user category.`,
    };
  }
  if (pass.category === 'StaffMonthly' && userCategory !== 'Staff') {
    return {
      valid: false,
      reason: `Staff Monthly Pass ${pass.passId} requires Staff user category.`,
    };
  }
  return { valid: true, pass };
}

export function allocateSlotForVehicle(
  slots: ParkingSlot[],
  vehicle: Omit<ParkedVehicleInfo, 'ticketId'>,
  ticketSeq: number,
  preferredSlotId?: string
):
  | {
      ok: true;
      allocatedSlot: ParkingSlot;
      nextSlots: ParkingSlot[];
      nextTicketSeq: number;
    }
  | { ok: false; error: string } {
  const regNo = normalizeRegNo(vehicle.regNo);
  if (!isValidRegNo(regNo)) {
    return { ok: false, error: 'Invalid registration number.' };
  }
  if (slots.some((s) => s.occupied && s.vehicle?.regNo === regNo)) {
    return { ok: false, error: `Vehicle ${regNo} is already parked inside the facility.` };
  }
  if (slots.some((s) => s.occupied && s.vehicle?.ticketId === `TKT-${ticketSeq}`)) {
    return { ok: false, error: 'Duplicate ticket sequence detected.' };
  }

  let target: ParkingSlot | undefined;
  if (preferredSlotId) {
    const requested = slots.find((s) => s.id === preferredSlotId);
    if (!requested) {
      return { ok: false, error: `Invalid slot number: ${preferredSlotId} does not exist.` };
    }
    if (requested.occupied) {
      return { ok: false, error: `Slot ${preferredSlotId} is already occupied.` };
    }
    target = requested;
  } else {
    target = slots.find((s) => !s.occupied);
  }

  if (!target) {
    return { ok: false, error: 'Parking facility is full. No available slots remain.' };
  }

  const parkedInfo: ParkedVehicleInfo = {
    ...vehicle,
    regNo,
    ticketId: `TKT-${ticketSeq}`,
  };

  const nextSlots = slots.map((s) =>
    s.id === target!.id ? { ...s, occupied: true, vehicle: parkedInfo } : s
  );
  const allocatedSlot = nextSlots.find((s) => s.id === target!.id)!;

  return {
    ok: true,
    allocatedSlot,
    nextSlots,
    nextTicketSeq: ticketSeq + 1,
  };
}

export interface FeeQuoteResult {
  ok: true;
  billedHours: number;
  durationMinutes: number;
  rawParkingFee: number;
  parkingFee: number;
  chargingKwh: number;
  chargingFee: number;
  totalFee: number;
  passNote: string;
}

export function calculateFeeQuote(
  vehicle: ParkedVehicleInfo,
  rates: PricingRates,
  options?: {
    exitTimeIso?: string;
    billedHoursOverride?: number;
    resolvedPass?: PassRecord | null;
    checkDateStr?: string;
    evKwhOverride?: number;
  }
): FeeQuoteResult | { ok: false; error: string } {
  const entryMs = new Date(vehicle.entryTimeIso).getTime();
  const exitIso = options?.exitTimeIso ?? new Date().toISOString();
  const exitMs = new Date(exitIso).getTime();

  if (Number.isNaN(entryMs) || Number.isNaN(exitMs)) {
    return { ok: false, error: 'Invalid entry or exit timestamp.' };
  }
  if (exitMs < entryMs) {
    return { ok: false, error: 'Negative parking duration is not allowed (exit precedes entry).' };
  }

  let durationMinutes = Math.round((exitMs - entryMs) / 60000);
  if (durationMinutes === 0) {
    durationMinutes = 1;
  }

  let billedHours: number;
  if (options?.billedHoursOverride !== undefined) {
    if (!Number.isFinite(options.billedHoursOverride) || options.billedHoursOverride <= 0) {
      return { ok: false, error: 'Parking duration must be greater than 0 hours.' };
    }
    billedHours = Math.ceil(options.billedHoursOverride);
    durationMinutes = billedHours * 60;
  } else {
    // Ceiling integer arithmetic: every started hour is charged in full
    billedHours = Math.floor((durationMinutes + 59) / 60);
  }

  let rawParkingFee = 0;
  if (vehicle.category === 'TwoWheeler') {
    rawParkingFee = billedHours * rates.twoWheelerPerHour;
  } else if (vehicle.category === 'Car') {
    rawParkingFee = billedHours * rates.carPerHour;
  } else if (vehicle.category === 'ElectricCar') {
    rawParkingFee = billedHours * rates.electricCarPerHour;
  } else if (vehicle.category === 'EBike') {
    rawParkingFee = rates.ebikeFlatFee;
  } else if (vehicle.category === 'DeliveryVan') {
    // Evaluate each started hour against the 09:00 - 17:00 peak window
    for (let i = 0; i < billedHours; i++) {
      const hourDate = new Date(entryMs + i * 3600 * 1000);
      const hr = hourDate.getHours();
      const isPeak = hr >= 9 && hr < 17;
      rawParkingFee += isPeak
        ? rates.carPerHour * rates.deliveryVanPeakMultiplier
        : rates.carPerHour;
    }
  }

  rawParkingFee = Math.min(rawParkingFee, rates.dailyMaxCap);

  const chargingKwh =
    vehicle.category === 'ElectricCar' && vehicle.chargingRequested
      ? Math.max(0, options?.evKwhOverride ?? vehicle.chargingKwh)
      : 0;
  const chargingFee = chargingKwh * rates.evChargingPerKwh;

  let parkingFee = rawParkingFee;
  let passNote = 'Standard Visitor Rate';

  if (options?.resolvedPass) {
    const checkDate = options.checkDateStr ?? exitIso.slice(0, 10);
    const validation = validatePassEligibility(
      options.resolvedPass,
      vehicle.regNo,
      vehicle.userCategory,
      checkDate
    );
    if (validation.valid) {
      parkingFee = 0;
      if (validation.pass.category === 'StudentMonthly') {
        passNote = `Student Monthly Pass (${validation.pass.passId}) - Free Parking`;
      } else if (validation.pass.category === 'StaffMonthly') {
        passNote = `Staff Monthly Pass (${validation.pass.passId}) - Free Parking`;
      } else {
        passNote = `Visitor One-Day Pass (${validation.pass.passId}) - Covered`;
      }
    } else {
      passNote = `Invalid Pass Rejected (${validation.reason}) - Standard Rate`;
    }
  }

  return {
    ok: true,
    billedHours,
    durationMinutes,
    rawParkingFee,
    parkingFee,
    chargingKwh,
    chargingFee,
    totalFee: parkingFee + chargingFee,
    passNote,
  };
}

export function findActiveSlotByRegOrTicket(
  slots: ParkingSlot[],
  queryRaw: string
): ParkingSlot | undefined {
  const q = queryRaw.trim().toUpperCase().replace(/\s+/g, '');
  if (!q) {
    return undefined;
  }
  return slots.find(
    (s) =>
      s.occupied &&
      s.vehicle &&
      (s.vehicle.regNo.toUpperCase() === q || s.vehicle.ticketId.toUpperCase() === q)
  );
}

export function computeReportsSummary(state: PersistedParkingState) {
  const totalCapacity = state.slots.length;
  const occupiedSlots = state.slots.filter((s) => s.occupied).length;
  const availableSlots = totalCapacity - occupiedSlots;

  const parkingFeeCollection = state.transactions.reduce((sum, t) => sum + t.parkingFee, 0);
  const evChargingCollection = state.transactions.reduce((sum, t) => sum + t.chargingFee, 0);
  const monthlyPassRevenue = state.passes
    .filter((p) => p.category === 'StudentMonthly' || p.category === 'StaffMonthly')
    .reduce((sum, p) => sum + p.purchasePrice, 0);
  const oneDayPassRevenue = state.passes
    .filter((p) => p.category === 'VisitorOneDay')
    .reduce((sum, p) => sum + p.purchasePrice, 0);

  const totalParkingCollection =
    parkingFeeCollection + evChargingCollection + monthlyPassRevenue + oneDayPassRevenue;

  return {
    totalCapacity,
    occupiedSlots,
    availableSlots,
    occupancyPct: totalCapacity > 0 ? Math.round((occupiedSlots / totalCapacity) * 100) : 0,
    parkingFeeCollection,
    evChargingCollection,
    monthlyPassRevenue,
    oneDayPassRevenue,
    totalParkingCollection,
  };
}

export interface StorageLike {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export function savePersistedState(
  state: PersistedParkingState,
  storage: StorageLike | undefined = typeof window !== 'undefined' ? window.localStorage : undefined
): void {
  if (!storage) return;
  try {
    storage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadPersistedState(
  storage: StorageLike | undefined = typeof window !== 'undefined' ? window.localStorage : undefined
): PersistedParkingState {
  if (!storage) {
    return createInitialParkingState();
  }
  try {
    const raw = storage.getItem(STORAGE_KEY);
    if (!raw) {
      return createInitialParkingState();
    }
    const parsed = JSON.parse(raw) as Partial<PersistedParkingState>;
    if (!Array.isArray(parsed.slots) || !Array.isArray(parsed.floorCapacities) || !parsed.rates) {
      return createInitialParkingState();
    }
    return {
      floorCapacities: parsed.floorCapacities,
      slots: parsed.slots,
      registeredVehicles: Array.isArray(parsed.registeredVehicles) ? parsed.registeredVehicles : [],
      passes: Array.isArray(parsed.passes) ? parsed.passes : [],
      transactions: Array.isArray(parsed.transactions) ? parsed.transactions : [],
      rates: { ...DEFAULT_RATES, ...parsed.rates },
      ticketSeq: typeof parsed.ticketSeq === 'number' ? parsed.ticketSeq : 1007,
      passSeq: typeof parsed.passSeq === 'number' ? parsed.passSeq : 504,
    };
  } catch {
    return createInitialParkingState();
  }
}

export function clearPersistedState(
  storage: StorageLike | undefined = typeof window !== 'undefined' ? window.localStorage : undefined
): PersistedParkingState {
  if (storage) {
    storage.removeItem(STORAGE_KEY);
  }
  return createInitialParkingState();
}
