import java.util.Arrays;

/**
 * TASK 3 - Mandatory ParkingFacility Program.
 * Preserves the assignment's main() method and implements allocate() and release()
 * using a jagged boolean[][] matrix.
 *
 * Expected Exact Output:
 * [0, 0]
 * [0, 1]
 * [1, 0]
 * null
 * true false false
 * [0, 1]
 */
public class ParkingFacility {

    private final boolean[][] slots;

    public ParkingFacility(int[] floorCapacities) {
        if (floorCapacities == null || floorCapacities.length == 0) {
            throw new IllegalArgumentException("Floor capacities must not be empty.");
        }
        this.slots = new boolean[floorCapacities.length][];
        for (int f = 0; f < floorCapacities.length; f++) {
            this.slots[f] = new boolean[floorCapacities[f]];
        }
    }

    /**
     * Finds the first free slot across floors and marks it occupied.
     *
     * @return int[]{floorIndex, slotIndex} or null if all slots are occupied
     */
    public int[] allocate() {
        for (int f = 0; f < slots.length; f++) {
            for (int s = 0; s < slots[f].length; s++) {
                if (!slots[f][s]) {
                    slots[f][s] = true;
                    return new int[]{f, s};
                }
            }
        }
        return null;
    }

    /**
     * Releases the specified slot if coordinates are valid and currently occupied.
     *
     * @param floor 0-based floor index
     * @param slot  0-based slot index
     * @return true if released successfully, false if out of bounds or already free
     */
    public boolean release(int floor, int slot) {
        if (floor < 0 || floor >= slots.length) {
            return false;
        }
        if (slot < 0 || slot >= slots[floor].length) {
            return false;
        }
        if (!slots[floor][slot]) {
            return false;
        }
        slots[floor][slot] = false;
        return true;
    }

    public static void main(String[] args) {
        ParkingFacility facility = new ParkingFacility(new int[]{2, 1});
        System.out.println(Arrays.toString(facility.allocate()));
        System.out.println(Arrays.toString(facility.allocate()));
        System.out.println(Arrays.toString(facility.allocate()));
        System.out.println(Arrays.toString(facility.allocate()));
        System.out.println(
                facility.release(0, 1) + " " +
                facility.release(0, 1) + " " +
                facility.release(2, 0)
        );
        System.out.println(Arrays.toString(facility.allocate()));
    }
}
