package assignment_3;


import java.io.*;

public class Q3SalesReport {

    static String[] files = {
        "store1.txt", "store2.txt", "missing.txt", "store3.txt"
    };

    static void createFiles() throws IOException {
        FileWriter f1 = new FileWriter("store1.txt");
        f1.write("Store 1 Sales: 5000\n");
        f1.close();

        FileWriter f2 = new FileWriter("store2.txt");
        f2.write("Store 2 Sales: 7000\n");
        f2.close();

        FileWriter f3 = new FileWriter("store3.txt");
        f3.write("Store 3 Sales: 6000\n");
        f3.close();
    }

    // Method 1: Manual close using finally
    static void manualReport() {
        BufferedWriter writer = null;

        try {
            writer = new BufferedWriter(
                new FileWriter("manual_report.txt")
            );

            for (String file : files) {
                BufferedReader reader = null;

                try {
                    reader = new BufferedReader(
                        new FileReader(file)
                    );

                    String line;

                    while ((line = reader.readLine()) != null) {
                        writer.write(line);
                        writer.newLine();
                    }

                } catch (IOException e) {
                    System.out.println("Manual Error: " + file);
                    writer.write("Unable to read: " + file);
                    writer.newLine();

                } finally {
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            System.out.println("Reader close error");
                        }
                    }
                }
            }

        } catch (IOException e) {
            System.out.println("Report Error: " + e.getMessage());

        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    System.out.println("Writer close error");
                }
            }
        }

        System.out.println("Manual report completed.");
    }

    // Method 2: Automatic close using try-with-resources
    static void automaticReport() {

        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter("automatic_report.txt"))) {

            for (String file : files) {

                try (BufferedReader reader = new BufferedReader(
                        new FileReader(file))) {

                    String line;

                    while ((line = reader.readLine()) != null) {
                        writer.write(line);
                        writer.newLine();
                    }

                } catch (IOException e) {
                    System.out.println("Automatic Error: " + file);
                    writer.write("Unable to read: " + file);
                    writer.newLine();
                }
            }

        } catch (IOException e) {
            System.out.println("Report Error: " + e.getMessage());
        }

        System.out.println("Automatic report completed.");
    }

    public static void main(String[] args) {

        try {
            createFiles();

            manualReport();
            automaticReport();

        } catch (IOException e) {
            System.out.println("File creation error: " + e.getMessage());
        }
    }
}
