package Q1;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.StringJoiner;

/**
 * Q1 - String, StringBuilder, and StringBuffer Benchmark
 * Problem: Railway E-Ticket Generation
 *
 * Compares String (+), StringBuilder, and StringBuffer across:
 *   1. Short Ticket (1 ticket, 8 core fields)
 *   2. Heavy Batch Workload (10,000 tickets, 50 fields each)
 *   3. Additional Workload: Consolidated Reservation Chart (3,000 entries into one String)
 *
 * Also demonstrates String.join(), StringJoiner, and String.format(),
 * estimates intermediate String objects and approximate heap usage,
 * and writes raw measurements to ExperimentalData/Q1_StringBenchmark.csv.
 */
public class StringBenchmark {

    private static final int WARMUP_RUNS = 3;
    private static final int MEASURED_RUNS = 5;

    private static final String[] SAMPLE_PASSENGERS = {
        "Aarav Sharma", "Diya Nair", "Rohan Verma", "Meera Krishnan", "Karthik Iyer"
    };
    private static final String[] SAMPLE_COACHES = {"B1", "B2", "B4", "A1", "S5"};
    private static final String[] SAMPLE_BERTHS = {"LB-12", "UB-24", "MB-19", "SL-07", "SU-32"};

    // Checksum sink to prevent JVM dead-code elimination
    private static volatile long blackhole = 0;

    public static void validateTicketInputs(String pnr, String name, double fare) {
        if (pnr == null || pnr.isBlank()) {
            throw new IllegalArgumentException("PNR must not be null or blank.");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Passenger name must not be null or blank.");
        }
        if (fare < 0.0) {
            throw new IllegalArgumentException("Fare cannot be negative: " + fare);
        }
    }

    // -------------------------------------------------------------------------
    // 1. Short Ticket Builders (PNR, Name, Coach, Berth, Fare, Journey Details)
    // -------------------------------------------------------------------------

    public static String buildShortTicketWithString(
            String pnr, String name, String coach, String berth,
            double fare, String trainNo, String route, String date) {
        validateTicketInputs(pnr, name, fare);
        String ticket = "";
        ticket = ticket + "PNR:" + pnr + "|";
        ticket = ticket + "Passenger:" + name + "|";
        ticket = ticket + "Train:" + trainNo + "|";
        ticket = ticket + "Route:" + route + "|";
        ticket = ticket + "Date:" + date + "|";
        ticket = ticket + "Coach:" + coach + "|";
        ticket = ticket + "Berth:" + berth + "|";
        ticket = ticket + "Fare:INR " + String.format(Locale.US, "%.2f", fare);
        return ticket;
    }

    public static String buildShortTicketWithStringBuilder(
            String pnr, String name, String coach, String berth,
            double fare, String trainNo, String route, String date) {
        StringBuilder sb = new StringBuilder(160);
        sb.append("PNR:").append(pnr).append('|');
        sb.append("Passenger:").append(name).append('|');
        sb.append("Train:").append(trainNo).append('|');
        sb.append("Route:").append(route).append('|');
        sb.append("Date:").append(date).append('|');
        sb.append("Coach:").append(coach).append('|');
        sb.append("Berth:").append(berth).append('|');
        sb.append("Fare:INR ").append(String.format(Locale.US, "%.2f", fare));
        return sb.toString();
    }

    public static String buildShortTicketWithStringBuffer(
            String pnr, String name, String coach, String berth,
            double fare, String trainNo, String route, String date) {
        StringBuffer sbf = new StringBuffer(160);
        sbf.append("PNR:").append(pnr).append('|');
        sbf.append("Passenger:").append(name).append('|');
        sbf.append("Train:").append(trainNo).append('|');
        sbf.append("Route:").append(route).append('|');
        sbf.append("Date:").append(date).append('|');
        sbf.append("Coach:").append(coach).append('|');
        sbf.append("Berth:").append(berth).append('|');
        sbf.append("Fare:INR ").append(String.format(Locale.US, "%.2f", fare));
        return sbf.toString();
    }

    // -------------------------------------------------------------------------
    // 2. Heavy Workload: 10,000 Tickets with 50 Fields Each
    // -------------------------------------------------------------------------

    private static long generateTicketsWithString(int ticketCount, int fieldsPerTicket) {
        long checksum = 0;
        for (int t = 0; t < ticketCount; t++) {
            String ticket = "PNR=" + (4100000000L + t);
            for (int f = 1; f < fieldsPerTicket; f++) {
                ticket = ticket + ";F" + f + "=" + getFieldValue(t, f);
            }
            checksum += ticket.length();
        }
        return checksum;
    }

    private static long generateTicketsWithStringBuilder(int ticketCount, int fieldsPerTicket) {
        long checksum = 0;
        for (int t = 0; t < ticketCount; t++) {
            StringBuilder sb = new StringBuilder(fieldsPerTicket * 18);
            sb.append("PNR=").append(4100000000L + t);
            for (int f = 1; f < fieldsPerTicket; f++) {
                sb.append(";F").append(f).append('=').append(getFieldValue(t, f));
            }
            checksum += sb.toString().length();
        }
        return checksum;
    }

    private static long generateTicketsWithStringBuffer(int ticketCount, int fieldsPerTicket) {
        long checksum = 0;
        for (int t = 0; t < ticketCount; t++) {
            StringBuffer sbf = new StringBuffer(fieldsPerTicket * 18);
            sbf.append("PNR=").append(4100000000L + t);
            for (int f = 1; f < fieldsPerTicket; f++) {
                sbf.append(";F").append(f).append('=').append(getFieldValue(t, f));
            }
            checksum += sbf.toString().length();
        }
        return checksum;
    }

    // -------------------------------------------------------------------------
    // 3. Additional Workload: Consolidated Reservation Chart (Single Large String)
    // -------------------------------------------------------------------------

    private static long buildChartWithString(int entryCount) {
        String chart = "=== RESERVATION CHART ===\n";
        for (int i = 0; i < entryCount; i++) {
            chart = chart + "PNR:" + (4500000000L + i)
                    + ",Name:" + SAMPLE_PASSENGERS[i % SAMPLE_PASSENGERS.length]
                    + ",Coach:" + SAMPLE_COACHES[i % SAMPLE_COACHES.length]
                    + ",Berth:" + SAMPLE_BERTHS[i % SAMPLE_BERTHS.length]
                    + ",Fare:1450.00\n";
        }
        return chart.length();
    }

    private static long buildChartWithStringBuilder(int entryCount) {
        StringBuilder chart = new StringBuilder(entryCount * 72 + 32);
        chart.append("=== RESERVATION CHART ===\n");
        for (int i = 0; i < entryCount; i++) {
            chart.append("PNR:").append(4500000000L + i)
                 .append(",Name:").append(SAMPLE_PASSENGERS[i % SAMPLE_PASSENGERS.length])
                 .append(",Coach:").append(SAMPLE_COACHES[i % SAMPLE_COACHES.length])
                 .append(",Berth:").append(SAMPLE_BERTHS[i % SAMPLE_BERTHS.length])
                 .append(",Fare:1450.00\n");
        }
        return chart.length();
    }

    private static long buildChartWithStringBuffer(int entryCount) {
        StringBuffer chart = new StringBuffer(entryCount * 72 + 32);
        chart.append("=== RESERVATION CHART ===\n");
        for (int i = 0; i < entryCount; i++) {
            chart.append("PNR:").append(4500000000L + i)
                 .append(",Name:").append(SAMPLE_PASSENGERS[i % SAMPLE_PASSENGERS.length])
                 .append(",Coach:").append(SAMPLE_COACHES[i % SAMPLE_COACHES.length])
                 .append(",Berth:").append(SAMPLE_BERTHS[i % SAMPLE_BERTHS.length])
                 .append(",Fare:1450.00\n");
        }
        return chart.length();
    }

    private static String getFieldValue(int ticketIndex, int fieldIndex) {
        return switch (fieldIndex % 5) {
            case 0 -> SAMPLE_PASSENGERS[ticketIndex % SAMPLE_PASSENGERS.length];
            case 1 -> SAMPLE_COACHES[ticketIndex % SAMPLE_COACHES.length];
            case 2 -> SAMPLE_BERTHS[ticketIndex % SAMPLE_BERTHS.length];
            case 3 -> "MAS-SBC";
            default -> "1450.00";
        };
    }

    // -------------------------------------------------------------------------
    // Helper Methods: Timing, Memory Approximation, Object Estimation, CSV
    // -------------------------------------------------------------------------

    @FunctionalInterface
    interface WorkloadTask {
        long run();
    }

    record BenchmarkRow(
            String workload,
            String approach,
            int iteration,
            long elapsedNanos,
            double elapsedMillis,
            long approxMemoryBytes,
            long estimatedIntermediateStrings,
            long checksum
    ) {}

    private static long getUsedMemoryBytes() {
        Runtime rt = Runtime.getRuntime();
        return rt.totalMemory() - rt.freeMemory();
    }

    private static List<BenchmarkRow> runBenchmark(
            String workloadName,
            String approachName,
            long estimatedIntermediateStrings,
            WorkloadTask task) {

        // Warmup runs to allow JIT compilation
        for (int w = 0; w < WARMUP_RUNS; w++) {
            blackhole += task.run();
        }

        List<BenchmarkRow> rows = new ArrayList<>();
        for (int i = 1; i <= MEASURED_RUNS; i++) {
            System.gc();
            try {
                Thread.sleep(20);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }

            long memBefore = getUsedMemoryBytes();
            long start = System.nanoTime();
            long checksum = task.run();
            long end = System.nanoTime();
            long memAfter = getUsedMemoryBytes();

            blackhole += checksum;
            long elapsedNanos = end - start;
            double elapsedMillis = elapsedNanos / 1_000_000.0;
            long approxMem = Math.max(0L, memAfter - memBefore);

            rows.add(new BenchmarkRow(
                    workloadName,
                    approachName,
                    i,
                    elapsedNanos,
                    elapsedMillis,
                    approxMem,
                    estimatedIntermediateStrings,
                    checksum
            ));
        }
        return rows;
    }

    private static void printSummary(String workloadName, String approach, List<BenchmarkRow> rows) {
        double avgMs = rows.stream().mapToDouble(BenchmarkRow::elapsedMillis).average().orElse(0.0);
        long avgNs = Math.round(rows.stream().mapToLong(BenchmarkRow::elapsedNanos).average().orElse(0.0));
        long avgMemKb = Math.round(rows.stream().mapToLong(BenchmarkRow::approxMemoryBytes).average().orElse(0.0) / 1024.0);
        long estObjects = rows.isEmpty() ? 0 : rows.get(0).estimatedIntermediateStrings();

        System.out.printf(Locale.US,
                "%-34s | %-13s | %12d ns | %9.3f ms | %8d KB | %12d%n",
                workloadName, approach, avgNs, avgMs, avgMemKb, estObjects);
    }

    private static void demonstrateFormattingUtilities() {
        System.out.println("\n--- Alternative Formatting Utilities (Short Ticket) ---");
        String joined = String.join(" | ",
                "PNR:4123456789", "Passenger:Aarav Sharma", "Train:12609",
                "Route:MAS-SBC", "Date:2026-11-20", "Coach:B2", "Berth:LB-12", "Fare:INR 1450.00");

        StringJoiner joiner = new StringJoiner(" | ", "[", "]");
        joiner.add("PNR:4123456789")
              .add("Passenger:Aarav Sharma")
              .add("Coach:B2")
              .add("Berth:LB-12")
              .add("Fare:INR 1450.00");

        String formatted = String.format(Locale.US,
                "PNR:%s | Passenger:%s | Train:%s | Route:%s | Coach:%s | Berth:%s | Fare:INR %.2f",
                "4123456789", "Aarav Sharma", "12609", "MAS-SBC", "B2", "LB-12", 1450.00);

        System.out.println("String.join()  : " + joined);
        System.out.println("StringJoiner   : " + joiner);
        System.out.println("String.format(): " + formatted);
    }

    private static Path resolveCsvPath(String fileName) throws IOException {
        Path direct = Path.of("ExperimentalData");
        Path nested = Path.of("CSA09-Assignment2", "ExperimentalData");
        Path dir = Files.exists(direct) ? direct : (Files.exists(nested) ? nested : direct);
        Files.createDirectories(dir);
        return dir.resolve(fileName);
    }

    private static void writeCsv(List<BenchmarkRow> allRows, Path csvPath) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(csvPath)) {
            writer.write("Workload,Approach,Iteration,ElapsedNanos,ElapsedMillis,ApproxMemoryBytes,EstimatedIntermediateStrings,Checksum\n");
            for (BenchmarkRow row : allRows) {
                writer.write(String.format(Locale.US,
                        "%s,%s,%d,%d,%.4f,%d,%d,%d%n",
                        row.workload(),
                        row.approach(),
                        row.iteration(),
                        row.elapsedNanos(),
                        row.elapsedMillis(),
                        row.approxMemoryBytes(),
                        row.estimatedIntermediateStrings(),
                        row.checksum()));
            }
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println("==========================================================================");
        System.out.println("Q1: Railway E-Ticket Generation - String vs StringBuilder vs StringBuffer");
        System.out.println("==========================================================================");

        // 1. Short Ticket Verification
        String t1 = buildShortTicketWithString("4123456789", "Aarav Sharma", "B2", "LB-12", 1450.0, "12609", "MAS-SBC", "2026-11-20");
        String t2 = buildShortTicketWithStringBuilder("4123456789", "Aarav Sharma", "B2", "LB-12", 1450.0, "12609", "MAS-SBC", "2026-11-20");
        String t3 = buildShortTicketWithStringBuffer("4123456789", "Aarav Sharma", "B2", "LB-12", 1450.0, "12609", "MAS-SBC", "2026-11-20");

        System.out.println("Sample Short Ticket: " + t1);
        System.out.println("All 3 implementations produce identical output: " + (t1.equals(t2) && t2.equals(t3)));

        demonstrateFormattingUtilities();

        List<BenchmarkRow> allRows = new ArrayList<>();

        System.out.println("\nRunning benchmarks (" + WARMUP_RUNS + " warmup, " + MEASURED_RUNS + " measured iterations)...");
        System.out.printf("%-34s | %-13s | %-15s | %-12s | %-11s | %-12s%n",
                "Workload", "Approach", "Avg Time (ns)", "Avg Time(ms)", "Approx Mem", "Est. Int Str");
        System.out.println("-".repeat(108));

        // Workload 1: Single Short Ticket (8 fields)
        List<BenchmarkRow> w1Str = runBenchmark("ShortTicket_1x8Fields", "String(+)", 15L,
                () -> buildShortTicketWithString("4123456789", "Aarav Sharma", "B2", "LB-12", 1450.0, "12609", "MAS-SBC", "2026-11-20").length());
        List<BenchmarkRow> w1Sb = runBenchmark("ShortTicket_1x8Fields", "StringBuilder", 1L,
                () -> buildShortTicketWithStringBuilder("4123456789", "Aarav Sharma", "B2", "LB-12", 1450.0, "12609", "MAS-SBC", "2026-11-20").length());
        List<BenchmarkRow> w1Sbf = runBenchmark("ShortTicket_1x8Fields", "StringBuffer", 1L,
                () -> buildShortTicketWithStringBuffer("4123456789", "Aarav Sharma", "B2", "LB-12", 1450.0, "12609", "MAS-SBC", "2026-11-20").length());

        allRows.addAll(w1Str);
        allRows.addAll(w1Sb);
        allRows.addAll(w1Sbf);
        printSummary("ShortTicket_1x8Fields", "String(+)", w1Str);
        printSummary("ShortTicket_1x8Fields", "StringBuilder", w1Sb);
        printSummary("ShortTicket_1x8Fields", "StringBuffer", w1Sbf);

        // Workload 2: 10,000 Tickets with 50 Fields Each
        int ticketCount = 10_000;
        int fieldsPerTicket = 50;
        long estStringObjsW2 = (long) ticketCount * (fieldsPerTicket - 1);
        long estBuilderObjsW2 = ticketCount; // 1 final String per ticket

        List<BenchmarkRow> w2Str = runBenchmark("BatchTickets_10000x50Fields", "String(+)", estStringObjsW2,
                () -> generateTicketsWithString(ticketCount, fieldsPerTicket));
        List<BenchmarkRow> w2Sb = runBenchmark("BatchTickets_10000x50Fields", "StringBuilder", estBuilderObjsW2,
                () -> generateTicketsWithStringBuilder(ticketCount, fieldsPerTicket));
        List<BenchmarkRow> w2Sbf = runBenchmark("BatchTickets_10000x50Fields", "StringBuffer", estBuilderObjsW2,
                () -> generateTicketsWithStringBuffer(ticketCount, fieldsPerTicket));

        allRows.addAll(w2Str);
        allRows.addAll(w2Sb);
        allRows.addAll(w2Sbf);
        printSummary("BatchTickets_10000x50Fields", "String(+)", w2Str);
        printSummary("BatchTickets_10000x50Fields", "StringBuilder", w2Sb);
        printSummary("BatchTickets_10000x50Fields", "StringBuffer", w2Sbf);

        // Workload 3 (Additional): Consolidated Reservation Chart (3,000 entries into 1 String)
        int chartEntries = 3_000;
        List<BenchmarkRow> w3Str = runBenchmark("ReservationChart_3000Entries", "String(+)", chartEntries,
                () -> buildChartWithString(chartEntries));
        List<BenchmarkRow> w3Sb = runBenchmark("ReservationChart_3000Entries", "StringBuilder", 1L,
                () -> buildChartWithStringBuilder(chartEntries));
        List<BenchmarkRow> w3Sbf = runBenchmark("ReservationChart_3000Entries", "StringBuffer", 1L,
                () -> buildChartWithStringBuffer(chartEntries));

        allRows.addAll(w3Str);
        allRows.addAll(w3Sb);
        allRows.addAll(w3Sbf);
        printSummary("ReservationChart_3000Entries", "String(+)", w3Str);
        printSummary("ReservationChart_3000Entries", "StringBuilder", w3Sb);
        printSummary("ReservationChart_3000Entries", "StringBuffer", w3Sbf);

        Path csvPath = resolveCsvPath("Q1_StringBenchmark.csv");
        writeCsv(allRows, csvPath);
        System.out.println("\nSaved raw benchmark measurements to: " + csvPath.toAbsolutePath());
        System.out.println("Blackhole checksum: " + blackhole);
    }
}
