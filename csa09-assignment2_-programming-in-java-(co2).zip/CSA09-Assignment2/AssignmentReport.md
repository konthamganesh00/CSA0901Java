# PROGRAMMING IN JAVA – ASSIGNMENT 2 (CO2)
## Technical Assignment Report

---

## Cover Page & Student Details

| Field | Details |
|---|---|
| **Course Code & Title** | CSA09 – Programming in Java (CO2) |
| **Assignment Title** | Assignment 2: Strings, Collections Framework, Generics, Comparators, Priority Queues, and Performance Redesign |
| **Maximum Marks** | 50 Marks |
| **Student Name** | `[YOUR NAME HERE]` |
| **Register Number** | `[YOUR REGISTER NUMBER HERE]` |
| **Department / Year** | `[DEPARTMENT, B.Tech II Year]` |
| **Faculty Name** | `[FACULTY NAME HERE]` |
| **GitHub Repository** | `[GITHUB REPOSITORY LINK HERE]` |
| **Software Requirements** | Java 21 (LTS), Eclipse IDE, Standard JDK (`java.util`, `java.io`, `java.nio.file`) |

---

## 1. Introduction
Efficient Java software depends on selecting the right string-handling abstraction and collection data structure for each workload. Concatenating immutable `String` objects inside large loops, inserting at index `0` of an `ArrayList`, or omitting `hashCode()` when overriding `equals()` causes correctness failures and quadratic $O(n^2)$ execution bottlenecks.

This report documents seven Java 21 console modules (`Q1`–`Q7`) covering Railway E-Ticket generation, Music Playlist editing, College Event Attendance de-duplication, Hospital Pharmacy inventory indexing, Inter-College Sports Leaderboard ranking, Hospital Emergency Triage scheduling, and an empirical Day-4 Performance Redesign challenge.

---

## 2. Objectives
1. Compare `String`, `StringBuilder`, and `StringBuffer` across immutability, thread safety, intermediate allocations, and latency.
2. Benchmark `ArrayList`, `LinkedList`, and `ArrayDeque` on positional insertions, removals, random access, and sequential traversal.
3. Apply the `equals()` and `hashCode()` contract correctly in `HashSet` and compare against `TreeSet` and `HashMap`.
4. Evaluate `HashMap`, `TreeMap`, `LinkedHashMap`, and `Arrays.binarySearch()` for pharmacy inventory operations.
5. Design a type-safe generic `Leaderboard<T>` using `Comparable`, chained `Comparator`s, wildcards, and bounded type parameters.
6. Build a fair emergency triage queue using `PriorityQueue`, `arrivalSeq` tie-breaking, and priority-aging analysis.
7. Diagnose a measured bottleneck using Q1 evidence and validate an $O(k)$ redesign through controlled A/B benchmarking.

---

## 3. Question-Wise Implementation

### Q1 – String, StringBuilder, and StringBuffer (`src/Q1/`)
- **Classes:** `Q1.Main`, `Q1.StringBenchmark`
- **Implementation:** Generates railway tickets (`PNR`, passenger name, train, route, date, coach, berth, fare) using `String (+)`, `StringBuilder`, and `StringBuffer`. Demonstrates `String.join()`, `StringJoiner`, and `String.format()`, validates non-blank PNR/name and non-negative fare, and benchmarks 3 workloads (short ticket, `10,000 × 50`-field batch, and `3,000`-entry consolidated chart).
- **Screenshot Placeholder:**
  `![Q1 Console Output](Screenshots/Q1_StringBenchmark_Console.png)`

### Q2 – ArrayList, LinkedList, and ArrayDeque (`src/Q2/`)
- **Classes:** `Q2.Main`, `Q2.PlaylistBenchmark`
- **Implementation:** Compares `ArrayList`, `LinkedList`, and `ArrayDeque` on end append, front insert/remove, middle insert/remove, `k`-th random access, and full iteration across `1,000`, `10,000`, and `50,000` songs. Includes plain `String[]` manual-shifting code, an `ArrayDeque` "Up Next" queue demo, and boundary/index tests.
- **Screenshot Placeholder:**
  `![Q2 Console Output](Screenshots/Q2_PlaylistBenchmark_Console.png)`

### Q3 – `hashCode()` and `equals()` (`src/Q3/`)
- **Classes:** `Q3.Main`, `Q3.Student`, `Q3.Attendance`, `Q3.HashSetExperiment`
- **Implementation:** `Student` overrides `equals(Object)` and `hashCode()` based on `regNo`. `Attendance.main()` deduplicates three check-in entries to output `Unique students: 2`. `HashSetExperiment` contrasts a broken class without `hashCode()`, the fixed `Student` class, mutating `regNo` after insertion, `TreeSet`, and `HashMap`.
- **Screenshot Placeholder:**
  `![Q3 Console Output](Screenshots/Q3_Attendance_Console.png)`

### Q4 – HashMap, TreeMap, and LinkedHashMap (`src/Q4/`)
- **Classes:** `Q4.Main`, `Q4.Medicine`, `Q4.PharmacyInventory`, `Q4.MapBenchmark`
- **Implementation:** Implements add, search by code, quantity update, delete, sorted code-order display (`TreeMap`), and insertion-order display (`LinkedHashMap`), with negative quantity/price validation and `Arrays.binarySearch()` comparison across `1,000`, `10,000`, and `50,000` medicines.
- **Screenshot Placeholder:**
  `![Q4 Console Output](Screenshots/Q4_PharmacyInventory_Console.png)`

### Q5 – Generics, Comparable, and Comparator (`src/Q5/`)
- **Classes:** `Q5.Main`, `Q5.Team`, `Q5.Leaderboard`, `Q5.LeaderboardDemo`
- **Implementation:** `Leaderboard<T>` supports `addAll(List<? extends T>)`, `sortWith(Comparator<? super T>)`, `copyStandingsTo(List<? super T>)`, and `<U extends Comparable<? super U>>`. `LeaderboardDemo` chains `Comparator.comparingInt(Team::getPoints).thenComparingInt(Team::getGoalDifference).reversed().thenComparing(Team::getName)` to produce `[Eagles(9,6), Bisons(9,4), Panthers(9,4), Cobras(6,1)]`, explains why `Bisons` ranks above `Panthers`, and tests multi-pass TimSort stability and `TreeSet` consistency.
- **Screenshot Placeholder:**
  `![Q5 Console Output](Screenshots/Q5_LeaderboardDemo_Console.png)`

### Q6 – Queue and PriorityQueue (`src/Q6/`)
- **Classes:** `Q6.Main`, `Q6.Patient`, `Q6.Triage`, `Q6.TriageBenchmark`
- **Implementation:** `Triage` orders `Patient` records via `TRIAGE_COMPARATOR` (`severity` `1`–`5` ascending, then `arrivalSeq` ascending) producing `Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)`. Tests an 8-patient scenario, invalid severities (`0`, `6`), priority aging, and benchmarks `PriorityQueue`, sorted `LinkedList`, and 5 FIFO `ArrayDeque` buckets across `1,000`, `10,000`, and `50,000` patients.
- **Screenshot Placeholder:**
  `![Q6 Console Output](Screenshots/Q6_Triage_Console.png)`

### Q7 – Day-4 Design Challenge (`src/Q7/`)
- **Classes & Docs:** `Q7.Main`, `Q7.RedesignComparison`, `src/Q7/DesignChallenge.md`
- **Implementation:** Diagnoses Q1's quadratic `String (+)` concatenation bottleneck and redesigns ticket/chart generation using a pre-sized `StringBuilder` (`fieldCount * 18` / `32 + entryCount * 72`). Verifies byte-for-byte equivalence (`Original.equals(Redesigned)`) and benchmarks `Batch_1000x50`, `Batch_10000x50`, and `Chart_3000Entries`.
- **Screenshot Placeholder:**
  `![Q7 Console Output](Screenshots/Q7_RedesignComparison_Console.png)`

---

## 4. Algorithms and Complexity Analysis

### Pseudocode: Capacity-Tuned Ticket & Chart Builder (Q1 / Q7)
```text
ALGORITHM BuildChartRedesigned(entryCount)
    IF entryCount < 0 THEN THROW IllegalArgumentException
    estimatedCapacity <- 32 + entryCount * 72
    buffer <- NEW StringBuilder(estimatedCapacity)
    buffer.append("=== RESERVATION CHART ===\n")
    FOR i <- 0 TO entryCount - 1 DO
        buffer.append("PNR:").append(4500000000 + i)
              .append(",Name:").append(PASSENGERS[i mod len])
              .append(",Coach:").append(COACHES[i mod len])
              .append(",Berth:").append(BERTHS[i mod len])
              .append(",Fare:1450.00\n")
    END FOR
    RETURN buffer.toString()
END ALGORITHM
```

### Pseudocode: Chained Sports Ranking Comparator (Q5)
```text
ALGORITHM RankTeams(teams)
    cmp <- Comparator.comparingInt(Team.points)
                     .thenComparingInt(Team.goalDifference)
                     .reversed()
                     .thenComparing(Team.name)
    teams.sort(cmp)
    RETURN teams
END ALGORITHM
```

### Pseudocode: Fair Emergency Triage Queue (Q6)
```text
ALGORITHM AdmitAndTreat(triageQueue, name, severity, arrivalCounter)
    patient <- NEW Patient(name, severity, arrivalCounter)
    arrivalCounter <- arrivalCounter + 1
    triageQueue.offer(patient)   // O(log n) min-heap sift-up
    next <- triageQueue.poll()   // O(log n) min-heap sift-down
    RETURN next
END ALGORITHM
```

---

## 5. Benchmark Methodology
All benchmarks (`Q1`, `Q2`, `Q4`, `Q6`, `Q7`) follow a consistent measurement protocol:
1. **Identical Deterministic Inputs:** Every competing structure/algorithm receives the exact same pre-generated input arrays and seeded random lookup keys (`Random` with fixed seeds).
2. **JIT Warmup:** `1`–`3` unmeasured warmup runs allow HotSpot C1/C2 JIT compilation before timing begins.
3. **Repeated Timing (`System.nanoTime()`):** `3`–`5` measured iterations per workload compute average execution time in nanoseconds and milliseconds.
4. **Dead-Code Prevention:** Output lengths/sums accumulate into a `volatile long blackhole` sink so the JIT compiler cannot optimize away work.
5. **Raw CSV Logging:** Per-iteration timings are written directly to `ExperimentalData/*.csv` without any pre-populated or invented values.

---

## 6. Actual Results and Observations

> **Important Separation Notice:** No measurements are invented in this report. Below, **Expected Deterministic Outputs** are separated from **Actual Measured Results**, which you should copy from `ExperimentalData/*.csv` after running `Q1`–`Q7` locally in Eclipse or JDK 21.

### A. Expected Deterministic Outputs (Functional Verification)
- **Q3 (`Q3.Attendance`):** `Unique students: 2`
- **Q5 (`Q5.LeaderboardDemo`):** `[Eagles(9,6), Bisons(9,4), Panthers(9,4), Cobras(6,1)]`
- **Q6 (`Q6.Triage`):** `Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)`

### B. Actual Measured Results *(Populate from `ExperimentalData/*.csv` after local execution)*

#### Q1 Results (`ExperimentalData/Q1_StringBenchmark.csv`)
| Workload | `String (+)` Avg (ms) | `StringBuilder` Avg (ms) | `StringBuffer` Avg (ms) | Est. Intermediate Strings (`+` vs `SB`) |
|---|---:|---:|---:|---|
| `ShortTicket_1x8Fields` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` | `15` vs `1` |
| `BatchTickets_10000x50Fields` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` | `490,000` vs `10,000` |
| `ReservationChart_3000Entries` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` | `3,000` vs `1` |

#### Q2 Results (`ExperimentalData/Q2_ListBenchmark.csv`)
| Size ($N$) | Operation | `ArrayList` (ms) | `LinkedList` (ms) | `ArrayDeque` (ms) |
|---|---|---:|---:|---:|
| `1,000` | `AddEnd` / `InsertFront` / `RemoveFront` / `IterateAll` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` |
| `10,000` | `AddEnd` / `InsertFront` / `InsertMiddle` / `GetKthElement` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` / `N/A` |
| `50,000` | `AddEnd` / `InsertFront` / `InsertMiddle` / `GetKthElement` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` / `N/A` |

#### Q4 Results (`ExperimentalData/Q4_MapBenchmark.csv`)
| Size ($N$) | Operation | `HashMap` (ms) | `TreeMap` (ms) | `LinkedHashMap` (ms) | `SortedArray` (ms) |
|---|---|---:|---:|---:|---:|
| `1,000` | `Insertion` / `Lookup_100k` / `Iteration` / `Report` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` |
| `10,000` | `Insertion` / `Lookup_100k` / `Iteration` / `Report` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` |
| `50,000` | `Insertion` / `Lookup_100k` / `Iteration` / `Report` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` |

#### Q6 Results (`ExperimentalData/Q6_QueueBenchmark.csv`)
| Size ($N$) | `PriorityQueue` Total (ms) | `SortedLinkedList` Total (ms) | `FiveFifoQueues` Total (ms) |
|---|---:|---:|---:|
| `1,000` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` |
| `10,000` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` |
| `50,000` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` |

#### Q7 Results (`ExperimentalData/Q7_RedesignBenchmark.csv`)
| Workload | `Original_StringPlus` (ms) | `Redesigned_PreSizedSB` (ms) | Speedup | Latency Saved (%) |
|---|---:|---:|---:|---:|
| `Batch_1000x50` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` |
| `Batch_10000x50` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` |
| `Chart_3000Entries` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` | `[Pending Run]` |

### C. Key Observations (Theory vs. Measurement)
- **Cache Locality Matters:** Contiguous array-backed collections (`ArrayList`, `ArrayDeque`, `FiveFifoQueues`) avoid pointer chasing and per-node heap allocations (`LinkedList`), yielding superior real-world throughput even when Big-O classes match.
- **Allocation Pressure Dominates Loops:** Eliminating repeated intermediate `String` copies in Q1/Q7 prevents quadratic copying and reduces GC overhead.

---

## 7. Comparison Tables

### Time & Space Complexity Summary

| Structure / Approach | Insert / Append | Lookup / Access | Remove | Iteration Order | Extra Space Overhead |
|---|---|---|---|---|---|
| `String (+)` in loop ($k$ ops) | $O(k^2)$ | — | — | — | $O(k^2)$ temp garbage |
| `StringBuilder` ($k$ ops) | $O(k)$ amort | — | — | — | $O(n)$ (capacity doubling) |
| `StringBuffer` ($k$ ops) | $O(k)$ amort | — | — | — | $O(n)$ + monitor lock |
| `ArrayList` | $O(1)$ end / $O(n)$ front | $O(1)$ | $O(n)$ front/mid | Index order | Minimal capacity slack |
| `LinkedList` | $O(1)$ ends / $O(n)$ mid | $O(n)$ | $O(1)$ ends / $O(n)$ mid | Link order | ~24–40 B per `Node` |
| `ArrayDeque` | $O(1)$ amort both ends | N/A | $O(1)$ both ends | Circular buffer | Minimal capacity slack |
| `HashMap` / `HashSet` | $O(1)$ avg | $O(1)$ avg | $O(1)$ avg | Unordered | Bucket table + entries |
| `LinkedHashMap` | $O(1)$ avg | $O(1)$ avg | $O(1)$ avg | Insertion order | `before`/`after` pointers |
| `TreeMap` / `TreeSet` | $O(\log n)$ | $O(\log n)$ | $O(\log n)$ | Sorted keys | RB-Tree node pointers |
| `SortedArray` (`binarySearch`) | $O(n)$ shift | $O(\log n)$ | $O(n)$ shift | Sorted keys | Minimal (contiguous) |
| `PriorityQueue` | $O(\log n)$ | $O(1)$ peek | $O(\log n)$ poll | Min-heap array | Minimal (`Object[]`) |
| `FiveFifoQueues` (`ArrayDeque[5]`) | $O(1)$ | $O(1)$ peek | $O(1)$ | Priority + FIFO | 5 circular buffers |

---

## 8. Limitations and Improvements

### Current Limitations
1. **Approximate Memory Measurement:** `Runtime.totalMemory() - freeMemory()` with `System.gc()` provides only an educational estimate; JVM allocation profilers (e.g., JMH `-prof gc` or Java Flight Recorder) are needed for exact per-allocation byte counts.
2. **Single-Threaded Benchmarks:** Benchmarks run sequentially on one thread, so uncontended `StringBuffer` synchronization appears artificially close to `StringBuilder` compared to contended multi-threaded workloads.
3. **Static Triage Priorities:** `Q6.Triage` demonstrates priority aging conceptually rather than running a continuous background aging timer.

### Future Improvements
1. Upgrade benchmarks to **JMH (Java Microbenchmark Harness)** for statistically rigorous warmups and GC profiling.
2. Implement scheduled **priority aging** inside `Q6.Triage` using `Instant` timestamps and periodic heap re-evaluation so low-severity patients never starve under heavy `S1` load.
3. Introduce thread-safe concurrent logging (`ConcurrentLinkedQueue` or `BufferedWriter`) when scaling Q1/Q7 ticket generation across multiple worker threads.

---

## 9. Conclusion
All seven questions (`Q1`–`Q7`) of **Programming in Java – Assignment 2 (CO2)** have been structured as a clean, Eclipse-compatible Java 21 project with unified `Main.java` drivers, normal/boundary/invalid-input verification tests, UML diagrams, and CSV benchmark pipelines. Running the programs locally populates genuine `System.nanoTime()` measurements into `ExperimentalData/*.csv` to complete the experimental tables and screenshots for final submission.
